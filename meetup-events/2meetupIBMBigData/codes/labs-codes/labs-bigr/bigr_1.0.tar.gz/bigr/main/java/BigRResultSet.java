// -------------------------------------------------------------
//  IBM Confidential
//  OCO Source Materials
//  (C) Copyright IBM Corp. 2010, 2013
//  The source code for this program is not published or
//  otherwise divested of its trade secrets, irrespective of
//  what has been deposited with the U.S. Copyright Office.
// -------------------------------------------------------------

import java.sql.*;
import java.util.Vector;

// BigRResultSet class is used to retrieve requested number of rows from the server in one fetch()
// call. This is done so to reduce the excess overhead by the .rJava invocation to fetch a single
// row.
public class BigRResultSet {
	// we tend to support all these data types, however so far BigR does not handle timestamp
	private static enum ColumnTypeName {UNKNOWN, ARRAY, STRING, BIGINT, DOUBLE, BOOLEAN, FLOAT, TIMESTAMP};
	
	// caller runs JDBC executeQuery and passes in this ResultSet
	private ResultSet resultSet;
	
	// the number of rows the previous fetch() method was asked to retrieve, we keep this in the
	// object so the current fetch() method can check whether it needs to reallocate the cols buffer
	// if the caller wants to retrieve more rows in one fetch()
	private int nrow;
	
	// the column count for the ResultSet
	private int numColumns;
	
	// the column count for array type ResultSet
	private int arrayColumns;
	
	// the data type name for the column
	private Vector<ColumnTypeName> columnTypeNameV = new Vector<ColumnTypeName>();
	
	// the memory buffer to hold all rows fetched from the server
	public Object cols[];
	
	// the indicator showing whether there are still rows in the ResultSet
	private boolean avail;
	
	// the column count for the array of arrays
	private int ncol;
	
	// constructor: 
	// caller passes in the ResultSet and the ResultSetMetaData
	// if caller has called ResultSet.next() method to check whether anything is returned, it should pass
	// true for avail.
	public BigRResultSet(ResultSet rs, ResultSetMetaData rsmd, boolean avail, int ncol) throws SQLException {
		this.resultSet = rs;
		this.numColumns = rsmd.getColumnCount();
		this.nrow = 0;
		this.avail = avail;
		this.ncol = ncol;
		this.arrayColumns = 0;
		
		// translate the JDBC type to java type and save it in the vector
        for (int i = 0; i < numColumns; i++) {
        	String columnTypeName = rsmd.getColumnTypeName(i+1);
        	if (columnTypeName.equals("array")) {
        		columnTypeNameV.add(ColumnTypeName.ARRAY);
        	}
        	else if (columnTypeName.equals("char") || columnTypeName.equals("varchar") ||
        			 columnTypeName.equals("binary")) {
        		columnTypeNameV.add(ColumnTypeName.STRING);
        	}
        	else if (columnTypeName.equals("bigint")) {
        		columnTypeNameV.add(ColumnTypeName.BIGINT);
        	}
        	else if (columnTypeName.equals("double")) {
        		columnTypeNameV.add(ColumnTypeName.DOUBLE);	
        	}
        	else if (columnTypeName.equals("boolean")) {
        		columnTypeNameV.add(ColumnTypeName.BOOLEAN);
        	}
        	else if (columnTypeName.equals("float")) {
        		columnTypeNameV.add(ColumnTypeName.FLOAT);
        	}
        	else if (columnTypeName.equals("timestamp")) {
        		columnTypeNameV.add(ColumnTypeName.TIMESTAMP);
        	}
        	else {
        		columnTypeNameV.add(ColumnTypeName.UNKNOWN);
        	}
        }
        
        if ((1 == numColumns) && columnTypeNameV.get(0).equals(ColumnTypeName.ARRAY) && (0 < ncol)) {
        	this.cols = new Object[ncol];
        }
        else {
    		this.cols = new Object[numColumns];
        }
	}
	
	public BigRResultSet(ResultSet rs, ResultSetMetaData rsmd, boolean avail) throws SQLException {
		this(rs, rsmd, avail, 0);
	}
	
	public void release() {
		for (int i = 0; i < this.cols.length; i++) {
			this.cols[i] = null;
		}
		this.cols = null;
		System.gc();
	}
	
	// fetch method takes the number of rows that the caller wants to retrieve
	public int fetch(int rowRequested) throws SQLException {
		int rowsFetched = 0;
		ColumnTypeName columnTypeName;
		
		// if the current data buffers have less memory to hold all the rows requested,
		// we need to reallocate and get more memory
		if (rowRequested > this.nrow) {
			int colsToAllocate = 0;
			
			// allocate new memory to keep the data
			// special case
			if ((1 == numColumns) && columnTypeNameV.get(0).equals(ColumnTypeName.ARRAY) && (0 < ncol)) {
				colsToAllocate = ncol;
			}
			else {
				colsToAllocate = numColumns;
			}
				
			// allocate memory for each element in the array
			for (int i = 0; i < colsToAllocate; i++) {
				cols[i] = new String[rowRequested];
			}
			this.nrow = rowRequested;
		}
		
		// some initialization
		rowsFetched = 0;
		if (!this.avail) {
			this.avail = resultSet.next();
		}
		
		// fetch from server's ResultSet until it is empty or we got enough rows
		while (avail && (rowsFetched < nrow)) {
			// special case
			if ((1 == numColumns) && columnTypeNameV.get(0).equals(ColumnTypeName.ARRAY) && (0 < ncol)) {
				Array ca = resultSet.getArray(1);
				Object[] o = (Object[]) ca.getArray();
				
				// update the numColumns from the real array return
				this.arrayColumns = o.length;
				
				// read in every element as String
				for (int i = 0; i < arrayColumns; i++) {
					((String[]) cols[i])[rowsFetched] = null == o[i] ? null : o[i].toString();
				}
			}
			else {
	            for (int i = 0; i < numColumns; i++) {
	                columnTypeName = columnTypeNameV.get(i);
	                
	                // call individual ResultSet get method to retrieve the data, based on the column type
	                if (columnTypeName.equals(ColumnTypeName.ARRAY)) {
	                	String str = resultSet.getString(i+1);
	                	if ((str.charAt(0) == '[') && (str.charAt(str.length()-1) == ']')) { 
	                		((String[]) cols[i])[rowsFetched] = str.substring(1, str.length()-1);
	                	}
	                }
	                else if (columnTypeName.equals(ColumnTypeName.STRING)) {
	                	((String[]) cols[i])[rowsFetched] = resultSet.getString(i+1);
	                }
	                else if (columnTypeName.equals(ColumnTypeName.BIGINT)) {
	                	long val = resultSet.getLong(i+1);
	                	((String[]) cols[i])[rowsFetched] = resultSet.wasNull() ? null : Long.toString(val);
	                }
	                else if (columnTypeName.equals(ColumnTypeName.DOUBLE)) {
	                	double val = resultSet.getDouble(i+1);
	                	((String[]) cols[i])[rowsFetched] = resultSet.wasNull() ? null : Double.toString(val);
	                }
	                else if (columnTypeName.equals(ColumnTypeName.BOOLEAN)) {
	                	boolean val = resultSet.getBoolean(i+1);
	                	((String[]) cols[i])[rowsFetched] = resultSet.wasNull() ? null : Boolean.toString(val);
	                }
	                else if (columnTypeName.equals(ColumnTypeName.FLOAT)) {
	                	float val = resultSet.getFloat(i+1);
	                	((String[]) cols[i])[rowsFetched] = resultSet.wasNull() ? null : Float.toString(val);
	                }
	                else if (columnTypeName.equals(ColumnTypeName.TIMESTAMP)) {
	                	((String[]) cols[i])[rowsFetched] = resultSet.getTimestamp(i+1).toString();
	                }
	            } // for
			}
			
            // one row is read
            rowsFetched++;
            
            // move the cursor
            this.avail = resultSet.next();
		} // while
		return (rowsFetched);
	}
	
	// method to get the number of columns read out
	public int getArrayColumnCount() {
		return this.arrayColumns;
	}
	
	// methods for caller to copy the buffer out to R
	// return vector of strings
	public String[] getStringTypeColumn(int colidx) {
		return ((String[]) cols[colidx-1]);
	}
	
	// return vector of numerics
	public long[] getLongTypeColumn(int colidx) {
		return ((long[]) cols[colidx-1]);
	}
	
	// return vector of numerics
	public double[] getDoubleTypeColumn(int colidx) {
		return ((double[]) cols[colidx-1]);
	}
	
	// return vector of logicals
	public boolean[] getBooleanTypeColumn(int colidx) {
		return ((boolean[]) cols[colidx-1]);
	}
	
	// return vector of numerics
	public float[] getFloatTypeColumn(int colidx) {
		return ((float[]) cols[colidx-1]);
	}
	
	// return vector of strings
	public String[] getTimeStampTypeColumn(int colidx) {
		return ((String[]) cols[colidx-1]);
	}
	
	// return column in String[]
	public String[] getColumnInString(int colidx) {
		return ((String[]) cols[colidx-1]);
	}
}