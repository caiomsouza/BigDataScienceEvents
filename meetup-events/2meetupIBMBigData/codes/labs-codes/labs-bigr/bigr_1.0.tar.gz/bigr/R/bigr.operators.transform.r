#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' \code{[,]} performs filtering and projection for a given bigr.frame
#' @param x a bigr.frame
#' @param i a bigr.vector with a logic operation that represents the
#' the filtering condition
#' @param j a vector which contains the columns to be projected. These could be
#' column ids (i.e., integer values) or column names (i.e., character values)
#' @return a bigr.frame with the result of the projection and filtering.
#' @rdname sq_bracket_frame
setGeneric("[")
setMethod("[", bigr.env$FRAME_CLASS_NAME,
    function(x, i, j) {
        logSource <- "bigr.frame.[]"
        
        bigr.info(logSource, "Filtering / projecting")
        # The filtering condition as a bigr.vector
        bvCond <- NULL
        
        # The vector of columns to be projected (either id's or names)
        projCols <-  NULL
        
        # The bigr.frame to which filtering and projection will be aplied
        bf <- x
                
        if (!missing(i)) {
            bvCond <- i
        }        
        if (!missing(j)) {
            projCols <- j
        }
        
        # Create a copy of bf to be returned. The copy must have dataSource=TRANSFORM,
        # to ensure integrity with the row count caching.
        resultBf <- new(bigr.env$FRAME_CLASS_NAME, dataSource = bigr.env$TRANSFORM,
                        dataPath = bf@dataPath, colnames = bf@colnames, coltypes = bf@coltypes,
                        delimiter=bf@delimiter, na.string = bf@na.string, localProcessing = bf@localProcessing,
                        envs=x@envs)                        
    
        # This initialization is to cover the case bf[, ]
        resultBf@tableExpression <- bf@tableExpression        
        resultBf@columnExpression <- bf@columnExpression
                        
        #####################################################
        # Apply filter only if there is a filtering condition
        #####################################################
        if (!.bigr.isNullOrEmpty(bvCond)) {
            bigr.info(logSource, "Filtering...")
            
            if (class(bvCond) != bigr.env$VECTOR_CLASS_NAME) {
                bigr.err(logSource, "The given filtering condition must be a logical bigr.vector.")
            }
            
            # Check that the given condition and the bigr.frame have the same origin
            # i.e., same table expression
            if (!.bigr.is.compatible(bf, bvCond)) {
                bigr.err(logSource, "Cannot perform filtering since the given " %++%
                    "bigr.frame and the given condition do not have the same data origin")
            }
            
            # Check that the given condition is a logic bigr.vector
            if (bvCond@dataType == "logical") {
                # Applying the filter implies combining tableExpression and columnExpression of bf
                # and then appending " -> filter..."
                resultBf@tableExpression <- .bigr.getJaqlExpression(bf) %++%
                    " -> filter " %++% bvCond@columnExpression
                 
                # Since tableExpression and columnExpression were already combined, columnExpression
                # must be reset to empty string.
                resultBf@columnExpression <- ""
            } else {
                bigr.err(logSource, "The provided condition must be a logical expression")
            }
        }
        
        ####################################################################
        # Apply projection only if the set of projected columns is specified
        ####################################################################
        if (!.bigr.isNullOrEmpty(projCols)) {
        
            # The number of columns to be projected
            ncols <- length(projCols)
            
            # The resulting column expression after projection
            colExpression <- ""            
            
            # The resulting column names and types after projection
            colnames <- character(0)
            coltypes <- character(0)
            
            ##############################
            # If column id's are provided
            ##############################
            
            if (class(projCols) == "numeric" | class(projCols) == "integer") {
                bigr.info(logSource, "Projecting columns from ids...")

                # Check that either all of the ids are positive or all of them
                # are negative                
                if (any(projCols > 0) & any(projCols < 0)) {
                    bigr.err(logSource, "Positive and negative subscripts cannot be mixed in a multi-column projection.")
                }
                
                # Negative index projection
                if (all(projCols < 0)) {
                    # Create a list of positive indices to project by removing the
                    # columns with negative indices
                    projCols <- seq(1:ncol(bf))[projCols]
                    ncols <- length(projCols)
                    bigr.info(logSource, "Projected cols: ")
                    bigr.infoShow(logSource, projCols)
                }                
                
                k <- 1
                while (k < ncols) {
                    if (projCols[k] != 0 & projCols[k] <= ncol(bf) & .bigr.is.integer(projCols[k])) {
                        colExpression <- colExpression %++% "$[" %++% (projCols[k] - 1) %++% "], "
                        colnames[k] <- bf@colnames[projCols[k]]
                        coltypes[k] <- bf@coltypes[projCols[k]]
                        k <- k + 1
                    } else {
                        bigr.err(logSource, "Invalid column id: " %++% projCols[k])
                    }
                }
                if (projCols[k] == 0 | projCols[k] > ncol(bf) | !.bigr.is.integer(projCols[k])) {
                    bigr.err(logSource, "Invalid column id: " %++% projCols[k])
                }
                colExpression <- colExpression %++% "$[" %++% (projCols[ncols] - 1) %++% "]"
                colnames[ncols] <- bf@colnames[projCols[ncols]]
                coltypes[ncols] <- bf@coltypes[projCols[ncols]]
                
            # If column names are provided    
            } else if (class(projCols) == "character") { 
                bigr.info(logSource, "Projecting columns from names...")
                
                # Check that the given column names are valid
                if (!.bigr.validProjectionNames(bf, projCols)) {
                    bigr.err(logSource, "Invalid columns to project")
                }
                k <- 1
                while (k < ncols) {
                    colId <- match(projCols[k], bf@colnames) - 1
                    if (is.na(colId)) {
                        bigr.err(logSource, "Column '" %++% projCols[k] %++% "' does not belong to the given bigr.frame.")
                    }
                    bigr.info(logSource, "ColId: " %++% colId)
                    colExpression <- colExpression %++% "$[" %++% colId %++% "], "
                    colnames[k] <- bf@colnames[colId + 1]
                    coltypes[k] <- bf@coltypes[colId + 1]
                    k <- k + 1
                }
                colId <- match(projCols[ncols], bf@colnames) - 1
                if (is.na(colId)) {
                    bigr.err(logSource, "Column '" %++% projCols[k] %++% "' does not belong to the given bigr.frame.")
                }
                colExpression <- colExpression %++% "$[" %++% colId %++% "]"
                colnames[ncols] <- bf@colnames[colId + 1]
                coltypes[ncols] <- bf@coltypes[colId + 1]
            } else {
                bigr.err(logSource, "Invalid columns for projection: " %++% class(projCols))
            }
            bigr.info(logSource, "Column expression: " %++% colExpression)
            
            # If there is only one projected column, a bigr.vector must be returned
            if (length(projCols) == 1) {
                resultBv <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath=bf@dataPath, 
                              name = colnames[1], dataType = coltypes[1], envs=x@envs)
                
                # The tableExpression will be the concatenation of the current tableExpression (i.e., after filtering)
                # , "transform -> ", and the original columnExpression
                resultBv@tableExpression <- .bigr.getJaqlExpression(resultBf)                
                resultBv@columnExpression <- colExpression      
                return(resultBv)
            } else {
                # Assign the new column expression, colnames, and coltypes, for the 
                # projected columns.
                
                # The tableExpression will be the concatenation of the current tableExpression (i.e., after filtering)
                # , "transform -> ", and the original columnExpression
                resultBf@tableExpression <- .bigr.getJaqlExpression(resultBf)
                resultBf@columnExpression <- colExpression
                resultBf@colnames <- colnames
                resultBf@coltypes <- coltypes
            }
        }
        return(resultBf)
    }
)

#' \code{[} performs filtering and projection for a given bigr.vector
#' @param x a bigr.vector
#' @param i a bigr.vector with a logic operation that represents the
#' the filtering condition. i and x must have the same data origin.
#' @return a bigr.vector with the result of the projection and filtering.
#' @rdname sq_bracket_vector
setGeneric("[")
setMethod("[", bigr.env$VECTOR_CLASS_NAME,
    function(x, i) {
        logSource <- "bigr.vector.[]"
        
        # The filtering condition as a logic bigr.vector
        bvCond <- i
        
        # The bigr.vector to which the filtering will be applied
        bv <- x
        
        # The resulting bigr.vector
        result <- bv
        result@tableExpression = ""
        result@columnExpression = ""
        result@envs = x@envs
        
        # Apply filter only if there is a given condition
        if (!is.null(bvCond)) {            
            bigr.info(logSource, "Filtering...")
            
            # Check that the given condition is a logic bigr.vector
            if (bvCond@dataType == "logical") {
            
                # Check that the given condition and the given bigr.vector have the
                # same data origin.
                if (bvCond@tableExpression == bv@tableExpression) {
                     result@tableExpression <- bv@tableExpression %++% " -> filter " %++% bvCond@columnExpression
                     result@columnExpression <- bv@columnExpression
                } else {
                    bigr.err(logSource, "The provided condition bigr.vector " %++% 
                        " does not match the target filtering bigr.vector")
                    return(NULL)
                }
            } else {
                bigr.err(logSource, "The provided condition is not a logic expression")
                return(NULL)
            }
        }
        return(result)
    }
)

# This function returns TRUE if the given JaQL column expression has
# the same column ids in all operations.
#
# Example:
# For exp="($[0] + $[1]) > 3 & $[0] > 3212)", it should return NULL
# For exp="($[0] + $[0]) > 3 & $[0] > 3212)", it should return $[0]
#
# This function is useful for filtering bigr.vector's
# Example: 
# zipcodes <- homes$zipcodes
# zipcodes[zipcodes != 95141]
.getOriginalColumnExpression <- function(exp) {
    pattern <- "\\$\\[[0-9]+\\]"
    m <- regexec(pattern, exp)    
    colExp <- as.character(regmatches(exp,m))
    exp <- gsub(colExp, "", exp, fixed=TRUE)
    
    if (regexec(pattern, exp)[[1]][1] == -1) {
        return(colExp)
    } else {
        return(NULL)
    }
}

#' \code{$} projects a column for a given bigr.frame
#' @param x a bigr.frame
#' @param name the column to be projected
#' @return a bigr.vector containing the projected column.
#' @rdname dollar
#' TODO: Modify this method to invoke x[, "name]
setGeneric("$")
setMethod("$", bigr.env$FRAME_CLASS_NAME,
    function(x, name) {
        x[, c(name)]
    }
)

#' \code{$<-} adds a new column to a given bigr.frame.
#'
#' The new column to be appended must have the same data origin
#' as the original bigr.frame.
#' @param x a bigr.frame
#' @param name the new column to be added
#' @param value a bigr.vector with the new column expression
#' @return a new bigr.frame with the appended column
#' @rdname col_assignment
setGeneric("$<-")
setMethod("$<-", bigr.env$FRAME_CLASS_NAME,
    function(x, name, value) {
        logSource <- "$<-"
        # Parameter validation
        
        if (missing(value)) {
            value <- NULL
        }
        if (.bigr.isNullOrEmpty(name) | .bigr.isNullOrEmpty(x))  {
            bigr.err(logSource, "Could not create a new column. Parameters for $<- cannot be NULL or empty.")
        }
        
        # If value is null, it means that the corresponding column should be removed
        if (is.null(value)) {
            if (name %in% x@colnames) {                
                bigr.info(logSource, "Value is null... removing column...")
                
                # Get the column id to be removed
                k <- match(name, colnames(x))            
                bigr.info(logSource, "Colid: " %++% k)
                
                # Project all columns but the one to be removed
                return(x[, colnames(x)[-k]])            
            } else {
                bigr.err(logSource, "Column '" %++% name %++% "' cannot be removed since it does not exist.")
            }
        }
        
        # Check for an existing column with the same name as the specified
        if (name %in% x@colnames) {
            bigr.err(logSource, "Cannot overwrite an existing column. No new column was created.")
        }
        
        newDataType <- NULL
        newColumnExpression <- NULL
        if (class(value) == bigr.env$VECTOR_CLASS_NAME) {
            # TODO: Check if it should be x@tableExpression
            if (value@tableExpression != .bigr.getJaqlExpression(x) & value@tableExpression != bigr.env$EMPTY_TABLE_EXPRESSION) {
                bigr.err(logSource, "The new column and the bigr.frame must have the same data origin.")
            } else {
                newDataType <- value@dataType
                newColumnExpression <- value@columnExpression
            }
        } else if (class(value) == "character" | class(value) == "numeric" | class(value) == "integer"
                   | class(value) == "logical") {                   
            newDataType <- class(value)
            newColumnExpression <- .bigr.getOperand(value)    
        }
        
       # Value could be either a bigr.vector or a fixed value
        result <- new(bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath=x@dataPath, 
                      delimiter=x@delimiter, colnames=x@colnames, coltypes=x@coltypes,
                      localProcessing = x@localProcessing,
                      envs=x@envs)
        
        length(result@colnames) <- length(result@colnames) + 1
        length(result@coltypes) <- length(result@coltypes) + 1
        
        result@colnames[length(result@colnames)] <- name
        result@coltypes[length(result@coltypes)] <- newDataType
        
        allColumns <- paste("$[" %++% (seq(1:length(x@coltypes)) - 1) , "]", collapse = ", ", 
                            sep="") %++% ", " %++% newColumnExpression
        
        result@tableExpression <- .bigr.getJaqlExpression(x) %++% " -> transform[" %++% allColumns %++% "]"
        result@columnExpression <- ""        
        return(result)
    }
)
