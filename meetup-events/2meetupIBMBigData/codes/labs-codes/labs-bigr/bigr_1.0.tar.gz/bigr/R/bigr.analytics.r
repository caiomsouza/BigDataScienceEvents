#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# bigr.analytics
#
# This file contains a variety of functions for big data analytics.
#

#' This function computes the quartiles, maximum, and minimum value from
#' a given bigr.vector. 
#'
#' @param bv a \code{bigr.vector} of numeric type
#' @return a \code{data.frame} with the minimum, maximum, and quartiles of \code{bv}
#' @keywords internal
bigr.quartiles <- function(bv) {
    logSource <- "bigr.quartiles"
    
    # Validate parameters
    if (missing(bv)) {
        bv <- NULL
    }    
    if (.bigr.isNullOrEmpty(bv)) {
        bigr.err(logSource, "Quartiles can only be calculated from a numeric bigr.vector.")
        return(NULL)
    }
    if (class(bv) != bigr.env$VECTOR_CLASS_NAME) {
        bigr.err(logSource, "Quartiles can only be calculated from a numeric bigr.vector.")
        return(NULL)
    }
    if (bv@dataType != "numeric" & bv@dataType != "integer") {
        bigr.err(logSource, "Quartiles can only be calculated from a numeric bigr.vector.")
        return(NULL)
    }
    
    # Invoke JaQL function to compute quartiles
    df <- .bigr.executeJaqlQuery(jaqlExpression = .bigr.getJaqlExpression(bv) %++% 
                                    " -> transform $[0] -> quartiles('')", 
                                    colnames=c("class", "Min.", "1st Qu.", "Median", "3rd Qu.", "Max."),
                                    coltypes=c("character", "numeric", "numeric", "numeric", "numeric", 
                                               "numeric"), limit=FALSE)
    
    # Remove grouping column since it is only used when grouping
    df$class <- NULL    
    return(df)
}

#' Computes the number of occurrences of each distinct value in a given bigr.vector
#'
#' @param bv a \code{bigr.vector}
#' @return a \code{data.frame} with the number of occurrences of each distinct value in \code{bv}
#' @keywords internal
bigr.distinctCounts <- function(bv) {
    logSource <- "bigr.distinctCounts"
    
    # Parameter validation
    if (missing(bv)) {
        bv <- NULL
    }
    if (.bigr.isNullOrEmpty(bv)) {
        bigr.err(logSource, "This method only applies to bigr.vector's.")
    }
    if (class(bv) != bigr.env$VECTOR_CLASS_NAME) {
        bigr.err(logSource, "This method only applies to bigr.vector's.")
    }
    
    # Invoke JaQL function to compute distinct counts
    df <- .bigr.executeJaqlQuery(.bigr.getJaqlExpression(bv) %++% 
                                    " -> transform $[0] -> distinctCounts()", limit=FALSE) 

    return(df)
}

setGeneric("mean")
setMethod("mean", signature(x = bigr.env$VECTOR_CLASS_NAME),
function (x, trim = 0, na.rm = T, ...) {               
    logSource <- "mean"
    
    # Parameter validation
    if (.bigr.isNullOrEmpty(x)) {
        bigr.err(logSource, "This function can only be applied to numeric bigr.vector's.")
        return(NULL)
    }
    if (class(x) != bigr.env$VECTOR_CLASS_NAME) {
        bigr.err(logSource, "This function can only be applied to numeric bigr.vector's.")
        return(NULL)
    }
    if (x@dataType != "numeric" & x@dataType != "integer") {
        bigr.err(logSource, "This function can only be applied to numeric bigr.vector's.")
        return(NULL)
    }
    
    # Trimmed means not supported yet
    .bigr.checkParameter(logSource, trim, expectedValues=0)
    
    # Invoke JaQL function to compute mean
    df <- .bigr.executeJaqlQuery(jaqlExpression = .bigr.getJaqlExpression(x) %++% 
                                    " -> transform double(toNumber($[0])) -> group into avg($)", limit=FALSE, coltypes=c("numeric"))
    
    # Return the result as a simple data type (not a bigr.frame)
    return(df[[1]])
})

setGeneric("var")
setMethod("var", signature(x = bigr.env$VECTOR_CLASS_NAME),
          function (x, na.rm = TRUE) {               
              logSource <- "var"
                            
              # Parameter validation
              if (.bigr.isNullOrEmpty(x)) {
                  bigr.err(logSource, "This function can only be applied to numeric bigr.vector's.")
                  return(NULL)
              }
              if (class(x) != bigr.env$VECTOR_CLASS_NAME) {
                  bigr.err(logSource, "This function can only be applied to numeric bigr.vector's.")
                  return(NULL)
              }
              if (x@dataType != "numeric" & x@dataType != "integer") {
                  bigr.err(logSource, "This function can only be applied to numeric bigr.vector's.")
                  return(NULL)
              }
              
              # Invoke JaQL function to compute var
              df <- .bigr.executeJaqlQuery(jaqlExpression = .bigr.getJaqlExpression(x) %++% 
                                               " -> transform $[0] -> group into var($)", limit=FALSE, coltypes=c("numeric"))
              
              # Return the result as a simple data type (not a bigr.frame)
              return(df[[1]])
          })

setGeneric("sd")
setMethod("sd", signature(x = bigr.env$VECTOR_CLASS_NAME),
          function (x, na.rm = TRUE) {               
              logSource <- "sd"
              
              sqrt(var(x, na.rm))
          })

#' This method computes basic statistics on a bigr.vector or a bigr.frame 
#' object. It has several overloaded variants. In its simplest form, the 
#' method accepts a single parameter of class bigr.vector or bigr.frame, and 
#' produces several key statistics such as max, min and count. The method can
#' also be called with a formula that specifies the exact set of aggregate 
#' statistics on one or more columns of a bigr.frame.
#' 
#' The variants of the method that accept one parameter compute a fixed set 
#' of statistics.
#' 
#' The "formula" variant, however, allows for greater flexibility as it 
#' supports the ability to compute grouped aggregate functions for the 
#' specified columns. For a given formula LHS ~ RHS, LHS should contain the 
#' aggregate functions that need to be computed whereas RHS should specify 
#' any grouping columns. If the aggregate functions are to be computed for 
#' the entire dataset (i.e., without grouping), RHS should be set to a dot 
#' (.) symbol. A column alone can be specified in the LHS, and that serves as
#' a shorthand for a collection of aggregate functions that apply to the 
#' column's type.
#' 
#' Supported aggregate functions are: min, max, count, sum, avg, var and sd. 
#' Each function requires a single-parameter that corresponds to a column 
#' name in the bigr.frame. Column names cannot be the same as function names.
#' NA values are implicitly ignored when computing the aggregate statistics 
#' on columns.
#' 
#' The count aggregate has two flavors. count(column) only counts rows where 
#' the column is not NA. In addition, count(.) can be used to count the total
#' number of rows in a bigr.frame, or group. Note that count(column1) and 
#' count(column2) may yield different values because of differences in NA 
#' values across column1 and column2.
#' 
#' @title Compute descriptive statistics
#' @name summary
#' @section Usage:
#'   
#'   \code{summary(object)           # object is a bigr.vector or bigr.frame}
#'   
#'   \code{summary(object, formula)  # object is a bigr.frame}
#'
#' @rdname summary_formula
#' @param object   (bigr.vector or bigr.frame) The data itself
#' @param formula  (formula) Optionally describes a set of columns, aggregate
#'   functions to be calculated on each column, as well any grouping columns.
#'   A formula can only be specified when object is of class "bigr.frame"
#'   
#' @return a data.frame with the computed aggregate functions
#' @examples \dontrun{
#' 
#' #' Summarize a bigr.frame
#' summary(air)
#' summary(air[,c("DepDelay", "ArrDelay")])
#' 
#' #' Summarize a bigr.vector
#' summary(air$Distance)
#' 
#' # Count total # of rows (flights) in the entire dataset
#' summary(air, count(.) ~ .)
#' 
#' # Count # of flights where Distance != NA
#' summary(air, count(Distance) ~ .)
#' 
#' # Compute basic descriptive statistics (count, min and max) on a
#' # non-numeric column.
#' summary(air, UniqueCarrier ~ .)
#' 
#' # Compute basic descriptive statistics (count, min, max, sum, mean) on a
#' # numeric column.
#' summary(air, air$Distance ~ .)
#' 
#' # Compute mean and standard deviation of distance flown by each airline
#' summary(air, mean(Distance) + sd(Distance) ~ UniqueCarrier)
#' 
#' # Compute a mix of statistics on various columms, grouped
#' # by multipe columns (UniqueCarrier and Year)
#' summary(air, max(Distance) + mean(DepDelay) + ArrDelay 
#                   ~ UniqueCarrier + Year)
#' }
NULL

bigr.summary <- function(dataset, formula) {
    logSource <- "bigr.summary"
    
    .bigr.checkParameter(logSource, dataset, expectedClasses="bigr.frame", isOptional=T)
    .bigr.checkParameter(logSource, formula, expectedClasses="formula")
        
    ###############################################################################
    # Step 1: Parse left hand side of the formula and build the corresponding JaQL
    # expression for the aggregate functions.
    ###############################################################################
    
    # The JaQL expression containing the aggregated functions. In other words, whatever
    # will be in the "into" clause. Ex: max($[1]), min($[3})
    aggJaqlExp <- ""
    
    # An array containing the column names of the aggregated functions.
    # Ex: max(saleprice), min(askingprice), avg(floors)
    aggColnames <- vector()
    
    # An array containing the column types of the aggregated functions.
    aggColtypes <- vector()
    
    # In R, formulas are represented in a tree-like fashion and individual tokens can be
    # extracted using the [[ ]] operators. For example, if formula == max(floors) ~ zipcode,
    # formula[[1]] refers to ~, formula[[2]] is max(floors), and formula[[3]] is zipcode.
    # In turn, formula[[2]][[1]] is max, while formula[[2]][[2]] is floors.
    
    # Therefore, to get the atomic tokens (i.e., aggregate functions and column names), a
    # tree traversal algorithm is invoked for formula[[2]]. Since this algorithm is recursive,
    # a global list of leaves is maintained in bigr.env. Such list must be manually cleaned up
    # before each invocation of the tree traversal algorithm.
    bigr.env$leaves <- list()
    leaves <- .bigr.tree.traversal(formula[[2]])
    
    # The data type count
    k <- 1
    
    # Go over the result of the traversal to interpret tokens.
    i <- 1
    while (i <= length(leaves)) {            
        # The column name which an aggregate function will be applied to
        col <- NULL
        
        # The bigr.frame name (only if using $ notation for the columns)
        bfName <- NULL
        
        # The aggregate function name: either max, min, avg, etc.
        fun <- NULL
        
        # Check if the current leaf is an aggregated function name
        if (leaves[[i]] %in% bigr.env$ALL_AGGREGATE_FUNCTIONS) {
            if (i >= length(leaves)) {
                bigr.err(logSource, "Invalid formula. A column name must be specified for each aggregate function")
            }
            
            # Extract the function name
            fun <- leaves[[i]]
            
            # Once an aggregate function is found, the next symbol(s)
            # will correspond to the column name, which can be one symbol 
            # (e.g., UniqueCarrier), or three symbols (e.g., air$UniqueCarrier)
            if (leaves[[i + 1]] == "$") {
                bfName <- leaves[[i + 2]]   
                col <- leaves[[i + 3]]
                i <- i + 4
            } else if (leaves[[i + 1]] == ".") {
                col <- bigr.env$ALL_COLUMNS
                i <- i + 2
            } else {                    
                col <- leaves[[i + 1]]
                i <- i + 2
            }
            
            # If no aggregate function is specified, then a column name was found.
        } else if (.bigr.validIdentifier(leaves[[i]])) {
            col <- leaves[[i]]
            i <- i + 1            
            
            # If a dollar symbol was found, the next token should be the dataset name and
            # the next one should be the column name
        } else if (leaves[[i]] == "$") {
            if (i >= length(leaves) - 1) {
                bigr.err(logSource, "Invalid formula. A column name must be specified after the $ operator")
            }
            col <- leaves[[i + 2]]
            if (is.null(bfName)) {
                bfName <- leaves[[i + 1]]
            } else if (bfName != leaves[[i + 1]]) {
                bigr.err(logSource, "All columns specified in the formula must belong to the same bigr.frame.")
            } else {
                bfName <- leaves[[i + 1]]
            }
            i <- i + 3
            # + signs will be skipped
        } else if (leaves[[i]] == "+") {
            i <- i + 1
        } else {
            bigr.err(logSource, "Invalid symbol in the formula: '" %++% leaves[[i]] %++% "'")                
        }
        
        # If current symbol/token is not +, some processing needs to be done
        if (!is.null(col)) {            
            
            # If a bigr.frame was specified in the formula
            if (!is.null(bfName)) {
                
                # Check that datasets are consistent
                if (is.null(dataset)) {
                    dataset <- get(bfName)
                } else if (.bigr.getJaqlExpression(dataset) != .bigr.getJaqlExpression(get(bfName))) {
                    bigr.err(logSource, "All columns specified in the formula must belong to the same bigr.frame.")
                }
            } else if (is.null(dataset)) {
                bigr.err(logSource, "A bigr.frame must be specified in either (1) the left side of the formula, or (2) the 'data' parameter.")
            }
            
            # Get the column id from the given column name
            colid <- NULL
            
            # Handle special cases for count
            if (!.bigr.isNullOrEmpty(fun)) {
                if (fun == "count") {
                    if (.bigr.isNullOrEmpty(col)) {
                        bigr.err(logSource, "Invalid formula. A column was expected for function count.")
                    }
                    if (col == bigr.env$ALL_COLUMNS) {                        
                        colid <- 0
                    } else {
                        fun <- "countnonNA"
                    }
                    # countnonNA will be disabled for the user but not for the backend
                } else if (fun == "countnonNA") {
                    bigr.err(logSource, "Invalid function 'countnonNA'. Use count instead.")
                } else {
                    if (col == bigr.env$ALL_COLUMNS) {
                        bigr.err(logSource, "Operator . is only supported by the count function.")
                    }
                }
            }
            if (.bigr.isNullOrEmpty(colid)) {
                colid <- match(col, colnames(dataset)) - 1
            }
            
            if (.bigr.isNullOrEmpty(colid)) {
                bigr.err(logSource, sprintf("Object'%s' used in formula is not valid column.", col))
            }
            
            # Get the data type of the current column
            dataType <- dataset@coltypes[colid + 1]                
            
            # Append a new column to the aggregate JaQL expression if a function was specified
            if (!is.null(fun)) {
                
                invalidOp <- F
                # Check that numeric functions are not being applied to nominal variables
                if (dataType == "character") {
                    if (!(fun %in% bigr.env$ALL_NOMINAL_AGGREGATE_FUNCTIONS)) {
                        invalidOp <- T
                        bigr.warn(logSource, "Cannot apply function '" %++% fun %++% "' to a non-numeric column: " %++% col)
                    } else {
                        if (fun %in% bigr.env$NUMERIC_TYPE_AGGREGATE_FUNCTIONS) {
                            aggColtypes[k] <- "numeric"
                        } else {
                            aggColtypes[k] <- dataType
                        }                            
                    }
                } else {
                    aggColtypes[k] <- "numeric"
                }
                if (!invalidOp) {
                    aggJaqlExp <- aggJaqlExp %++% fun %++% "($[*][" %++% colid %++% "])"
                } else {
                    aggColtypes[k] <- "numeric"
                    aggJaqlExp <- aggJaqlExp %++% fun %++% "(null)"
                }
                # Display countnonNA as count for the user. Under the cover, we invoke countnonNA
                if (fun == "countnonNA") {
                    aggColnames[k] <- "count(" %++% col %++% ")"
                } else {
                    aggColnames[k] <- fun %++% "(" %++% col %++% ")"
                }
                k <- k + 1
                
                # Calculate all functions for the current column if no function was specified
            } else {
                
                # Pick the set of aggregate functions according to the data type
                functions <- NULL
                if (dataType == "character" | dataType == "boolean") {
                    functions <- bigr.env$DEFAULT_NOMINAL_AGGREGATE_FUNCTIONS
                } else {
                    functions <- bigr.env$DEFAULT_NUMERIC_AGGREGATE_FUNCTIONS
                }     
                
                aggJaqlExp <- aggJaqlExp %++% paste(functions, "($[*][" %++% colid %++% "])", sep="", collapse=", ")                
                for (j in 1 : length(functions)) {
                    if (functions[j] %in% bigr.env$NUMERIC_TYPE_AGGREGATE_FUNCTIONS) { 
                        aggColtypes[j + k - 1] <- "numeric"                            
                    } else {
                        aggColtypes[j + k - 1] <- dataType
                    }
                    if (functions[j] == "countnonNA") {
                        aggColnames[j + k - 1] <- "count(" %++% col %++% ")"    
                    } else {
                        aggColnames[j + k - 1] <- functions[j] %++% "(" %++% col %++% ")"
                    }
                    
                }
                k <- k + length(functions)
            }
            
            # Append a "," if this is not the last token
            if (i <= length(leaves)) {
                aggJaqlExp <- aggJaqlExp %++% ", "
            }
        }
    }    
    bigr.info(logSource, "Aggregate JaQL expression: " %++% aggJaqlExp)
    
    ###############################################################################
    # Step 2: Parse right hand size of the formula to extract the grouping columns        
    ###############################################################################
    
    # The JaQL expression for the group by clause (e.g., "$[1], $[2]") 
    groupByJaqlExp <- ""
    
    # The JaQL expression for the grouping columns (e.g., "$[0][1], $[0][2]")
    # This is to include the grouping columns in the resulting data.frame
    groupingColExp <- ""
    
    # The names of the grouping columns
    groupingColnames <- vector()
    
    # The data types of the grouping columns
    groupingColtypes <- vector()
    
    # The complete JaQL query to calculate the summary
    summaryJaqlExp <- NULL
    if (formula[[3]] == ".") {
        summaryJaqlExp <- .bigr.getJaqlExpression(dataset) %++% " -> " %++% "group into [" %++% aggJaqlExp %++% "]"            
        bigr.infoShow(logSource, aggColnames)            
    } else {
        # The counter for groupingColnames/types
        k <- 1
        
        # Repeat the same process for formula[[2]] (see above comments)
        bigr.env$leaves <- list()
        leaves <- .bigr.tree.traversal(formula[[3]])
        bigr.infoShow(logSource, leaves)
        i <- 1
        while (i <= length(leaves)) {
            # The column name which an aggregate function will be applied to
            col <- NULL
            
            # The bigr.frame name (optional)
            bfName <- NULL
            
            # If a column name is specified
            if (.bigr.validIdentifier(leaves[[i]])) {
                col <- leaves[[i]]
                i <- i + 1
                
                # If a dollar symbol was found, the next token should be the dataset name and
                # the next one should be the column name                
            } else if (leaves[[i]] == "$") {
                if (i >= length(leaves) - 1) {
                    bigr.err(logSource, "Invalid formula. A column name must be specified after the $ operator")
                }
                col <- leaves[[i + 2]]
                if (is.null(bfName)) {
                    bfName <- leaves[[i + 1]]
                } else if (bfName != leaves[[i + 1]]) {
                    bigr.err(logSource, "All columns specified in the formula must belong to the same bigr.frame.")
                } else {
                    bfName <- leaves[[i + 1]]
                }
                i <- i + 3
            } else if (leaves[[i]] == "+") {
                # Do nothing
                i <- i + 1
            } else {
                bigr.err(logSource, "Invalid symbol in the formula: '" %++% leaves[[i]] %++% "'")
            }
            
            # If current symbol is not +, there is something to do
            if (!is.null(col)) {
                # If a bigr.frame was specified in the formula
                if (!is.null(bfName)) {
                    # Check that datasets are consistent
                    if (is.null(dataset)) {
                        dataset <- get(bfName)
                    } else if (.bigr.getJaqlExpression(dataset) != .bigr.getJaqlExpression(get(bfName))) {
                        bigr.err(logSource, "All columns specified in the formula must belong to the same bigr.frame.")
                    }
                } else if (is.null(dataset)) {
                    bigr.err(logSource, "A bigr.frame must be specified in the formula.")
                }
                
                # Get the column id from the given column name
                colid <- match(col, colnames(dataset)) - 1
                if (.bigr.isNullOrEmpty(colid)) {
                    bigr.err(logSource, "2. Invalid column: '" %++% col %++% "'" )
                }
                
                # Append current column to the groupBy clauses
                groupByJaqlExp <- groupByJaqlExp %++% "$[" %++% colid %++% "]"
                groupingColExp <- groupingColExp %++% "$[0][" %++% colid %++% "]"
                groupingColnames[k] <- col
                groupingColtypes[k] <- dataset@coltypes[colid + 1]
                k <- k + 1
                if (i <= length(leaves)) {
                    groupByJaqlExp <- groupByJaqlExp %++% ", "
                    groupingColExp <- groupingColExp %++% ", "
                } 
            }
        }
        
        bigr.info(logSource, "GroupByJaqlExp: " %++% groupByJaqlExp)
        bigr.info(logSource, "groupingColnames:")
        bigr.infoShow(logSource, groupingColnames)
        bigr.info(logSource, "groupingColtypes:")
        bigr.infoShow(logSource, groupingColtypes)
        bigr.info(logSource, "aggColnames:")
        bigr.infoShow(logSource, aggColnames)
        bigr.info(logSource, "aggColtypes:")
        bigr.infoShow(logSource, aggColtypes)
        
        summaryJaqlExp <- .bigr.getJaqlExpression(dataset) %++% " -> " %++% "group by [" %++% groupByJaqlExp %++%
            "] into [" %++% groupingColExp %++% ", " %++% aggJaqlExp %++% "]"
    }
    .bigr.executeJaqlQuery(summaryJaqlExp, colnames=c(groupingColnames, aggColnames), coltypes=c(groupingColtypes, aggColtypes), limit=FALSE)
}

# This function returns the leaves of a formula tree in a preorder fashion
.bigr.tree.traversal <- function(root) {    
    if (!is.null(root)) {
        # If the current node has children
        if (length(root) > 1) {        
            for (i in 1:length(root)) {                
                .bigr.tree.traversal(root[[i]])
            }
        # Only add the current node to the list if it has no children    
        } else {
            bigr.env$leaves[[length(bigr.env$leaves) + 1]] <- as.character(root)
        }
    }
    bigr.env$leaves
}

# Summary - Define family of generic functions
#    max, min, range, sum, any, all. prod is not available yet
setMethod("Summary", 
  signature(x = "bigr.vector"),
  function (x, ..., na.rm = TRUE) {
      op <- .Generic
      logSource <- op
      
      # Get the operator, turning mean->avg
      legalops <- c("min", "max", "sum", "range", "any", "all")
      
      # Validate if we support the requested operator
      if (! (op %in% legalops)) {
          bigr.err(logSource, sprintf("Operation %s currently not supported", op))
      }
      
      # Validate operators against datatypes
      if ((op %in% c("sum", "range")) & (x@dataType == "character")) {
          bigr.err(logSource, sprintf("Operation '%s' not supported on character vectors.", op))
      }
      if ((op %in% c("any", "all")) & (x@dataType != "logical")) {
          bigr.err(logSource, sprintf("Operation '%s' not supported on logical vectors.", op))
      }
      
      # Turn logical vectors into integer vectors (with T = 1, F = 0)
      if (x@dataType == "logical")
          x <- ifelse(x, 1, 0)
      
      # Construct the JaQL query to send over
      query <- .bigr.getJaqlExpression(x) %++% " -> transform $[0]"
      if (op == "range") {
          query <- query %++% " -> group into [min($[*]), max($[*])]"
          coltypes <- c(x@dataType,x@dataType)
      } else {
          if (op == "any")
              altop <- "max"
          else if (op == "all")
              altop <- "min"
          else
              altop <- op
      
          query <- query %++% " ->" %++% altop %++% "()"
          coltypes <- c(x@dataType)
      }
      
      df <- .bigr.executeJaqlQuery(jaqlExpression = query, limit=FALSE, coltypes = coltypes)
      
      # Return the result
      if (op == "range") {
          return (t(df)[,1])
      } else {
          result <- df[[1]]
          if (op %in% c("any", "all"))
              result <- ifelse(result, T, F)
          return (result)
      }
  })

# .bigr.covcor
#   Compute covariance or correlation between all columns of a bigr.frame
.bigr.covcor <- function(x, type="cor", method) {
    logSource <- ".bigr.covcor"
    
    .bigr.checkParameter(logSource, type, expectedValues=c("cor", "cov"))
    .bigr.checkParameter(logSource, method, expectedValues="pearson")
    
    types <- (coltypes(x) %in% c("integer", "numeric"))
    if (length(which(types == FALSE)) > 0) {
        bigr.err(logSource, "Function can only accept a bigr.frame with integer or numeric columns")
    }  
    
    if (ncol(x) <= 1) {
        bigr.err(logSource, "Frame needs at least two columns.");
    }
    
    # Remove all rows with NAs
    x <- na.omit(x)
    
    # Compute count, mean and sd    
    query <- sprintf("%s -> group into [ %s ] -> expand -> expand",
                     .bigr.getJaqlExpression(x),
                     paste("cmv($[*][", 0:(ncol(x)-1), "])[0:2]", sep="", collapse=", "))
    
    msd <-  .bigr.executeJaqlQuery(query, coltypes="numeric", limit=F)
    
    # Extract row count
    N <- msd[1,1]
    
    if (is.na(N)) {
        bigr.warn(logSource, "Cannot compute covariance/correlation matrix as input data has 0 rows.")
        return(NULL)
    }
    
    # Extract means and standard deviations
    means <- msd[seq(2, ncol(x) * 3, 3),1]
    stds <- sqrt(msd[seq(3, ncol(x) * 3, 3),1])
    
    
    # Generate pairs    
    ncols <- 0
    newcolnames <- c()
    newexpr <- c()
    for (i in 1:ncol(x)) {
        for (j in i:ncol(x)) {
            colname  <- paste(colnames(x)[i], colnames(x)[j], sep="")
            newcolnames <- c(newcolnames, colname)
            newexpr <- c(newexpr,
                         sprintf("(($[%d] - %f) * ($[%d] - %f)) / %d",
                                 i-1, means[i], j-1, means[j], N - 1))
        }
    }
    newexpr <- paste(newexpr, collapse=", ")
    newexpr <- .bigr.getJaqlExpression(x) %++% " -> transform [ " %++% newexpr %++% " ]"
    
    result <- new(bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TRANSFORM, 
                  dataPath=x@dataPath, 
                  delimiter=x@delimiter, 
                  colnames=newcolnames, 
                  coltypes=rep("numeric", length(newcolnames)),
                  envs=x@envs)
    
    result@tableExpression <- newexpr
    result@columnExpression <- ""        
        
    # Compute covariance
    f <- paste("sum(", colnames(result), ")", sep="", collapse=" + ")
    f <- paste(f, "~ .", sep="")
    f <- as.formula(f)
    covs <- summary(result, f)
    
    # Finalize computations based on whether we're calculating cov or cor
    if (type == "cor") {
        denom <- c()
        for (i in 1:ncol(x)) {
            for (j in i:ncol(x)) {
                denom <- c(denom, stds[i] * stds[j])
            }
        }
        out <- covs / denom
    } else {
        out <- covs
    }
    
    # Make result matrix
    result <- matrix(1, nrow=ncol(x), ncol=ncol(x))
    
    idx <- 1
    for (i in 1:ncol(x)) {
        for (j in i:ncol(x)) {
            result[i,j] <- ifelse(i == j & type == "cor", 1, out[1,idx])
            result[j,i] <- ifelse(i == j & type == "cor", 1, out[1,idx])
            idx <- idx + 1
        }
    }
    
    colnames(result) <- colnames(x)
    rownames(result) <- colnames(x)
    
    return (result)
}

setGeneric("cov")
setMethod("cov", signature(x = bigr.env$FRAME_CLASS_NAME),
          function(x, y = NULL, use = "complete.obs", method = "pearson") {
              logSource <- "cov"
              
              .bigr.checkParameter(logSource, y, expectedValues=NULL)
              .bigr.checkParameter(logSource, use, expectedValues="complete.obs")
              .bigr.checkParameter(logSource, method, expectedValues="pearson")
              
              .bigr.covcor(x, type="cov", method)
          }
)

setGeneric("cor")
setMethod("cor", signature(x = bigr.env$FRAME_CLASS_NAME),
          function(x, y = NULL, use = "complete.obs", method = c("pearson")) {
              logSource <- "cor"
              
              .bigr.checkParameter(logSource, y, expectedValues=NULL)
              .bigr.checkParameter(logSource, use, expectedValues="complete.obs")
              .bigr.checkParameter(logSource, method, expectedValues="pearson")
              
              .bigr.covcor(x, type="cor", method)
          }
)

setGeneric("var")
setMethod("var", signature(x = bigr.env$FRAME_CLASS_NAME),
          function(x, y = NULL, na.rm = T, use) {
              logSource <- "var"
              
              if (missing(use))
                  use <- "complete.obs"

              .bigr.checkParameter(logSource, y, expectedValues=NULL)
              .bigr.checkParameter(logSource, use, expectedValues="complete.obs")
              
              .bigr.covcor(x, type="cov", "pearson")
          }
)

setGeneric("mean")
setMethod("mean", signature(x = bigr.env$FRAME_CLASS_NAME),
function (x, trim = 0, na.rm = T, ...) {               
    logSource <- "mean"
    
    .bigr.checkParameter(logSource, trim, expectedValues=0)  # Trimmed means not supported yet
    
    # Compute means
    f <- paste("mean(", colnames(x), ")", sep="", collapse=" + ")
    f <- paste(f, "~ .", sep="")
    f <- as.formula(f)
    means <- summary(x, f)
    colnames(means) <- colnames(x)
    means <- t(means)
    means[,1]
})

setGeneric("sd")
setMethod("sd", signature(x = bigr.env$FRAME_CLASS_NAME),
          function (x, na.rm = T) {               
              logSource <- "sd"
              
              # Compute sds
              f <- paste("sd(", colnames(x), ")", sep="", collapse=" + ")
              f <- paste(f, "~ .", sep="")
              f <- as.formula(f)
              sds <- summary(x, f)
              colnames(sds) <- colnames(x)
              sds <- t(sds)
              sds[,1]
          })

###################################################################################
### DOCUMENTATION for mean and sd
###################################################################################

#' Calculate the mean and standard deviation of a bigr.vector, or columns of a 
#' bigr.frame. When called on bigr.vector objects, the underlying datatype of 
#' the object must be numeric. Similarly, when called on bigr.frame objects, all
#' columns must be numeric.
#' 
#'@section Usage: 
#'  \code{mean(x, trim = 0, na.rm = TRUE, ...)}
#'  
#'  \code{sd(x, na.rm = TRUE)}
#'  
#' NOTE: Unlike the identically-named R functions that operate on vector and 
#' data.frame objects, these functions do not consider rows or elements with NA 
#' values. Any "na.rm" parameter specification is ignored by these functions.
#' 
#' @name Mean and standard deviation
#' @title mean, sd
#' @param x An object of class bigr.frame or bigr.vector
#' @rdname mean_sd
#' @family mean_sd
NULL

#' See \code{\link{Mean and standard deviation}}
#' @name mean
#' @title mean
NULL

#' See \code{\link{Mean and standard deviation}}
#' @name sd
#' @title sd
NULL

###################################################################################
### DOCUMENTATION for var, cov, cor
###################################################################################

#' These functions compute the variance, covariance and correlation matrices
#' respectively.
#' 
#'@section Usage: 
#'  \code{var(x, y = NULL, na.rm = TRUE)}
#'  
#'  \code{cov(x, y = NULL, use = "complete.obs", method = "pearson")}
#'  
#'  \code{cor(x, y = NULL, use = "complete.obs", method = "pearson")}
#'
#' \code{var} computes the variance of a bigr.vector, or of columns in a 
#' bigr.frame When called on bigr.vector objects, the underlying datatype of the
#' object must be numeric.
#' 
#' \code{cov} and \code{cor} compute the covariance and correlation matrices 
#' between columns of a specified bigr.frame. All columns of the specified 
#' bigr.frame object must be numeric.
#' 

#'
#' NOTE: Unlike the identically-named R functions that operate on vector and 
#' data.frame objects, these functions do not consider rows or elements with NA 
#' values. var() ignores the "na.rm" parameter specification. cov() and cor()
#' implicitly assume the "use" parameter to be "complete.obs", and
#' "method" to be "pearson".
#' 
#' @name Variance, Covariance and Correlation
#' @title var, cov, cor
#' @param x An object of class bigr.frame or bigr.vector
#' @rdname var_cov_cor
NULL

#' See \code{\link{Variance, Covariance and Correlation}}
#' @name var
#' @title var
NULL

#' See \code{\link{Variance, Covariance and Correlation}}
#' @name cov
#' @title cov
NULL

#' See \code{\link{Variance, Covariance and Correlation}}
#' @name cor
#' @title cor
NULL


