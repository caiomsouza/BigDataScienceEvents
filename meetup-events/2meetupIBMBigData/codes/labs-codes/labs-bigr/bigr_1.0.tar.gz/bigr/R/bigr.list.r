#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' Class bigr.list
#'
#' The bigr.list is basically a proxy to a list of bigr.object categorized by groups.
#' On BigInsights cluster, this is saved in a delimited file with following format:
#' header: groupColumnName : character, chunk : character   (for example: airline, chunk)
#' content: groupColumnValue : character | integer | numeric, objectSnippet : character
#' The bigr.list supports show(), head(), $, [[, as.list() methods
#'
#' @section Slots:
#'  \describe{
#'      \item{\code{groupColumns}:}{\code{"numeric"} values specifying the number of groups}
#'  }

#' @name bigr.list
#' @rdname bigr.list
#' @exportClass bigr.list
setClass(bigr.env$LIST_CLASS_NAME,
    representation(
        groupColumns = "numeric"
    ), contains = bigr.env$DATASET_CLASS_NAME
)    

#' The constructor of class bigr.list
#'
#' @param dataSource
#' @param dataPath
#' @param delimiter
#' @return the initialized bigr.list
#' @keywords internal
setMethod("initialize", bigr.env$LIST_CLASS_NAME,
    function(.Object, dataSource, dataPath, delimiter="", groupColumns, envs) {
        logSource <- "bigr.list::initialize"
        bigr.info(logSource, "Initializing bigr.list...")
        
        .Object <- bigr.dataset.constructor(.Object, dataSource, dataPath, delimiter, header=FALSE, envs=envs)
        
        # Check required parameter
        if (missing(groupColumns)) {
            bigr.err(logSource, "Argument groupColumns is required...")
        }

        # validate dataPath
        if (!.bigr.validFilename(dataPath)) {
            bigr.err(logSource, "Invalid dataPath value is provided...")
        }

        # Validate number of groups
        bigr.info(logSource, "Validating parameter...")
        if (groupColumns <= 0) {
            bigr.err(logSource, "Invalid groupColumns value is provided, number of groups must be > 0...")
        }
        .Object@groupColumns = groupColumns

        # Read from the file and construct the bigr.list
        .Object <- .bigr.list.read(.Object)
        if (!is.null(.Object@tableExpression)) {
            logfile <- paste(dirname(dataPath), "/R.log", sep="")
            logcols <- rep("group", groupColumns)
            logcols <- paste(logcols, seq_along(logcols), sep="")
            logcols <- c("status", logcols, "logfile")
            logtypes <- rep("character", groupColumns+2)
            .Object@logInfo <- list(logfile, logcols, logtypes)
            bigr.info(logSource, bigr.env$LIST_CLASS_NAME %++% " was successfully intitialized")
            return(.Object)
        } else {
            bigr.err(logSource, "Count not generate read expression")
        }
    }
)

#' indexing the bigr.list object
#' @param x the bigr.list object
#' @param i, j, ... the group name (or NA) of the grouping column for the object
#' @return bigr.list object
setGeneric("[")
setMethod("[", bigr.env$LIST_CLASS_NAME,
    function(x, i, j, ...) {
        logSource <- "bigr.list::["
        bigr.info(logSource, "Get the element of the list by indexing...")

        tempsys <- sys.call()
        arglist <- as.list(tempsys)
        arglist <- arglist[-c(1,2)]
        len <- length(arglist)
        
        # no argument
        if (0 == len) {
            # show the whole object
            return (x)
        }

        if (x@groupColumns < len) {
            bigr.err(logSource, "The object only has " %++% x@groupColumns %++% " grouping columns.")
        }
        
        # check every argument
        for (argpos in c(1:len)) {
            # only accept character or NA
            v <- arglist[[argpos]]
            if (!missing(v)) {
                v <- eval(v, envir=sys.frame(sys.parent()))
                sapply(v, function(x) {if(!is.na(x) && ("character" != class(x)))
                                          bigr.err(logSource, "Parameter has invalid class: Expected 'character', specified '" %++% class(x) %++% "'")
                                      })
            }
        }
        
        genConnector <- FALSE
        filter <- NULL
        argpos <- 1
        while (argpos <= len) {
            v <- arglist[[argpos]]
            if (missing(v)) {
                # nothing to process, consider the whole columns to be included
            }
            else {
                if (TRUE == genConnector) {
                    # a first filter factor has been generated
                    filter <- filter %++% " and "
                }
                v <- eval(v, envir=sys.frame(sys.parent()))
                if (1 == length(v)) {
                    filter <- filter %++% .bigr.list.getEqualFilter(x, argpos, v)
                }
                else {
                    # this is the case with a vector c()
                    # TODO: I'd like to change the filter of multiple values to use the 'in' clause
                    # such as: p->filter ($[0] in ["98755","94555"]) and ([$[1]] == [null]);
                    k <- 1
                    filter <- filter %++% "(("
                    while (k <= length(v)) {
                        if (k > 1) {
                            filter <- filter %++% ") or ("
                        }
                        filter <- filter %++% .bigr.list.getEqualFilter(x, argpos, v[[k]])
                        k <- k + 1
                    }
                    filter <- filter %++% "))"
                }
                genConnector <- TRUE
            }
            argpos <- argpos + 1
        } # while
        
        if (is.null(filter)) {
            return(x)
        }
        else if ("" == filter) {
            # the whole bigr.list object is returned
            bigrList <- x
        }
        else {
            # update the tableExpression and return the object
            bigrList <- x
            bigrList@tableExpression <- "(" %++% x@tableExpression %++% "-> filter " %++% filter %++% ")"         
        }
        return(bigrList)
    }
)

#' Return the bigr.object of the specified group, this only works with one grouping column
#'
#' @param x the bigr.list object
#' @param name the name of the grouping column
#' @return the bigr.list
setGeneric("$")
setMethod("$", bigr.env$LIST_CLASS_NAME,
    function(x, name) {
        logSource <- "bigr.list::$"
        bigr.info(logSource, "Return the bigr.list for the group " %++% name)
        
        if (missing(name)) {
            bigr.err(logSource, "Must provide a valid group name of the bigr.list object...")
        }
        
        # return err if the groupColumns is greater than 1
        if (x@groupColumns > 1) {
            bigr.err(logSource, "this method only works when there is one grouping column...")
            return (NULL)
        }
            
        # Check for null input parameters
        if (is.null(x) || is.null(name) || ("character" != class(name))) {
            bigr.err(logSource, "Cannot apply projection for invalid parameters...")            
            return(NULL)
        }
            
        # Convert NA
        if ("NA" == name) {
            name <- NA
        }
            
        if (is.bigr.connected()) {
            # Check that the given group value is defined
            groupvalues <- .bigr.list.getGroupValues(x)
            if (!(name %in% groupvalues[,1])) {
                bigr.err(logSource, "Group value '" %++% name %++% "' is not defined")
                return(NULL)
            }
              
            # return a bigr.list for the group value
            # data is not pulled from the cluster yet
            bigrList <- x
            if (is.na(name)) {
                bigrList@tableExpression <- "(" %++% x@tableExpression %++% "->filter [$[0]] == [null])"
            }
            else {
                bigrList@tableExpression <- "(" %++% x@tableExpression %++% "->filter $[0] == '" %++% name %++% "')"
            }
              
            return(bigrList)
        }
    }
)

# Return the length of the bigr.list
# TODO: figure out how to cache the length value
setGeneric("length")
setMethod("length", bigr.env$LIST_CLASS_NAME,
    function(x) {
        logSource <- "bigr.list::length"
        bigr.info(logSource, "get the group count...")
        if (is.bigr.connected()) {
            groupCount <- .bigr.getCachedCount(x)
            if (is.null(groupCount)) {
                n <- x@groupColumns
                jaqlExpression <- "bigrListGetGroupCount(" %++% x@tableExpression %++% ", " %++% n %++% ")"
                groupCount <- .bigr.execQuery(jaqlExpression)[[1]]
                bigr.env$COUNT_CACHE[[x@tableExpression]] <- groupCount
            }
            
            if (!is.null(groupCount)) {
                return(groupCount)
            }
            else {
                return (-1)
            }
        }
        return(-1)
    }
)    

#' Return the groupvalues of the bigr.list
#'
#' @param x the bigr.list object
#' @return the vector of all the grouping columns for the bigr.list object
setGeneric("names")
setMethod("names", bigr.env$LIST_CLASS_NAME,
    function(x) {
#        logSource <- "bigr.list::names"
#        bigr.info(logSource, "get the group names...")
#        if (is.bigr.connected()) {
#            return(.bigr.list.getGroupValues(x))
#        }
#        return(NULL)
        return(dimnames(x))
    }
)    

# R function to get all the dim names in one grouping column
.bigr.list.getDimname <- function(x, nth) {
    logSource <- ".bigr.list.getDimname"
    bigr.info(logSource, "get dim name...")
    if (missing(nth)) {
        bigr.err(logSource, "not enough number of arguments...")
    }
    jaqlExpression <- "bigrListGetDimname(" %++% x@tableExpression %++% ", " %++% nth %++% ")"
    gv <- .bigr.execQuery(jaqlExpression)
    if (0 == nrow(gv)) {
        return (NULL)
    }
    gv <- gv[[1]]
    if (any(gv == "true", na.rm=TRUE) || any(gv == "false", na.rm=TRUE)) {
        return(sapply(as.list(gv), toupper))
    }
    return(as.list(gv))
}

#' Return the dimmension names of the bigr.list object
#'
#' @param x the bigr.list object
#' @return the dimmesion names
setGeneric("dimnames")
setMethod("dimnames", bigr.env$LIST_CLASS_NAME,
    function(x) {
        logSource <- "bigr.list::dimnames"
        bigr.info(logSource, "get the dimnames...")
        if (is.bigr.connected()) {
            groups <- c(1:x@groupColumns)
            func <- function(nth) {
                gv <- .bigr.list.getDimname(x, nth)
            }
            gn <- rep("group", x@groupColumns)
            gn <- paste(gn, seq_along(gn), sep="")
            dn <- as.data.frame(sapply(groups, func), stringsAsFactors=F)
            if (0 == nrow(dn)) {
                bigr.err(logSource, "Invalid bigr.list object.")
            }
            names(dn) <- gn
            for (nm in names(dn)) eval(parse(text=paste("dn$", nm, "<-unlist(dn$", nm, ")", sep="")))
            functxt <- rep("group", x@groupColumns)
            functxt <- paste(functxt, seq_along(functxt), sep="")
            functxt <- paste("dn$", functxt, sep="", collapse=", ")
            functxt <- paste("dn[order(", functxt, "),,drop=FALSE]")
            dn <- eval(parse(text=functxt))
            row.names(dn) <- seq_len(nrow(dn))
            return(dn)
        }
    }
)

#' Displays the data and metadata from the given bigr.list
#'
#' @param x the bigr.list object
#' @return show the dimnames for the bigr.list object as well as the
#'         struct of the bigr.list
#' @keywords internal
setMethod("show", bigr.env$LIST_CLASS_NAME,
    function(object) {
        logSource <- "bigr.list::show"
        bigr.info(logSource, "show the bigr.list...")
        if (!is.null(object)) {
            cat(bigr.env$LIST_CLASS_NAME %++% "\n")
            capture.output({logs <- bigr.logs(object)})
            tryCatch({
                dn <- dimnames(object)
            })
            mp <- merge(dn, logs[, -grep("^logfile$", names(logs)), drop=FALSE])
            show(mp)
        }
    }
)

#' Displays the data and metadata from the given bigr.list
#'
#' @param x the bigr.list.object
#' @return show the dimnames for the bigr.list object as well as the
#'         struct of the bigr.list
#' @rdname print_frame
setMethod("print", bigr.env$LIST_CLASS_NAME,
    function(x, ...) {
        logSource <- "bigr.list::print"
        bigr.info(logSource, "print the bigr.list...")
        if (length(list(...)) > 0) {
            bigr.err(logSource, "unused argument(s)")
        }                      
        show(x)
    }
)

#' pull the object from the cluster to R client
#' 
#' @param x the bigr.list 
#' @param i the ith object in the bigr.list
#' @return the real R object saved in the bigr.list
#' @keywords internal
.bigr.list.pull <- function(x, i) {
    # retrieve the native object
    # retrieve the filename of the stored object
    jaqlExpression <- x@tableExpression %++% "[0][" %++% x@groupColumns %++% "]"
    fn <- .bigr.execQuery(jaqlExpression)[[1]]
    if (is.null(fn)) {
        bigr.err(logSource, "Failed to retrieve the filename of the object...")
    }
    
    # read the object file
    jaqlExpression <- "bigrPullObject('" %++% dirname(x@dataPath) %++% "', '" %++% fn %++% "')"
    lines <- .bigr.execQuery(jaqlExpression)
    if (is.null(lines)) {
        bigr.err(logSource, "Invalid data received from BigInsights server...")
    }
    lines <- lines[[1]]
    tf <- tempfile()
    tfile <- file(tf, open="wb")
    txt <- write.table(lines, file=tfile, quote=FALSE, row.names=FALSE, na="", col.names=FALSE)
    close(tfile)
        
    # read the RDS file
    sv <- readRDS(tf)
    unlink(tf)
    return (sv)  
}

#' pull the object from the cluster to R client
#' 
#' @param x the bigr.list object
#' @return the real R object saved in the bigr.list or the list of R objects
bigr.pull <- function(x) {
    logSource <- "bigr.pull"
    bigr.info(logSource, "retrieve the object from server to R client...")
    l <- list()
    l <- as.list(x)
    if (1 == length(x)) {
        return (l[[1]])
    }
    else
    {
        return (l)
    }
}

# Returns all the objects for the bigr.list
.bigr.list.getAllObjects <- function (x) {
    logSource <- ".bigr.list.getAllObjects"
    bigr.info(logSource, "put all objects into a vector...")
    df <- NULL
    if (!is.null(x)) {
        if (is.bigr.connected()) {
            conv <- FALSE
            for (i in 1:length(x)) {
                m <- bigr.pull(x[i])
                
                # TODO: we will need to make data.frame accept the function data type,
                # so that the model "lm" type can be added
                # for now, I will have to convert this model into a string so that it
                # can be saved in the data.frame
                if (!(class(m) %in% c("numeric", "character", "factor", "list", "matrix", "data.frame")) &&
                        ("function" == class(get(class(m))))) {
                    m <- base64encode(serialize(m, connection=NULL, ascii=FALSE))
                    conv <- TRUE
                }
                
                df <- rbind(df, m)
            }
            row.names(df) <- seq_len(length(x))
            if (conv) {
                colnames(df) <- "object"
            }
        }
    }
    return(df)
}

#' Convert the bigr.list object to a R list
#'
#' @param x the bigr.list object
#' @return the list representation of the bigr.list object
setGeneric("as.list")
setMethod("as.list", signature=bigr.env$LIST_CLASS_NAME,
    function(x, ...) {
        logSource <- "bigr.list::as.list"
        bigr.info(logSource, "convert the bigr.list to list...")
        bigr.info(logSource, "retrieve the object from server to R client...")
        
        if (missing(x)) {
            bigr.err(logSource, "Argument x is required...")
        }
        
        # Check for null input parameters
        if (is.null(x)) {
            bigr.err(logSource, "Cannot apply projection for null parameters")
            return(NULL)
        }
        
        plist <- list()
        
        if (is.bigr.connected()) {
            pnames <- c()
            for (i in c(1:length(x))) {
                ithObj <- .bigr.list.getObject(x,i)
                plist[i] <- list(.bigr.list.pull(ithObj))
                tn <- as.character(dimnames(ithObj))
                if (ithObj@groupColumns > 1) {
                    tn <- paste(tn, sep="", collapse=",")
                }
                pnames <- c(pnames, tn)
            }
            names(plist) <- pnames
        }
        return(plist)
    }
)

# R function to get the ith object from the bigr.list 
.bigr.list.getObject <- function(x, i) {
    logSource <- ".bigr.list.getObject"
    bigr.info(logSource, "retrieve the ith object from the bigr.list...")
    obj <- x
    i <- i - 1
    obj@tableExpression <- "[" %++% obj@tableExpression %++% "[" %++% i %++% "]]"
    return (obj)
}

# R function to return all group values within a bigr.list object
.bigr.list.getGroupValues <- function(x) {
    logSource <- ".bigr.list.getGroupValues"
    bigr.info(logSource, "retrieve the group values for the bigr.list...")
    jaqlExpression <- "bigrListGetGroupValues(" %++% x@tableExpression %++% ", " %++% x@groupColumns %++% ")"
    ct <- rep("character", x@groupColumns)
    groupvalues <- .bigr.executeJaqlQuery(jaqlExpression, coltypes=ct, limit=F)
    cv <- function(x) {
        if (identical(x, "null")) {
            return (NA)
        }
        else if (identical(x, "false") || identical(x, "true")) {
            return (toupper(x))
        }
        return (x)
    }
    gv <- apply(groupvalues, c(1,2), FUN="cv")
    return(as.data.frame(gv, stringsAsFactors=F))
}

# Build the filter logic
.bigr.list.getEqualFilter <- function(x, pos, v) {
    logSource <- ".bigr.list.getEqualFilter"
    bigr.info(logSource, "construct the filter...")
    filter <- NULL
    n <- pos - 1
    if (is.na(v)) {
        filter <- "([$[" %++% n %++% "]] == [null])"
    }
    else if (is.character(v)) {
        filter <- "($[" %++% n %++% "] == "
        if (("TRUE" == v) || ("FALSE" == v)) {
            v <- tolower(v)
        }
        filter <- filter %++% "'" %++% v %++% "')"
    }
    else {
        bigr.err(logSource, "unknown data type...")
    }
    filter
}

# Retrieve all values from one group column
.bigr.list.getOneGroup <- function(x, nth) {
    logSource <- ".bigr.list.getOneGroup"
    bigr.info(logSource, "get one group values...")
    
    if (is.bigr.connected()) {
        jaqlExpression <- x@tableExpression %++% "->bigrListGetOneGroup(" %++% nth %++% ")"
        gv <- .bigr.execQuery(jaqlExpression)
        return(gv)
    }
}

#' Save the bigr.list object to a persistent directory
#'
#' @param x the bigr.list object
#' @param path the persistent directory path
#' @param filename the persistent filename for the csv file
#' @return NULL or new bigr.list on the persist files
.bigr.list.persist <-   function(x, path, filename) {
    logSource <- ".bigr.list.persist"
    bigr.info(logSource, "Move the bigr.list object to a persist path...")
        
    if (missing(path)) {
        bigr.err(logSource, "Argument path must be specified...")
    }
        
    if (is.null(path)) {
        bigr.err(logSource, "Argument path is invalid...")
    }
        
    if (missing(filename)) {
        fn <- path %++% "/" %++% basename(x@dataPath)
    }        
    else {
        if (is.null(filename)) {
            bigr.err(logSource, "Argument filename is invalid...")
        }
        fn <- path %++% "/" %++% filename
    }

    # check whether the datapath is the same as the original one
    if (fn == x@dataPath) {
        bigr.err(logSource, 
                sprintf("Source and target datasets cannot be identical: source@dataPath = %s, target@dataPath = %s ", 
                        x@dataPath, fn))
    }
    
    if (is.bigr.connected()) {
        # retrieve the current directory path for the bigr.list
        dn <- dirname(x@dataPath)
            
        # build the schema
        schema <- rep("string", x@groupColumns)
        schema <- paste("group", seq_along(schema), ":", schema, sep="", collapse=", ")
        schema <- "schema {" %++% schema %++% ", data : string}"
        
        # write to file on BigInsights server
        jaqlExpression <- x@tableExpression %++% "->write(del('" %++% fn %++% "', schema=" %++% schema %++% ", quoted=false))"
        jaqlRet <- .bigr.execQuery(jaqlExpression)
        if (is.null(jaqlRet)) {
            bigr.err(logSource, "Failed to write the file on BigInsights server...")
            return (NULL)
        }
            
        # get all associated object filenames
        jaqlExpression <- x@tableExpression %++% "[*][" %++% x@groupColumns %++% "]"
        objfns <- .bigr.execQuery(jaqlExpression)[[1]]
        if (is.null(objfns)) {
            bigr.err(logSource, "Failed to retrieve data from BigInsights server...")
        }
            
        # copy object files over
        copyObj <- function(x) {
            e <- "hdfsShell('-cp " %++% dn %++% "/" %++% x %++% " " %++% path %++% "')"
            je <- .bigr.execQuery(e)
            if (0 > je) {
                return (FALSE)
            }
            return (TRUE)
        }
        jaqlRet <- sapply(objfns, copyObj)
        if (any(jaqlRet == FALSE)) {
            return (NULL)
        }
        
        # get all associated log filenames
        capture.output({logfns <- basename(bigr.logs(x)$"logfile")})
        logfns[length(logfns)+1] <- "R.log"
        
        # coopy log files over
        jaqlRet <- sapply(logfns, copyObj)
        if (any(jaqlRet == FALSE)) {
            return (NULL)
        }
        
        # get the new bigr.list object
        blist <- new(bigr.env$LIST_CLASS_NAME, dataSource = bigr.env$TEXT_FILE, dataPath=fn, groupColumns=x@groupColumns, envs = list())
        # update the loginfo in the object
        if (is.null(blist)) {
            return (NULL)
        }
        blist@logInfo <- x@logInfo
        blist@logInfo[1] <- dn %++% "/" %++% "R.log"
        return (blist)
    }
}