#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# bigr.list.io
#
# This file contains functions to handle I/O operations to read/write
# from different sources (e.g., BigSQL, text files, etc.)
# to generate a bigr.list
#

# TODO: should this merge with the bigr.io.r as a generic dataset support
# functions?

# Read from the data source accordingly
.bigr.list.read <- function(bl) {
    logSource <- ".bigr.list.read"
    exp <- NULL
    if (bl@dataSource == bigr.env$TEXT_FILE) {
        exp <- .bigr.list.readTextToArray(bl)
    } else if (bl@dataSource == TRANSFORM) {
        exp <- TRUE # Nothing should be read
    } else {
        bigr.err(logSource, "Invalid data source: '" %++% dataSource %++% "'")
    }
    bl@tableExpression <- exp
    return(bl)
}

# Returns the schema to read from the bigr.list server file
.bigr.list.getInputSchema <- function(bl) {
    logSource <- ".bigr.list.getInputSchema"
    if (is.null(bl)) {
        bigr.err(logSource, "Cannot read from a NULL object")
    }
    bigr.info(logSource, "get the input schema of the bigr.list server file...")
    groups <- toString(rep("string? ", bl@groupColumns))
    sc <- "schema [" %++% groups %++% ", string]"
    return (sc)
}

# Reads a character-delimited file from HDFS as an array of array
.bigr.list.readTextToArray <- function(bl) {
    logSource <- ".bigr.list.readTextToArray"
    if (is.null(bl)) {
        bigr.err(logSource, "Cannot read from a NULL object")
        return(NULL)
    }    
    bigr.info(logSource, "Reading from '" %++% bl@dataPath %++% "'...")
    
    # Read on the cluster
    sc <- .bigr.list.getInputSchema(bl)
    jaqlExpression <- "(sc = " %++% sc %++% ", bigrListReadTextToArray('" %++% bl@dataPath %++% "', false" %++% ", sc))"
    bigr.info(logSource, jaqlExpression)
    return(jaqlExpression)
}
