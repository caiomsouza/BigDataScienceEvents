#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# bigr.init.r
# 
# This file contains initialization code that must be run AFTER all bigr sources are loaded
# but BEFORE the user executes any BigR function/method.

################
# Set row limit
################

bigr.setRowLimit(bigr.env$DEFAULT_ROW_LIMIT)


###############################
# Register customized functions
###############################

if (2 == 2) {
    bigr.registerFn(rName="mod", jaqlName="mod", argNames=c("x", "y"), argTypes=c("numeric", "numeric"), returnType="numeric", fnEnv=environment())
    bigr.registerFn(rName="pow", jaqlName="pow", argNames=c("x", "y"), argTypes=c("numeric", "numeric"), returnType="numeric", fnEnv=environment())
   
    bigr.registerFn(rName="bigr.random", jaqlName="random01", 
                    returnType="numeric", is.generic=FALSE, fnEnv=environment())
    
    bigr.registerFn(rName="bigr.sampleRNG", jaqlName="sampleRNG",
                    argNames=c("rng"),
                    argTypes=c("character"),
                    returnType="numeric", is.generic=FALSE, fnEnv=environment())
    bigr.registerFn(rName="bigr.sample01RNG", jaqlName="sample01RNG",
                    argNames=c("rng"),
                    argTypes=c("character"),
                    returnType="numeric", is.generic=FALSE, fnEnv=environment())
    
    bigr.registerFn(rName="as.bigr.integer", jaqlName="asbigrinteger", argNames="x", argTypes="ANY",
                    returnType="integer", is.generic=FALSE, fnEnv=environment())
    bigr.registerFn(rName="as.bigr.numeric", jaqlName="asbigrnumeric", argNames="x", argTypes="ANY",
                    returnType="numeric", is.generic=FALSE, fnEnv=environment())
    bigr.registerFn(rName="as.bigr.character", jaqlName="asbigrcharacter", argNames="x", argTypes="ANY",
                    returnType="string", is.generic=FALSE, fnEnv=environment())
    
    ### String functions ###
    bigr.registerFn(rName="bigr.nchar", jaqlName="strLen", argNames="x", argTypes="character", 
                    returnType="integer", is.generic=FALSE, fnEnv=environment())
    bigr.registerFn(rName="toupper", jaqlName="strToUpperCase", argNames="x", argTypes="character", 
                    returnType="character", is.generic=TRUE, fnEnv=environment())
    bigr.registerFn(rName="tolower", jaqlName="strToLowerCase", argNames="x", argTypes="character", 
                    returnType="character", is.generic=TRUE, fnEnv=environment())
    bigr.registerFn(rName="bigr.grepl", jaqlName="bigrgrepl", 
                    argNames=c("pattern", "x"), 
                    argTypes=c("character", "character"),
                    returnType="logical", is.generic=TRUE, fnEnv=environment())
    bigr.registerFn(rName="bigr.gsub", jaqlName="bigrgsub", 
                    argNames=c("pattern", "replacement", "x"), 
                    argTypes=c("character", "character", "character"),
                    returnType="character", is.generic=TRUE, fnEnv=environment())
    bigr.registerFn(rName="substring", jaqlName="substring", 
                    argNames=c("text", "first", "last"), 
                    argTypes=c("character", "numeric", "numeric"),
                    returnType="character", is.generic=TRUE, fnEnv=environment())
    bigr.registerFn(rName="substr", jaqlName="substring", 
                    argNames=c("x", "start", "stop"), 
                    argTypes=c("character", "numeric", "numeric"),
                    returnType="character", is.generic=TRUE, fnEnv=environment())
}

#
# FIXME: These methods don't belong here. Adarsh needs to move them
# elsewhere, and clean/unit test these. Pardon the uncleanliness.
# If I dont get these into the code soon, I'll lose these. -Adarsh
setMethod("as.character", signature(x = "bigr.vector"), function (x, ...) {
    as.bigr.character(x)
})

setMethod("as.numeric", signature(x = "bigr.vector"), 
          function (x, ...) {
              as.bigr.numeric(x)
          })

setMethod("as.integer", signature(x = "bigr.vector"), 
          function (x, ...) {
              as.bigr.integer(x)
          })

setMethod("as.logical", signature(x = "bigr.vector"), 
          function (x, ...) {
              return (ifelse(x %in% c("T", "TRUE", "true"), T,
                             ifelse(x %in% c("F", "FALSE", "false"), F, NA)))
          })

setMethod("toString", signature(x = "bigr.vector"), 
          function (x, ...) {
              as.bigr.character(x)
          })

setGeneric("grepl")
setMethod("grepl", signature(pattern = "bigr.vector", x = "character"),
          function (pattern, x, ignore.case = FALSE, perl = FALSE, fixed = FALSE, useBytes = FALSE) {
              bigr.grepl(pattern, x)
          })

setGeneric("grepl")
setMethod("grepl", signature(pattern = "character", x = "bigr.vector"),
          function (pattern, x, ignore.case = FALSE, perl = FALSE, fixed = FALSE, useBytes = FALSE) {
              bigr.grepl(pattern, x)
          })

setGeneric("sub")
setMethod("sub", signature(pattern = "ANY", replacement = "ANY", x = "bigr.vector"), 
          function (pattern, replacement, x, ignore.case = F, perl = F, fixed = F, useBytes = F) {
              bigr.gsub(pattern, replacement, x)
          })

setGeneric("gsub")
setMethod("gsub", signature(pattern = "ANY", replacement = "ANY", x = "bigr.vector"), 
          function (pattern, replacement, x, ignore.case = F, perl = F, fixed = F, useBytes = F) {
              bigr.gsub(pattern, replacement, x)
          })

setMethod("nchar", signature(x = "bigr.vector"), 
          function (x, type = "chars", allowNA = FALSE) {
              bigr.nchar(x)
          })

bigr.registerRNG <- function(rng, seed) {
    logSource <- "bigr.registerRNG"
    if (missing(rng))
        bigr.err(logSource, "Missing argument: 'rng'");
    if (missing(seed))
        bigr.err(logSource, "Missing argument: 'seed'");
    if (! is.character(rng))
        bigr.err(logSource, "Argument'rng' needs to be a character.");
    if (! is.numeric(seed))
        bigr.err(logSource, "Argument'seed' needs to be an integer / numeric");
    
    query <- sprintf("registerRNG('%s', fn() %d); true;", rng, as.integer(seed));
    df <- .bigr.executeJaqlQuery(jaqlExpression = query,
                                colnames="col1", coltypes="logical", limit=FALSE);
    return (df[1,1])
}

#bigr.sample01RNG <- function(rng) {
#    logSource <- "bigr.sample01RNG"
#    random <- as.vector(.bigr.sample01RNG(rng))
#    if (is.na(random))
#        bigr.warn(logSource, "Random number not generated. Check if bigr.registerRNG() has been called.")
#    return (random)
#}
#
#bigr.sampleRNG <- function(rng) {
#    logSource <- "bigr.sampleRNG"
#    random <- as.vector(.bigr.sampleRNG(rng))
#    if (is.na(random))
#        bigr.warn(logSource, "Random number not generated. Check if bigr.registerRNG() has been called.")
#    return (random)
#}
#
#bigr.random <- function(seed) {
#    if (! missing(seed)) {
#        bigr.registerRNG(bigr.env$DEFAULT_RNG, seed)
#        bigr.env$DEFAULT_RNG_INITED <- T
#    }
#    
#    if (! bigr.env$DEFAULT_RNG_INITED) {
#        seed <- as.integer(runif(1, 1, 1e6))
#        bigr.registerRNG(bigr.env$DEFAULT_RNG, seed)
#        bigr.env$DEFAULT_RNG_INITED <- T
#    }
#    
#    return(bigr.sample01RNG(bigr.env$DEFAULT_RNG))
#}
#
#bigr.set.seed <- function(seed) {
#    logSource <- "bigr.set.seed"
#    
#    if (! is.numeric(seed)) {
#        bigr.err(logSource, "Seed must be an integer.")
#    }
#    return(bigr.registerRNG(bigr.env$DEFAULT_RNG, seed))
#}
