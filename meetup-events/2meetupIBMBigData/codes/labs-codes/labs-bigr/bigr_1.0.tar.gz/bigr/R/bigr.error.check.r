#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# bigr.error.check
#
# This file contains methods to validate parameters for all BigR objects.

# This method checks whether a given string is a valid identifier name.
# Supported identifiers cannot start with a digit nor contain special
# characters other than letters, numbers, and the '_' character
.bigr.validIdentifier <- function(x) {
    if (is.null(x) | class(x) != "character") {
        return(FALSE)
    }
    
    # Check if the identifier starts with a digit
    if (substr(x, start=1, stop=1) %in% c("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"))  {
        return(FALSE)
    } else {
        # Since grep may throw an error, a tryCatch block was implemented
        output <- tryCatch({
            
            # Check that the indentifer name only contains letters, numbers or '_'
            if (grep("^[[:digit:][:alpha:]_]*$", x) != 1) {
                return(FALSE)
            } else {
                return(TRUE)
            }
        }, error = function(e) {
            return(FALSE)
        })
    }
    return(output)
}

# This method checks if a given value is a numeric scalar (i.e., not a vector).
.bigr.is.numeric.scalar <- function(x) {
    if (!is.numeric(x)) {
        return(FALSE)
    } else {
        if (!is.vector(x)) {
            return(FALSE)
        } else if (length(x) != 1) {
            return(FALSE)
        }
    }
    return(TRUE)
}

#' Checks that the number of columns can be changed safely.
#'
#' The user can only change the number of columns if (1) headers are not provided 
#' AND colnames/coltypes are the same as default values, or (2) if the query for
#' x triggers an error.
#'
#' In other words, user cannot change the number of columns when headers are provided or        
#' when colnames/coltypes are the same as default values, unless the query for x
#' triggers an error
#' 
#' @param x a bigr.frame
#' @return whether or not the number of columns can be changed
.bigr.canChangeColumnCount <- function(x) {
    if (class(x) != bigr.env$FRAME_CLASS_NAME) {
        return(FALSE)
    }
    
    # If this is the first time assigning coltypes/colnames
    if (.bigr.isNullOrEmpty(x@tableExpression)) {
        return(TRUE)
    }
    
    # If the dataSource is TRANSFORM or BIGSQL, the user should not be
    # able to change the columns.
    if (x@dataSource == bigr.env$TRANSFORM | x@dataSource == bigr.env$BIG_SQL) {
        return(FALSE)
    }
	
	# If colnames are unknown (i.e., the entire frame is being read as a single column)
	if (.bigr.equals(colnames(x), bigr.env$UNKNOWN_COLNAMES)) {
		return(TRUE)
	} else {
		return(FALSE)
	}
    return(TRUE)
}

# Validates the integrity of column names
.bigr.validColnames <- function(colnames) {
    logSource <- ".bigr.validColnames"
    
    # Check for null/empty column names
    if (is.null(colnames) | length(colnames) < 1) {
        bigr.warn(logSource, "colnames cannot be empty: '" %++% colnames %++% "'")
        return(FALSE)
    }    
    if (class(colnames) != "character") {
        bigr.warn(logSource, "colnames must be of type 'character'")
        return(FALSE)
    }    
    
    # Check that column names are valid
    #for (i in 1:length(colnames)) {
    #    if (!.bigr.validIdentifier(colnames[i])) {
    #        bigr.warn(logSource, "Column name '" %++% colnames[i] %++% "' is not valid")
    #        return(FALSE)
    #    }
    #}
    
    # Check that the column names are unique
    #if (anyDuplicated(colnames) != 0) {
    #    bigr.err(logSource, "Column names must be unique")
    #    return(FALSE)
    #}
    return(TRUE)
}
 
# Validates the integrity of column types
.bigr.validColtypes <- function(coltypes) {
    logSource <- ".bigr.validColtypes"
    
    # Check for null/empty column types
    if (is.null(coltypes) | length(coltypes) < 1) {
        bigr.warn(logSource, "Column types cannot be empty")
        return(FALSE)
    }
    
    # Check that coltypes are character values
    if (class(coltypes) != "character") {
        bigr.warn(logSource, "Column types must be of type 'character'")
        return(FALSE)
    }
    
    # Check that the column types are in the list of supported types
    for (i in 1:length(coltypes)) {
        if (is.null(coltypes[i]) | (!(coltypes[i] %in% names(bigr.env$DATA_TYPES)))) {
            bigr.warn(logSource, "Data type '" %++% coltypes[i] %++% "' is not valid")
            return(FALSE)
        }
    }
    return(TRUE)
}

# Validates the integrity of column names
.bigr.validProjectionNames <- function(bf, colnames) {
    logSource <- "validProjectedNames"
    
    # Check for null/empty column names
    if (is.null(colnames) | length(colnames) < 1) {
        bigr.warn(logSource, "colnames cannot be empty: '" %++% colnames %++% "'")
        return(FALSE)
    }
    if (class(colnames) != "character") {
        bigr.warn(logSource, "colnames must be of type 'character'")
        return(FALSE)
    }

    # Check that column names are valid identifiers
    #for (i in 1:length(colnames)) {
    #    if (!.bigr.validIdentifier(colnames[i])) {
    #        bigr.warn(logSource, "Column name '" %++% colnames[i] %++% "' is not valid")
    #        return(FALSE)
    #    } else if (!(colnames[i] %in% bf@colnames)) {
    #        bigr.warn(logSource, "Column name '" %++% colnames[i] %++% "' does not belong to the given bigr.frame")
    #        return(FALSE)
    #    }
    #}
    return(TRUE)
}

##################################################################################
# The following methods are used for the remote execution / JaQL to R invocation #
##################################################################################

# Validates the integrity of filename
# file must exist on the cluster as well
.bigr.validFilename <- function(filename) {
    logSource <- ".bigr.validFilename"

    if (missing(filename)) {
        bigr.err(logSource, "Filename must be specified...")
    }
    
    # filename can't be null/empty
    if (is.null(filename) | length(filename) < 1) {
        bigr.err(logSource, "Filename cannot be empty:  '" %++% filename %++% "'")
        return(FALSE)
    }

    # filename must be a string
    if (class(filename) != "character") {
        bigr.err(logSource, "Filename must be of type 'character'")
        return(FALSE)
    }

    # file must exist on the cluster  
    jaqlExpression <- "hdfsShell('-ls " %++% filename %++% "')"
    existing <- .bigr.execQuery(jaqlExpression)
    if ("-1" == existing[[1]]) {
        return(FALSE)
    }
    return(TRUE)
}
