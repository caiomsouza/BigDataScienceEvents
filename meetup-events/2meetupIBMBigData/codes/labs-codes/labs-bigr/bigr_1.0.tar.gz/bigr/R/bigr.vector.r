#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' Class bigr.vector
#'
#' This class represents a proxy to a unidimensional big data source, which is derived from
#' a column of a bigr.frame. Class \code{bigr.vector} extends from bigr.dataset.
#'
#'@section Slots: 
#'  \describe{
#'    \item{\code{name}:}{\code{"character"} value specifying bigr.vector name}
#'    \item{\code{dataType}:}{;\code{"character"} value specifying the bigr.vector data type, which could be either "character", "logical", "integer" or "numeric"}
#'  }

#' @name bigr.vector
#' @rdname bigr.vector
#' @exportClass bigr.vector
setClass(bigr.env$VECTOR_CLASS_NAME,
    representation(
        name = "character",
        dataType = "character"
    ), contains = bigr.env$DATASET_CLASS_NAME
)

#' Initializes a bigr.vector with the given parameters.
#' @name bigr.vector.initialize
#' @rdname bigr.vector.initialize
#' @param dataSource \code{"character"} value specifying the big data source. It could be either
#' BIG_SQL or TEXT.
#' @param dataPath \code{"character"} value specifying the big data location.
#' @param name the vector column name
#' @param dataType the vector column type.
#' @return the initialized bigr.vector
#' @keywords internal
setMethod("initialize", bigr.env$VECTOR_CLASS_NAME, 
    function(.Object, dataSource, dataPath="", name=bigr.env$DEFAULT_COLNAMES, dataType=bigr.env$DEFAULT_COLTYPES, envs) {
        logSource <- "init-bigr.vector"
        bigr.info(logSource, "Initializing bigr.vector...")
        
        # Invoke the constructor of class bigr.dataset
        .Object <- bigr.dataset.constructor(.Object, dataSource=dataSource, dataPath=dataPath, envs=envs)
        
        # Validate name and type
        if (.bigr.isNullOrEmpty(name)) {
            .Object@name <- bigr.env$DEFAULT_COLNAMES
        } else {
            .Object@name <- name
        }
        if (.bigr.isNullOrEmpty(dataType)) {
            .Object@dataType <- bigr.env$DEFAULT_COLTYPES
        } else {
            .Object@dataType <- dataType        
        }        
        bigr.info(logSource, "<OK>")
        return(.Object)
    }
)

#' This function downloads the contents of a bigr.vector into an R vector.
#' Since R vectors are held in memory, ensure that you have enough memory
#' on your system to accommodate the contents.
#' 
#' @title Download data from the server into a vector
#' @param x a bigr.vector
#' @return a vector containing the data in the bigr.vector
#' @seealso \link{as.data.frame}
#' @examples \dontrun{
#' 
#' carriers <- as.vector(air$UniqueCarrier)
#' 
#' years <- as.vector(unique(air$Year))
#' }

setGeneric("as.vector")
setMethod(f = "as.vector", signature = bigr.env$VECTOR_CLASS_NAME, definition = 
    function(x) {
        if (is.null(x)) {
            return(NULL)
        }
        name <- x@name
        vector <- .bigr.executeJaqlQuery(.bigr.getJaqlExpression(x), colnames=x@name, 
                                         coltypes=x@dataType, limit=FALSE)[,x@name]
        if (x@dataType == "numeric" || x@dataType == "integer") {
            return(as.numeric(vector))
        } else if (x@dataType == "logical") {
            return(as.logical(vector))
        } else {
            return(vector)
        }        
    }
)

#' Displays a slice of a bigr.vector
#'
#' @param x a bigr.vector
#' @return NULL
#' @rdname show_vector
#' @keywords internal
setMethod(f = "show", signature = bigr.env$VECTOR_CLASS_NAME, definition = 
    function(object) {
        if (!is.null(object)) {
            df <- .bigr.executeJaqlQuery(.bigr.getJaqlExpression(object), colnames=object@name,
                                         coltypes=object@dataType)
            if (!is.null(df)) {
                if (nrow(df) > 0) {
                    vector <- df[,object@name]
                    if (object@dataType == "numeric" || object@dataType == "integer") {
                        vector <- as.numeric(vector)
                    } else if (object@dataType == "logical") {
                        vector <- as.logical(vector)
                    }
                    # Show the contents of the bigr.vector as a vector
                    show(vector)
                    
                    # Get the row count from the cache
                    len <- .bigr.getCachedCount(object)
                    
                    # Show the count only if it is cached
                    if (bigr.getRowLimit() > 0) {
                        if (is.null(len)) {
                            if (length(vector) == bigr.getRowLimit()) {
                                cat("... " %++% " showing first " %++% bigr.getRowLimit() %++% " observations only.\n")
                            }
                        } else {
                            if (len > bigr.getRowLimit()) {
                                cat("... " %++% (len - bigr.getRowLimit()) %++% " more observations.\n")
                            }
                        }
                    }
                } else {
                    cat("bigr.vector(0).\n")
                }
            }
        }
    }
)

#' Displays a slice of a bigr.frame
#'
#' @param x a bigr.vector
#' @return NULL
#' @rdname print_frame
setGeneric("print")
setMethod(f = "print", signature = bigr.env$VECTOR_CLASS_NAME, definition = 
              function(x, ...) {
                  logSource <- "print"
                  if (length(list(...)) > 0) {
                      bigr.err(logSource, "unused argument(s)")
                  }                      
                  show(x)
              }
)

# Returns the number elements of a bigr.vector
setGeneric("length")
setMethod("length", signature(x = bigr.env$VECTOR_CLASS_NAME),
    function(x) {
        # RStudio often calls the length() function on objects saved away in the
        # If we don't have a connection and raise an error, that messes things up. 
        # Let's try this simple approach.
        if (! is.bigr.connected()) return("<not connected>")
        return(.bigr.count(x))
    }
)

# This method does not apply to bigr.vectors
setGeneric("nrow")
setMethod("nrow", signature(x = bigr.env$VECTOR_CLASS_NAME),
    function(x) {
        return(NULL)
    }
)

# This method does not apply to bigr.vectors
setGeneric("ncol")
setMethod("ncol", signature(x = bigr.env$VECTOR_CLASS_NAME),
    function(x) {
        return(NULL)
    }
)

#' Computes some basic statistics on the given bigr.vector
#'
#' If the given \code{bigr.vector} is character, the counts for each category
#' will be computed. Otherwise, for numeric \code{bigr.vector}'s max, min, and
#' quartiles will be calculated.
#' @param x a \code{bigr.vector}
#' @return a \code{vector} with the statistics calculated from the \code{bigr.vector}
#' @rdname summary_vector
#' @keywords internal
setGeneric("summary")
setMethod(f = "summary", signature = bigr.env$VECTOR_CLASS_NAME, definition = 
    function(object) {                         
        type <- object@dataType
        result <- NULL
        if (type == "character" | type == "logical") {
            df <- bigr.distinctCounts(object)            
            result <- df[, 2]
            names(result) <- df[, 1]
            if (nrow(df) == bigr.getRowLimit()) {
                cat("Showing first " %++% bigr.getRowLimit() %++% " categories only: \n")
            }
        } else if (type == "numeric" | type == "integer") {
			df <- bigr.quartiles(object)
            df$Mean <- mean(object)
            result <- t(df)[, 1]
            names(result) <- colnames(df)
            result <- sort(result)            
        }        
        return(result)
    }
)

#' Computes the set of distinct values in a given bigr.vector
#'
#' @param x a \code{bigr.vector}
#' @return a \code{vector} with the distinct values of \code{x}
setGeneric("unique")
setMethod("unique", signature(x = bigr.env$VECTOR_CLASS_NAME),
    function(x) {
        result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource = bigr.env$TRANSFORM, envs=x@envs)
        result@name <- "unique(" %++% x@name %++% ")"
        result@dataType <- x@dataType
        result@tableExpression <- .bigr.getJaqlExpression(x) %++% " -> unique()"
        result@columnExpression <- ""
        return(result)
    }
)

#' Sorts a \code{bigr.vector} in increasing or decreasing order.
#' @param x a \code{bigr.vector}
#' @param decreasing a boolean value indicating whether the bigr.vector should be sorted
#' in decreasing order.
#' @return a \code{vector} with the sorted elements of \code{x}
setGeneric("sort")
setMethod("sort", signature(x = bigr.env$VECTOR_CLASS_NAME),
    function(x, decreasing) {
        result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource = bigr.env$TRANSFORM, dataPath = "", 
                      name=x@name, dataType=x@dataType, envs=x@envs)
        result@columnExpression <- ""
        
        if (decreasing) {
            result@tableExpression <- .bigr.getJaqlExpression(x)  %++% " -> sort by [$ desc]"
        } else {
            result@tableExpression <- .bigr.getJaqlExpression(x)  %++% " -> sort by [$]"
        }
        return(result)
    }
)

#' Computes a contingency table for the given bigr.vector. This is nothing
#' but the set of distinct values (i.e., categories), along with the
#' number of occurrences of each category.
#'
#' @param x a \code{bigr.vector}
#' @return a \code{vector} with the contingency table of \code{x}
setGeneric("table")
setMethod("table", definition = 
    function (..., exclude, useNA, dnn, deparse.level) {
        logSource <- "table"
        args <- list(...)
        if (length(args) > 1) {
            bigr.err(logSource, "Only a 'bigr.vector' was expected but extra arguments were found.")
        }
        x <- args[[1]]
        if (class(x) != bigr.env$VECTOR_CLASS_NAME) {
            return(callNextMethod())
        }
        #if (x@dataType == "character" | x@dataType == "logical") {
            df <- bigr.distinctCounts(x)
            result <- df[, 2]
            names(result) <- df[, 1]        
            return(result)    
        #} else {
        #    bigr.err(logSource, "Cannot calculate contingency table for numeric columns")
        #    return(NULL)
        #}
    }
)

#' Displays the structure of a bigr.vector including column name and type, along with a
#' data slice and the total number of elements.
#' @param x a bigr.vector
#' @return NULL
#' @rdname str_vector
#' @keywords internal
setGeneric("str")
setMethod(f = "str", signature = bigr.env$VECTOR_CLASS_NAME, definition = 
    function(object) {
        if (!is.null(object)) {
            cat(bigr.env$VECTOR_CLASS_NAME %++% ": " %++% length(object) %++% " observations")
          
        vector <- as.vector(head(object))
        ellipsis <- FALSE
        # Add ellipsis (i.e., "...") if there are more rows than shown
        if (length(object) > bigr.env$DEFAULT_HEAD_ROWS) {
            ellipsis <- TRUE
        } 
        # Get the first elements for each column
        if (object@dataType == "character") {
            vector <- '"' %++% vector %++% '"'
        }
        firstElements <- paste(vector, collapse = " ")

        # Concatenate the colnames, coltypes, and first elements
        cat("\n $ " %++% object@name %++% "\t: " %++% object@dataType %++% " " %++% firstElements)
        if (ellipsis) {
            cat("...")
        }
        cat("\n")
      }
  }
)
