#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# bigr.log.r
#
# This file contains functions to log different types of messages. 
# Three types are currently supported: info, warning, and error.
# At the moment, all messages go to the screen. In each function,
# the logging source (i.e., where the method comes from) should be 
# specified.

#' Specifies the logging level for BigR.
#'
#' The Log level is used to determine which messages are printed to the
#' screen and which ones are not. Three values are provided: ERR_LOG_LEVEL,
#' WARN_LOG_LEVEL, and INFO_LOG_LEVEL, corresponding to error messages, warnings,
#' and information messages. Combinations of these values can also be
#' set using the operator +. For instance, WARN_LOG_LEVEL + INFO_LOG_LEVEL
#' means that warning and information messages will be printed, but no
#' error messages will be generated.
#' 
#' @param logLevel an integer value with the log level
#' @return a logical value indicating whether the new log level was successfully applied
#' @keywords internal
bigr.setLogLevel <- function(logLevel) {
    logSource <- "setLogLevel"
    if (.bigr.isNullOrEmpty(logLevel) | !.bigr.is.integer(logLevel)) {
        bigr.err(logSource, "Invalid log level")
        return(FALSE)
    }
    if (logLevel >= 0 & logLevel <= bigr.env$ERR_LOG_LEVEL + bigr.env$WARN_LOG_LEVEL + bigr.env$INFO_LOG_LEVEL) {
        bigr.env$LOG_LEVEL <- logLevel
        return(TRUE)
    } else {
        bigr.err(logSource, "Invalid log level")
        return(FALSE)
    }
}

#' Sets the logging level to verbose, which means that all messages will be
#' displayed.
#' 
#' @keywords internal
bigr.setVerbose <- function() {
    bigr.setLogLevel(bigr.env$ERR_LOG_LEVEL + bigr.env$INFO_LOG_LEVEL + bigr.env$WARN_LOG_LEVEL)
}

#' A synonym for bigr.setVerbose and bigr.setDefaultLogLevel
#' @param x a boolean value indicating whether debug messages should be displayed.
#' @keywords internal
bigr.debug <- function(x) {
    logSource <- "bigr.debug"
    if (.bigr.isNullOrEmpty(x)) {
        bigr.err(logSource, "Invalid debug option")
    }
    if (x == TRUE) {
        invisible(bigr.setVerbose())
    } else if (x == FALSE) {
        invisible(bigr.setDefaultLogLevel())
    }
}

#' Sets the logging level to the default, which means that only error messages will be
#' displayed.
#' 
#' @keywords internal
bigr.setDefaultLogLevel <- function() {
    bigr.setLogLevel(bigr.env$DEFAULT_LOG_LEVEL)
}

# Prints an error message and stops the code execution generating an R error.
bigr.err <- function(source, message) {
    if (missing(source)) {
        source <- ""
    }
    if (missing(message)) {
        message <- ""
    }
    if (.bigr.isNullOrEmpty(message)) {
        message <- ""
    }
    if (.bigr.isNullOrEmpty(source)) {
        source <- ""
    }
    errBit <- bigr.env$LOG_LEVEL %% 2
    stop("BigR[" %++% source %++% "]: " %++% message, call. = FALSE)
    if (errBit == 1) {
        # Log code here
        #cat("\n")
    }
}

# Prints a warning message
bigr.warn <- function(source, message) {
    if (missing(source)) {
        source <- ""
    }
    if (missing(message)) {
        message <- ""
    }    
    warnBit <- trunc(bigr.env$LOG_LEVEL / 2) %% 2
    if (warnBit == 1) {
        warning("WARN[" %++% source %++% "]: " %++% message, call. = F)
    }
}

# Prints an information message
bigr.info <- function(source, message) {
    if (missing(source)) {
        source <- ""
    }
    if (missing(message)) {
        message <- ""
    }    
    infoBit <- trunc(bigr.env$LOG_LEVEL / 4) %% 2
    if (infoBit == 1) {
        if (length(message) == 1) {        
            cat("DEBUG[" %++% source %++% "]: " %++% message)
            cat("\n")
        } else {
            cat("DEBUG[" %++% source %++% "]: [vector]: " %++% paste(message, collapse=", "))
        }
    }
}

# Prints an important information message regardless of the logging level
bigr.infoUser <- function(source, message) {
    if (missing(source)) {
        source <- ""
    }
    if (missing(message)) {
        message <- ""
    }    
    if (length(message) == 1) {        
        cat("INFO[" %++% source %++% "]: " %++% message)
        cat("\n")
    } else {
        cat("INFO[" %++% source %++% "]: [vector]: " %++% paste(message, collapse=", "))
    }
}

bigr.infoShow <- function(source, message) {
    if (missing(source)) {
        source <- ""
    }
    if (missing(message)) {
        message <- ""
    }    
    infoBit <- trunc(bigr.env$LOG_LEVEL / 4) %% 2
    if (infoBit == 1) {
        cat("INFO[" %++% source %++% "]: ")
        show(message)
    }
}
