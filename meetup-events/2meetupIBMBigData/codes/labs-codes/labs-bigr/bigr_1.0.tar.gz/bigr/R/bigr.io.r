#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# bigr.io
#
# This file contains functions to handle I/O operations to read/write
# from different sources (e.g., BigSQL, delimited (text) files, etc.) 

# This method reads a big.frame from the corrsponding data source. It returns
# a table expression as a JaQL query.
.bigr.read <- function(bf) {
    logSource <- "read"
    exp <- NULL    
    if (bf@dataSource == bigr.env$TEXT_FILE) {
        bigr.info(logSource, "Reading a text file...")
        
        # Check that the file exists
        if (!.bigr.fileExists(bf@dataPath)) {
            bigr.err(logSource, "File '" %++% bf@dataPath %++% "' does not exist in HDFS.")
        }
        
        # Case 1: Colnames: Yes, Coltypes: Yes, Header: Anything, Delimiter != "\n"
        if (!(bigr.env$UNKNOWN_COLNAMES == colnames(bf)[1])) {
            bigr.info(logSource, '# Case 1: Colnames: Yes, Coltypes: Yes, Header: Anything, Delimiter != "\n"')
            exp <- .bigr.readText(bf)
            
        # Case 2: Colnames: No, Coltypes: Anything, Header: Yes, Delimiter != "\n"
        } else if ((bigr.env$UNKNOWN_COLNAMES == colnames(bf)[1]) & (bf@header==TRUE)) {
            bigr.info(logSource, 'Case 2: Colnames: No, Coltypes: Anything, Header: Yes, Delimiter != "\n"')
            headers <- .bigr.getHeaderNames(bf)
            if (.bigr.validColnames(headers)) {
                bf@colnames <- headers
                
                # If coltypes were not specified, default coltypes will be used 
                if (length(bf@coltypes) <= 1) {
                    bf@coltypes <- rep(bigr.env$DEFAULT_COLTYPES, length(headers))    
                }                
                
                # Invoke method to read a text file into a JaQL array
                exp <- .bigr.readText(bf)
            }
        # Case 3: Colnames: No, Coltypes: Anything, Header: No, Delimiter != "\n"
        } else if ((bigr.env$UNKNOWN_COLNAMES == colnames(bf)[1]) & (bf@header==FALSE) & (bf@delimiter != "\n")) {
            bigr.info(logSource, '# Case 3: Colnames: No, Coltypes: Anything, Header: No, Delimiter != "\n"')
            headers <- .bigr.getHeaderNames(bf)            
            if (!.bigr.isNullOrEmpty(headers)) {
                
                # Since colnames were not specified, default coltypes will be used 
                bf@colnames <- rep("V", length(headers)) %++% seq(1:length(headers))
                
                # If coltypes were not specified, default coltypes will be used 
                if (length(bf@coltypes) <= 1) {
                    bf@coltypes <- rep(bigr.env$DEFAULT_COLTYPES, length(headers))    
                }                
                
                # Invoke method to read a text file into a JaQL array
                exp <- .bigr.readText(bf)
            } else {
                # If something went wrong with the headers, read as lines
                exp <- .bigr.readText(bf)
            }
        # Case 4: Colnames: No, Coltypes: Anything, Header: No, Delimiter: No
        } else if ((bigr.env$UNKNOWN_COLNAMES == colnames(bf)[1]) & (bf@header==FALSE) & .bigr.isNullOrEmpty(bf@delimiter)) {
            bigr.info(logSource, "4. No colnames/coltypes, no headers, no delimiter, or delimiter == '\n'. Reading lines...")
            exp <- .bigr.readTextLines(bf)
        }
    } else if (bf@dataSource == bigr.env$BIG_SQL) {
        bigr.info(logSource, "Reading from BigSQL...")
        readlist <- .bigr.readBigSQL(bf)     
        # Set the column name and column types
        exp <- readlist$tableExpression
        bf@colnames <- readlist$colnames
        bf@coltypes <- readlist$coltypes
    } else if (bf@dataSource == bigr.env$LINE_FILE) {
        bigr.info(logSource, "Reading lines...")
        exp <- .bigr.readTextLines(bf)
    } else if (bf@dataSource == bigr.env$TRANSFORM) {
        # No need to read when TRANSFORM
        exp <- ""
    } else {
        bigr.err(logSource, "Invalid data source: '" %++% bf@dataSource %++% "'")
    }
    bf@tableExpression <- exp
    return(bf)
}

.bigr.readText <- function(bf) {
    if (class(bf) == bigr.env$FRAME_CLASS_NAME) {
        if (!.bigr.isNullOrEmpty(bf@delimiter)) {
            if (bf@delimiter != "\n") {
                .bigr.readTextToArray(bf)
            } else {
                .bigr.readTextLines(bf)
            }
        }
    }
}
    
# Returns the header names for a given bigr.frame by reading from  the file
# For this purpose we have two steps:
# 1. Read the first line and count, to get the number of columns
# 2. Read the first line and pass coltypes=rep("character", ncols), so executeJaqlQuery
# returns the headers as separate columns
# This needs to be done since headers could contain "," or delimiter characters and function
# bigr.jdbc.query returns everything as a single column appended with commas
.bigr.getHeaderNames <- function(bf) {
    logSource <- ".bigr.getHeaderNames"    
    
    # Get the number of columns
    dfCount <- .bigr.executeJaqlQuery("(read(del('" %++% bf@dataPath %++% "',quoted=true, ddquote=true, delimiter='" %++% bf@delimiter %++% "')) -> top 1)[0] -> count()", limit=FALSE)    
    if (is.null(dfCount) | nrow(dfCount) < 1 | .bigr.isNullOrEmpty(bf@delimiter)) {
        bigr.err(logSource, "Could not read headers. The dataset is empty / inaccessible, or delimiter was not set")
    } else {
        ncols <- as.integer(dfCount[[1]])
        bigr.info(logSource, "Ncols:" %++% ncols)
        
        # Get the header using coltypes as characters
        dfHeaders <- .bigr.executeJaqlQuery("read(del('" %++% bf@dataPath %++% "',quoted=true, ddquote=true, delimiter='" %++% bf@delimiter %++% "')) -> top 1", limit=FALSE, coltypes=rep("character", ncols))
        #headerStr <- gsub("\\s","", headerStr)
        headers <- as.character(dfHeaders[1, ])
        
        bigr.infoShow(logSource, headers)
        return(headers)
    }
}

# This method generates the JaQL query to read a character-delimited file from 
# HDFS as an array of arrays. If the read was not successful, it returns NULL
.bigr.readTextToArray <- function(bf) {
    logSource <- "readTextToArray"
    bigr.info(logSource, "Reading text file...");
    if (is.null(bf)) {
        bigr.err(logSource, "Cannot read from a NULL bigr.frame")
        return(NULL)
    }    
    bigr.info(logSource, "Generating reading expression for '" %++% bf@dataPath %++% "'...")
    
    bigr.info(logSource, "colnames: ")
    bigr.info(logSource, paste(bf@colnames, collapse=","))
    bigr.info(logSource, "coltypes:")
    bigr.info(logSource, paste(bf@coltypes, collapse=","))
    
    # Map R types to Jaql types
    jaqlTypes <- bf@coltypes
    dataNames <- names(bigr.env$DATA_TYPES)
    for (i in 1:length(bigr.env$DATA_TYPES)) {
        jaqlTypes <- replace(jaqlTypes, jaqlTypes == dataNames[i], bigr.env$DATA_TYPES[i])
    }
    
    # Choose between read or localRead accordingly
    readInstruction <- "read"
    if (bf@localProcessing == TRUE) {
        readInstruction <- "localRead"
    }
    
    jaqlExpression <- NULL
    # Handle NA string
    if (!.bigr.isNullOrEmpty(bf@na.string)) {
    
        # Build JaQL expression with all field as strings
        stringTypes <- rep("string", length(bf@coltypes))    
        jaqlExpression <- readInstruction %++% "(del(location='" %++% bf@dataPath %++%
            "', delimiter='" %++% bf@delimiter %++% "', inoptions={header:" %++% tolower(bf@header) %++% "},quoted=true,schema=schema [" %++% 
            paste(stringTypes %++% "?", collapse=", ") %++% "] ))"    
        
        # Recode NA's as null values
        jaqlExpression <- jaqlExpression %++% " -> transform replaceNAs($, '" %++% bf@na.string %++% "')"
        
        # Assign the corresponding datatypes after NA's have been recoded
        i <- 1
        dataTypeExpression <- ""
        while (i <= length(bf@coltypes)) {
            if (jaqlTypes[i] != "string") {
                column <- jaqlTypes[i] %++% "($[" %++% (i - 1) %++% "])"
            } else {
                column <- "($[" %++% (i - 1) %++% "])"
            }        
            dataTypeExpression <- dataTypeExpression %++% column
            
            # All but the last one have comma at the end
            if (i < length(bf@coltypes)) {
                dataTypeExpression <- dataTypeExpression %++% ", "
            }
            i <- i + 1
        }
        jaqlExpression <- jaqlExpression %++% " -> transform [" %++% dataTypeExpression %++% "]"       
    } else {
        jaqlExpression <- readInstruction %++% "(del(location='" %++% bf@dataPath %++%
            "', delimiter='" %++% bf@delimiter %++% "', inoptions={header:" %++% tolower(bf@header) %++% "},quoted=true,schema=schema [" %++% 
            paste(jaqlTypes %++% "?", collapse=", ") %++% "] ))"  
    }
    bigr.info(logSource, jaqlExpression)    
    return(jaqlExpression)
}

# This method generates the JaQL query to read a file from 
# HDFS as an array of lines. If the read was not successful, it returns NULL
.bigr.readTextLines <- function(bf) {
    logSource <- "readDel"
    if (is.null(bf)) {
        bigr.err(logSource, "Cannot read from a NULL bigr.frame")
    }    
    bigr.info(logSource, "Generating read expression for '" %++% bf@dataPath %++% "'...")
    
    readInstruction <- "read"
    if (bf@localProcessing) {
        readInstruction <- "localRead"
    }    
    jaqlExpression <- readInstruction %++% "(lines(location='" %++% bf@dataPath %++% "'))"
 
    bigr.info(logSource, jaqlExpression)
    return(jaqlExpression)
}

# Checks whether a file exists in HDFS
.bigr.fileExists <- function(filePath) {
    if (.bigr.isNullOrEmpty(filePath)) {
        return(FALSE)
    }
    result <- .bigr.executeJaqlQuery("ls('" %++% filePath %++% "')", limit=FALSE)
    if (.bigr.isNullOrEmpty(result)) {
        return(FALSE)
    }
    if (length(result) != 1) {
        return(FALSE)
    }
    if (is.na(result[1,1])) {
        return(FALSE)
    }
    return(TRUE)
}

# Read from BigSQL
.bigr.readBigSQL <- function(bf) {
    logSource = "readBigSQL"

    if (is.null(bf)) {
        bigr.err(logSource, "Cannot read from a NULL bigr.frame")
        stop()
    }

    # Determine the columns of the table, if it exists
    cols <- bigr.listColumns(bf@dataPath, expand=F)
    if (is.null(cols) | nrow(cols) == 0) {
        bigr.err(logSource, sprintf("Cannot find table '%s'.", bf@dataPath))
    }
    
    # Only select columns whose datatypes map to R
    colidx <- cols$type %in% bigr.env$DATA_TYPES
    if (length(colidx[colidx == FALSE]) > 0) {
        bigr.warn(logSource, "Cannot map all column datatypes to R. The following columns have been omitted: ")
        bigr.warn(logSource, paste(cols$name[!colidx], collapse=", "))
    }
    
    # Return the table expression and column metadata
    if (grepl("^sys", bf@dataPath)) {
        # For catalog tables (i.e. tables starting with "sys", build a slightly
        # different JaQL expression. We have no way of specifying "localProcessing"
        # for such tables, but there's no harm done as catalog tables are typically
        # smaller than regular tables.
        qry <- sprintf("(select * from %s) -> transform [ %s ]",
                       bf@dataPath, paste(c("$."), cols$name[colidx], sep="", collapse=", "))
    }
    else {
        qry <- sprintf("%s(hcatTable('%s')) -> transform [ %s ]",
                       ifelse(bf@localProcessing, "localRead", "read"),
                       bf@dataPath, paste(c("$."), cols$name[colidx], sep="", collapse=", "))
    }
    
    numdec <- cols$type %in% c("numeric", "decimal")
    if (any(numdec)) {        
        # Turn JaQL numeric / decimal columns into JaQL doubles. This is a workaround as we're not
        # able to deal with those column types directly. (See Defect #50818)
        qry <- sprintf("%s -> transform [ %s ]", qry,
                       paste(ifelse(numdec, "double(", ""), 
                             "$[",
                             0:(length(numdec)-1),
                             "]",
                             ifelse(numdec, ")", ""),
                             sep="",
                             collapse=", "))
    }
    
    colnames <- cols$name[colidx]
    pos <- match(cols$type[colidx], bigr.env$DATA_TYPES)
    coltypes <- names(bigr.env$DATA_TYPES)[pos]
    
    return (list(tableExpression=qry, colnames=colnames, coltypes=coltypes))
}

# This method allows to write a dataset with the specified output parameters.
.bigr.write <- function(dataset) {
    logSource <- ".bigr.write"
    
    # Missing/invalid parameter validation
    if (missing(dataset)) {
        dataset <- NULL
    }
    
    # If the dataset is to be exported as a text file
    if (dataset@dataSource == bigr.env$TEXT_FILE) {
        .bigr.writeToTextFile(dataset)
    }
}

# This method exports a bigr.dataset to a text file in HDFS
.bigr.writeToTextFile <- function(dataset) {    
    logSource = "writeDel"
    if (is.null(dataset)) {
        bigr.err(logSource, "Cannot write a NULL bigr.frame")    
    }
    if (class(dataset) != bigr.env$FRAME_CLASS_NAME & class(dataset) != bigr.env$VECTOR_CLASS_NAME) {
        bigr.err(logSource, "Writing to HDFS is only supported for bigr.frame's and bigr.vector's")    
    }
    
    # The JaQL statement with the data to be written
    datasetJaqlExpr <- NULL
    
    # The writing command, either write or localWrite
   writeCommand <- "localWrite"    
    if (dataset@localProcessing == FALSE) {
        writeCommand <- "write"
    }
    
    colnames <- NULL
    coltypes <- NULL
    if (class(dataset) == bigr.env$FRAME_CLASS_NAME) {
        colnames <- dataset@colnames
        coltypes <- dataset@coltypes
    }
    if (class(dataset) == bigr.env$VECTOR_CLASS_NAME) {
        colnames <- dataset@name
        coltypes <- dataset@dataType
    }
    
    # Build the JaQL update to write to HDFS
    jaqlExpr <- .bigr.getJaqlExpression(dataset) %++% " -> " %++% writeCommand %++% "(del(location='" %++% 
        dataset@dataPath %++% "', delimiter='" %++% dataset@delimiter %++% "', quoted=true" %++%
        ", schema=" %++% .bigr.jaql.getSchema(colnames, coltypes) %++%
        ", outoptions={header:" %++% tolower(dataset@header) %++% "}))"
    
    # Return the result of the JaQL query
    if (length(.bigr.executeJaqlQuery(jaqlExpr, limit=FALSE)) > 0) {
        return(TRUE)
    } else {
        return(FALSE)
    }
}

# Write a bigr.frame to HDFS
.bigr.writeToBigSQL <- function(bf) {
    logSource = "writeBigSQL"
    if (is.null(bf)) {
        bigr.err(logSource, "Cannot read from a NULL bigr.frame")
        stop()
    }
    bigr.err(logSource, "Writing to BigSQL is not supported")
    return(NULL)
}
