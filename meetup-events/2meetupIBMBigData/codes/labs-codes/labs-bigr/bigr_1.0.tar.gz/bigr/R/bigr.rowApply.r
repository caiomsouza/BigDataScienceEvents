#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' \code{rowApply} partitions its input into batches of rows, and applies an 
#' R function to each batch. The batching of the data and execution of the 
#' functions all happen on the server and results are retained on the server 
#' as well. Big R attempts to assign the same # of rows to each batch. In 
#' some cases, however, the number of rows in a batch may be less than the 
#' requested number. This can happen when a batch happens to be the last one 
#' in an "input split."
#' 
#' The semantics of rowApply() make it an ideal for scenarios wherein one 
#' wants to loosely partition data, and each row is generally independently 
#' processed by the user-specified R function. On application that fits this 
#' profile involves "model scoring".
#' 
#' To process the batches, an instance of R is invoked for each batch and 
#' data from the batch is passed to R. The function is invoked on the data 
#' and results are consolidated. Depending on the configuration of the 
#' underlying cluster, the batches can be processed in parallel on different 
#' nodes of the cluster. Unlike \code{groupApply}, results generated from 
#' \code{rowApply} are always tabular. The user-supplied R function is 
#' expected to return a data.frame, and tabular data from all batches is 
#' consolidated and presented as a bigr.frame. Big R needs to know the shape 
#' of the output, and this information can be provided via an input 
#' "signature".
#' 
#' @section Configuration:
#'   
#'   Unlike groupApply, rowApply contructs the batches (i.e. partitions) in 
#'   the Hadoop "mappers". How many partitions will be actually run 
#'   concurrently depends on the configuration of the underlying cluster. 
#'   Specifically, the options "mapred.map.tasks" and 
#'   "mapred.tasktracker.map.tasks.maximum" play a big role. A user can set 
#'   these settings from Big R itself. Depending on how long your R functions
#'   are designed to run, there may be a need to increase the MapReduce 
#'   timeout via "mapred.task.timeout".
#'   
#'   In the current implementation, rowApply first constructs the batches in 
#'   memory inside the JaQL environment, and then passes the batches to R. As
#'   such, one ought to set the 'numRowsPerBatch' carefully. Too high a
#'   number may case MapReduce jobs to run out of memory. Too low a number
#'   will spawn a large # of R instances (i.e. one per batch) and increase
#'   execution overhead.
#'   
#' @section Error handling and diagnostics:
#'   
#'   rowApply can fail for several reasons. The most common error scenario 
#'   faced by beginning users is when the R interpreter or the "bigr" package
#'   itself are not properly installed on all data nodes of the BigInsights 
#'   cluster. In addition, rowApply may also fail if any of the underying 
#'   MapReduce jobs fail to execute. Should any of these events happen, 
#'   rowApply issues a stack trace that describes the symptoms of the 
#'   problem. In some cases, it may be necessary to examine the Big SQL 
#'   server logs (bigsql.log) to obtain additional information on the 
#'   problems. Should there be a problem in executing MapReduce jobs, it may 
#'   be necessary to examine the job logs via services such as Hadoop 
#'   JobTracker.
#'   
#'   In many cases, one or more instance of the user-specified R function 
#'   raise errors. These errors, along with all output that the R function(s)
#'   may produce on stdout and stderr, are captured. These can be accessed by
#'   bigr.logs().
#'   
#' @title Partitioned execution via batches of rows
#' @param data bigr.frame object
#' @param rfunction function to apply to each partition
#' @param signature a data.frame that has the same structure as the return 
#'   value of "rfunction".
#' @param numRowsPerBatch Indicates the # of rows per batch. In some cases, 
#'   the # of rows in the batch may be less that this parameter.
#' @param ... (optional) parameters that are passed to 'rfunction'
#' @return a bigr.frame.
#' @seealso \link{bigr.logs}, \link{bigr.frame}, 
#'   \link{bigr.set.server.options}
#' @examples \dontrun{
#' 
#' # Coming soon ...
#' }
rowApply <- function(data, rfunction, signature, ..., numRowsPerBatch = 10000)
{
    # save the current time
    b4 <- Sys.time()
    
    # require this library for encode/decode
    library("base64enc")
    
    # logging set up
    logSource <- "rowApply"
    bigr.info(logSource, "Start rowApply processing...")
    
    # checking arguments
    .bigr.checkParameter(logSource, data, "bigr.frame")
    .bigr.checkParameter(logSource, rfunction, "function")
    .bigr.checkParameter(logSource, signature, "data.frame")
    .bigr.checkParameter(logSource, numRowsPerBatch, c("integer", "numeric"), isOptional=T)
    
    # Default value of numRowsPerBatch is 10,000
    if (missing(numRowsPerBatch) || is.null(numRowsPerBatch)) {
        numRowsPerBatch <- 10000
    }
    
    # pack the connection credential and the bigr library version/built info to send to R server
    vb <- packageDescription("bigr", fields=c("Version", "Date"))
    scon <- c(bigr.env$CONNECTION@host, bigr.env$CONNECTION@port, bigr.env$CONNECTION@database, 
              bigr.env$CONNECTION@user, bigr.env$CONNECTION@password, vb[[1]], vb[[2]])
    scon <- base64encode(serialize(scon, connection=NULL, ascii=FALSE))
    
    # get the list of the arguments, the first element is the function name
    tempsys <- match.call()
    arglist <- as.list(tempsys)
   
    # get the function name
    streamfunc <- "arg_" %++% deparse(arglist[[1]])

    # get the function body
    rfunction <- deparse(eval(arglist$rfunction))
    rfunction <- base64encode(serialize(rfunction, connection=NULL, ascii=FALSE))

    # send the rfunction to Jaql
    jaqlExpression <- streamfunc %++% "='" %++% rfunction %++% "'"
    .bigr.execUpdate(jaqlExpression)
    
    # generate the argument list
    ignored <- append(1, which(names(arglist) %in% c("data", "rfunction", "signature", "numRowsPerBatch")))

    # the argument list to pass to rfunction
    parmlist <- arglist[-ignored]
    parmlist <- sapply(parmlist, eval)
  
    # serialize the argument list
    bigr.parmlist <- base64encode(serialize(parmlist, connection=NULL, ascii=FALSE))
  
    # send the argument list to Jaql server
    arglistname <- streamfunc %++% "_arglist"
    arglistPair <- arglistname %++% "='" %++% bigr.parmlist %++% "'"
    .bigr.execUpdate(arglistPair)
  
    # generate the warning/error output directory name
    jaqlExpression <- "logdir := bigrGetFilename('/tmp/bigr', 'rowApply', 'd'); logdir"
    logdir <- .bigr.execQuery(jaqlExpression)
    if (is.null(logdir)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # create the logdir TODO: check the error and handle it
    jaqlExpression <- "hdfsShell('-mkdir " %++% logdir %++% "')"
    jaqlret <- .bigr.execQuery(jaqlExpression)
    if (0 > jaqlret) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # the current log filename
    logfile <- logdir %++% "/R.log"
    bigr.env$LOGDIR <- logdir
    bigr.env$LOGFILE <- logfile
    
    # get the colname
    columnNames <- base64encode(serialize(colnames(data), connection=NULL, ascii=FALSE))
    
    # construct the rowApply_rFunc
    sigcheck <- paste(deparse(signature), collapse='')
    rowApply_rFunc <- "rowApply_rFunc=" %++% "bigrGetRFunc_groupRowApply_dataframe('" %++% streamfunc %++% "', '" %++% rfunction %++% "', '" %++% columnNames %++% "', '" %++% arglistname %++% "', '" %++% bigr.parmlist %++% "', '" %++% scon %++% "', '" %++% logdir %++% "', '" %++% sigcheck %++% "')"      
    .bigr.execUpdate(rowApply_rFunc)
    
    # generate the temporary unique output filename
    jaqlExpression <- "csvout := bigrGetFilename(logdir, 'rowApply', 'csv'); csvout"
    csvout <- .bigr.execQuery(jaqlExpression)
    if (is.null(csvout)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }

    # warning that the factors in data.frame will be treated as characters
    if (!is.null(signature) && ("data.frame" == class(signature))) {
        if ("factor" %in% coltypes(signature))
            bigr.warn(logSource, "Factor(s) in signature are implicitly treated as character(s).")
    }
    
    # generate the coltype and colname for the log file
    bigr.env$LOGCOLTYPE <- c("character", "character")
    bigr.env$LOGCOLNAME <- c("status", "logfile")
    
    # build the output schema for the function from the signature passed in
    jaqlType <- sapply(sapply(signature, class), .bigr.getJaqlType)
    jaqlType <- paste("data",seq_along(jaqlType),":",jaqlType,"?",sep="",collapse=", ")
    outSchema <- paste("schema {", jaqlType, "}", sep="")
    
    # generate the input and result schemas for the R external function
    inputSchema <- .bigr.frame.jaqlInputSchema(data)
    resultSchema <- "schema [{status : string, " %++% substring(outSchema, 9, nchar(outSchema) - 1) %++% ", logfile : string}*]"
    
    # retrieve timeout option
    timeout <- getOption("bigr.r.timeout")
    if (is.null(timeout)) {
        timeout <- 180000
    }
    else {
        timeout <- as.numeric(timeout)
        if (is.na(timeout)) {
            timeout <- 180000
        }
    }
    
    jaqlExpression <- "insc = " %++% inputSchema %++% "; outsc = " %++% resultSchema %++% "; rowApply = externalRFn(rFunction=rowApply_rFunc, parameters=insc, result=outsc, timeout=" %++% timeout %++% ")"
    .bigr.execUpdate(jaqlExpression)
    
    # generate log file schema
    logSchema <- "schema {status : string, logfile : string}"

    # ask Jaql to generate the rowApply function
    jaqlExpression <- "bigrGetRowApplyFn(rowApply, " %++% numRowsPerBatch %++% ", csvout, " %++% outSchema %++% ", '" %++% logfile %++% "', '" %++% logSchema %++% "')"
    rowApplyFn <- .bigr.execQuery(jaqlExpression)
    if (is.null(rowApplyFn)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # run the query on the server
    jaqlExpression <- "res = " %++% .bigr.getJaqlExpression(data) %++% "->" %++% as.character(rowApplyFn)
    jaqret <- .bigr.execQuery(jaqlExpression)
    if (is.null(jaqlret)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # Create a environment that holds metadata for any temporary files, and 
    # register a finalizer for it. These files will be removed when the environment
    # cannot be accessed.                        
    e <- new.env(parent = emptyenv())
    e$finals <- logdir
    reg.finalizer(e, .bigr.remove.files)
    envs <- list(e)
    
    # result is put into a bigr.frame and returned 
    result <- new (bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TEXT_FILE, dataPath=as.character(csvout), delimiter=",", colnames=names(signature), 
                   coltypes=sapply(signature, function(x) {if(class(x)=="factor") "character" else class(x)}), header=FALSE, 
                   localProcessing = data@localProcessing, envs = envs)

    if (!is.null(result)) {
        result@logInfo <- list(bigr.env$LOGFILE, bigr.env$LOGCOLNAME, bigr.env$LOGCOLTYPE)
    }

    # log time and print 
    dt <- difftime(Sys.time(), b4); 
    cat("rowApply ran for " %++% round(dt,2) %++% units(dt) %++% "\n");
    
    # return message so that users know what to check
    capture.output({logs <- bigr.logs(result)})
    wlen <- length(grep('Warning', logs[[1]]))
    elen <- length(grep('Error', logs[[1]]))
    if ((wlen > 0) || (elen > 0)) {
        warning(wlen %++% " warnings and " %++% elen %++% " errors encountered. Use bigr.logs() to examine R execution logs.", call.=FALSE)
    }
        
    return (result)
}
