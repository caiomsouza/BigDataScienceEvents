#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------


# Class bigr.frame
#
# This class represents a proxy to a big data source with a bi-dimensional structure.
# Class \code{bigr.frame} extends from \code{bigr.dataset}.
setClass(bigr.env$FRAME_CLASS_NAME,
    representation(
        colnames = "vector",
        coltypes = "vector"
    ), contains = bigr.env$DATASET_CLASS_NAME
)

#' bigr.frame objects are proxies for tabular datasets residing in a 
#' BigInsights cluster. These datasets could be delimited files or tables in 
#' a Big SQL server.
#' 
#' @title Contruct a bigr.frame object
#' @name bigr.frame
#' @rdname bigr.frame
#' @param dataSource (character) Type of data source. Supported sources are 
#'   "DEL" and "BIGSQL"
#' @param dataPath (character) Complete name or path of the dataset
#' @param delimiter (character) Delimiter if dataSource is set to "DEL"
#' @param colnames (character vector) Names of the table columns. If not 
#'   specified and header == TRUE, headers will be used as colnames. If 
#'   neither colnames, coltypes, nor headers are specified, the entire 
#'   dataset will be read as one single character column.
#' @param coltypes (character vector) an array of column types. If not 
#'   specified and header == TRUE, all column types will be 
#'   \code{'character'}. If neither colnames, coltypes, nor headers are 
#'   specified, the entire dataset will be read as one single character 
#'   column.
#' @param header (logical) whether or not the dataset has headers. This only 
#'   applies if dataSource is "DEL"
#' @param na.string (character) if specified, all occurrences of the value of
#'   'na.string' will be interpreted as NA.
#' @param useMapReduce (logical) If set to FALSE, Big R will execute all 
#'   statements on a single-node. This is a low-latency mode that can be very
#'   useful when working with smaller files esp. those that are created by
#'   sampling large datasets.
#' @return a newly created bigr.frame
#' @examples \dontrun{
#' 
#' # Construct a bigr.frame atop a delimited file
#' air <- bigr.frame(dataPath = "airline_demo.csv", 
#'                   dataSource = "DEL", 
#'                   delimiter=",", header = T,
#'                   coltypes = ifelse(1:29 %in% c(9,11,17,18,23), 
#'                                     "character", "integer"),
#'                   useMapReduce = F)
#' 
#' # Construct a bigr.frame over a Big SQL catalog table
#' bfcat <- bigr.frame(dataSource = "BIGSQL", dataPath = "syscat.tables")
#' 
#' # Construct a bigr.frame over a Big SQL user table
#' bfhbase <- bigr.frame(dataSource = "BIGSQL", dataPath = "hbase.emp")
#' 
#' }
bigr.frame <- function(dataSource, 
                       dataPath, 
                       delimiter = ifelse(dataSource == "DEL", ",", ""), 
                       colnames = NULL,
                       coltypes = NULL,
                       header = TRUE,
                       na.string = "", 
                       useMapReduce = FALSE) {
    
    logSource <- "bigr.frame"
    
    # Check parameters
    .bigr.checkParameter(logSource, dataSource, expectedValues=c("DEL", "BIGSQL"))
    .bigr.checkParameter(logSource, dataPath, "character")
    .bigr.checkParameter(logSource, delimiter, "character", isOptional=T)
    .bigr.checkParameter(logSource, colnames, "character", isOptional=T, isNullOK=T, isSingleton=F)
    .bigr.checkParameter(logSource, coltypes, "character", isOptional=T, isNullOK=T, isSingleton=F)
    .bigr.checkParameter(logSource, header, "logical", isOptional=T)
    .bigr.checkParameter(logSource, na.string, "character", isOptional=T, isNullOK=T)
    .bigr.checkParameter(logSource, useMapReduce, "logical", isOptional=T)
    
    if (class(useMapReduce) == "logical" & !.bigr.isNullOrEmpty(useMapReduce)) {
        # Check if the hidden option (bigr.use.map.reduce) is set. If so,
        # it overrides anything the user may have specified. This is only used during Big R
        # testing, and it allows us to gain some predictability in the output.
        useMapReduceOption <- getOption("bigr.use.map.reduce")
        if (! is.null(useMapReduceOption)) {
            useMapReduce <- useMapReduceOption
        }
    } else {
        bigr.err(logSource, "Invalid value for argument 'useMapReduce'.")
    }
    
    bf <- new(bigr.env$FRAME_CLASS_NAME, dataSource, dataPath, delimiter, colnames, coltypes, 
              header, na.string, localProcessing=!useMapReduce, envs = list())
    
    #if (useMapReduce == FALSE) {
    #    bigr.warn(logSource, "Operations on this bigr.frame will not use MapReduce since argument 'useMapReduce' was set to FALSE. " %++%
    #                  "This configuration is only suitable for small datasets.")
    #}
    
    return(bf)
}

setMethod("initialize", bigr.env$FRAME_CLASS_NAME,
    function(.Object, dataSource=NULL, dataPath="", delimiter="", colnames, coltypes, 
             header=FALSE, na.string=bigr.env$DEFAULT_NA_STRING, localProcessing=bigr.env$DEFAULT_LOCAL_PROCESSING,
             envs) {
        logSource <- "initialize(bigr.frame)"
        bigr.info(logSource, "Initializing bigr.frame...")
        
        # Invoke the constructor of class dataset
        .Object <- bigr.dataset.constructor(.Object, dataSource, dataPath, 
                                            delimiter, header, na.string, localProcessing, envs=envs)
        
        # Check required parameters
        if (missing(colnames)) {
            colnames <- NULL
        }
        if (missing(coltypes)) {
            coltypes <- NULL
        }
        
        # If the bigr.frame is the result of a transformation, both
        # colnames and coltypes must be specified
        if (dataSource == bigr.env$TRANSFORM) {
            .Object@colnames <- colnames
            .Object@coltypes <- coltypes
        } else {
            # If both colnames and coltypes are provided, no adjustment is needed
            if (!.bigr.isNullOrEmpty(colnames) & !.bigr.isNullOrEmpty(coltypes)) {
                .Object@colnames <- colnames
                .Object@coltypes <- coltypes
            # If only colnames are not empty, assign colnames and coltypes will be
            # automatically adjusted.
            } else if (!.bigr.isNullOrEmpty(colnames)) {
                bigr.info(logSource, "No coltype information was provided. Adjusting...")
                .Object@colnames <- colnames
                .Object@coltypes <- rep(bigr.env$DEFAULT_COLTYPES, length(colnames))
            # If only coltypes are not empty, assign coltypes and colnames will be NA.
            } else if (!.bigr.isNullOrEmpty(coltypes)) {
                bigr.info(logSource, "No colnames information was provided.")
                .Object@colnames <- rep(bigr.env$UNKNOWN_COLNAMES, length(coltypes))
                .Object@coltypes <- coltypes
            } else {
                # If neither colnames nor coltypes are provided, use default values
                bigr.info(logSource, "No column information was provided. Using defaults...")
                .Object@colnames <- bigr.env$UNKNOWN_COLNAMES
                .Object@coltypes <- bigr.env$DEFAULT_COLTYPES
            }
        }
        
        # Validate column names and types
        if (!.bigr.validColnames(.Object@colnames)) {
            bigr.err(logSource, "Invalid column names.")
        }
        if (!.bigr.validColtypes(.Object@coltypes)) {
            bigr.err(logSource, "Invalid column types.")
        }
        if (length(.Object@colnames) != length(.Object@coltypes)) {
            bigr.err(logSource, "colnames and coltypes must have the same length.")
        }
        
        # Update the JaQL expression of the bigr.frame with the result of the read operation
        .Object <- .bigr.read(.Object)
        if (.bigr.isNullOrEmpty(.Object)) {
            bigr.err(logSource, "Could not read from the specified data source")
        }
        if (!is.null(.Object@tableExpression)) {
            bigr.info(logSource, "<OK>")
            return(.Object)
        } else {
            bigr.err(logSource, "Could not read from the specified data source")
        }        
    }
)

#' With this pair of methods, one can get and set column names of a 
#' bigr.frame.
#' 
#' @name colnames, colnames<-
#' @title Set and get column names
#' @section Usage:
#'   
#'   \code{colnames(x)}
#'   
#'   \code{names(x)}
#'   
#'   \code{colnames(x) <- value}
#'   
#'   \code{names(x) <- value}
#'
#' @param x (bigr.frame)
#' @param value (character) A vector that has the same length as the number
#'   of columns of the bigr.frame
#' @return For \code{colnames}, return a character vector holding the column 
#'   names. For \code{colnames<-}, return an updated object.
#' @rdname colnames_bigrframe
#' @examples \dontrun{
#'   
#' # Get column names 
#' colnames(air)
#'   
#' air2 <- air[air$UniqueCarrier == "DL", c("UniqueCarrier", "Distance")] 
#' colnames(air2) <- c("Code", "Dist")
#' str(air2)
#' }
#' @aliases colnames, names
setGeneric("colnames")
setMethod("colnames", signature(x = bigr.env$FRAME_CLASS_NAME),
    function(x, do.NULL = NULL, prefix = NULL) {
        logSource <- "colnames"
        if (!is.null(do.NULL)) {
            bigr.err(logSource, "Parameter 'do.NULL' is not supported by colnames()")
        }
        if (!is.null(prefix)) {
            bigr.err(logSource, "Parameter 'prefix' is not supported by colnames()")
        }
        return(x@colnames)
    }
)

# Returns the column names for the given bigr.frame
setGeneric("names")
setMethod("names", signature(x = bigr.env$FRAME_CLASS_NAME),
    function(x) {
        colnames(x)              
    }
)

# Sets the column names for the given bigr.frame
setGeneric("colnames<-")
setMethod("colnames<-", signature(x = bigr.env$FRAME_CLASS_NAME),
    function(x, value) {
        logSource <- "colnames<-"
        
        # Check parameter integrity
        if (is.null(x) | (class(x) != bigr.env$FRAME_CLASS_NAME) | 
                (class(value) != "character") | (!.bigr.validColnames(value))) {
            bigr.err(logSource, "Invalid column names.")
        }
        
        # Check if the number of columns can be changed
        if (length(colnames(x)) != length(value)) {
            if (!.bigr.canChangeColumnCount(x)) {
                bigr.err(logSource, "Cannot assign new column names since the number of specified columns (" %++% length(value) %++% ") " %++%
                         "does not match the number of columns in the dataset (" %++% length(colnames(x)) %++% ")")
            }      
        }
        
        oldNcol <- ncol(x)
        newColnames <- value
        
        # If the bigr.frame has not been initialized yet
        if (length(colnames(x)) == 0) {
            x@colnames <- newColnames
            oldNcol <- 0
        }
        
        # If the colnames and coltypes do not have the same length, coltypes will
        # be automatically adjusted using default column types.
        if (length(newColnames) > length(x@coltypes)) {
            # Append default column types to coltypes
            from <- length(x@coltypes) + 1
            to <- length(newColnames)
            for (i in from:to) {
                x@coltypes[i] <- bigr.env$DEFAULT_COLTYPES[1]
            }                
        } else if (length(newColnames) < length(x@coltypes)) {
            # Remove extra coltypes
            newColtypes <- character(length(newColnames))
            for (i in 1:length(newColnames)) {
                newColtypes[i] <- x@coltypes[i]
            }
            x@coltypes <- newColtypes
        }
        x@colnames <- newColnames        
        
        bigr.info(logSource, "colnames after adjustment: ")
        bigr.info(logSource, paste(x@colnames, collapse=","))
        bigr.info(logSource, "coltypes after adjustment: ")
        bigr.info(logSource, paste(x@coltypes, collapse=","))
        
        # If the number of columns have changed, and it is not the first time
        # assigning colnames, the frame must be re-read
        if (oldNcol > 0) {
            if (length(newColnames) != oldNcol) {
                x <- .bigr.read(x)
            }        
        }
        return(x)
    }
)

# Sets the column names for the given bigr.frame
setGeneric("names<-")
setMethod("names<-", signature(x = bigr.env$FRAME_CLASS_NAME),
          function(x, value) {
              colnames(x) <- value
              x
          }
)

#' With this pair of methods, one can get and set column types of a 
#' bigr.frame.
#' 
#' Legal column types are "character", "integer", "numeric" and "logical". 
#' \code{coltypes<-} can only be used to assign types on bigr.frame objects 
#' created directly on delimited files (dataSource = "DEL".) One cannot alter
#' column types of bigr.frames created on Big SQL tables (dataSource = 
#' "BIGSQL"), or of frames that have been derived from other frames.
#' 
#' @name coltypes, coltypes<-
#' @title Set and get column types
#' @section Usage:
#'   
#'   \code{coltypes(x)}
#'   
#'   \code{coltypes(x) <- value}
#'   
#' @param x (bigr.frame)
#' @param value (character) A vector that has the same length as the number
#'   of columns of the bigr.frame
#' @return For \code{coltypes}, return a character vector holding the column 
#'   types. For \code{coltypes<-}, return an updated object.
#' @rdname coltypes_bigrframe
#' @examples \dontrun{
#'   
#' # Get column types 
#' coltypes(air)
#'   
#' # Set column types 
#' coltypes(air) <- ifelse(1:29 %in% c(9,11,17,18,23), 
#'                         "character", "integer")
#'   
#' # Illegal column type assignment on derived big.frame 
#' air2 <- air[air$UniqueCarrier == "DL", c("UniqueCarrier", "Distance")] 
#' coltypes(air2) <- c("character", "numeric")                    # error
#' }
setGeneric("coltypes", function(x) standardGeneric("coltypes"))
setMethod("coltypes", signature(x = bigr.env$FRAME_CLASS_NAME),
    function(x) {
        if ((!is.null(x)) & (class(x) == bigr.env$FRAME_CLASS_NAME)) {
            return(x@coltypes)
        } else {
            return(NULL)
        }
    }
)

# Sets the column types for the given bigr.frame
setGeneric("coltypes<-", function(x, value) standardGeneric("coltypes<-"))
setMethod("coltypes<-", signature(x = bigr.env$FRAME_CLASS_NAME),
    function(x, value) {
        logSource <- "coltypes<-"
        if ((!is.null(x)) & (class(x) == bigr.env$FRAME_CLASS_NAME) & (class(value) == "character") & 
                (.bigr.validColtypes(value))) {        
            # Prevent changing coltypes from a TRANSF bigr.frame
            if (x@dataSource == bigr.env$TRANSFORM & !.bigr.isNullOrEmpty(x@coltypes)) {
                bigr.err(logSource, "Cannot change the column types of a bigr.frame containing the result of a data transformation.")
            }
          
            # Prevent changing coltypes of a BIGSQL bigr.frame
            if (x@dataSource == bigr.env$BIG_SQL & !.bigr.isNullOrEmpty(x@coltypes)) {
                bigr.err(logSource, "Cannot change the column types of a bigr.frame derived from a BigSQL data source.")
            }
            
            # Check if the number of columns can be changed
            if (length(colnames(x)) != length(value)) {
                if (!.bigr.canChangeColumnCount(x)) {
                    bigr.err(logSource, "Cannot assign new column types since the number of specified columns (" %++% length(value) %++% ") " %++%
                                 "does not match the number of columns in the dataset (" %++% length(coltypes(x)) %++% ")")
                    
                }      
            }
            coltypes <- value
            
            # If the colnames and coltypes do not have the same length, coltypes will
            # be automatically adjusted using default column types
            if (length(coltypes) > length(x@colnames)) {
                # Append default column names to colnames
                from <- length(colnames) + 1
                to <- length(coltypes)
                for (i in from:to) {
                    x@colnames[i] <- "V" %++% i
                }
            } else if (length(coltypes) < length(x@colnames)) {
                # Remove extra colnames
                newColnames <- character(length(coltypes))
                for (i in 1:length(coltypes)) {
                    newColnames[i] <- x@colnames[i]
                }
                x@colnames <- newColnames
            }
            x@coltypes <- coltypes
            
            # Since the data types have changed, the bigr.frame must be re-read
            x <- .bigr.read(x)
        } else {
            bigr.err(logSource, "Invalid column types")
        }
        return(x)
    }
)

# Returns the column types for the given data.frame
setMethod("coltypes", signature(x = "data.frame"),
          function(x) {
              if ((!is.null(x)) & (class(x) == "data.frame")) {
                  return(as.vector(sapply(x, class)))
              } else {
                  return(NULL)
              }
          }
)

#' Displays a slice of a bigr.frame
#'
#' @param x a bigr.frame
#' @return NULL
#' @rdname show_frame
#' @keywords internal
setMethod(f = "show", signature = bigr.env$FRAME_CLASS_NAME, definition = 
    function(object) {
        logSource <- "bigr.frame.show"
        if (!is.null(object)) {
            
            # Get the query result as a data.frame
            df <- .bigr.executeJaqlQuery(.bigr.getJaqlExpression(object), 
                                        colnames=object@colnames, coltypes=object@coltypes)
            if (!.bigr.isNullOrEmpty(df)) {                
                if (nrow(df) > 0) {
                    # Show the contents of the big.frame as a data.frame
                    show(df)
                    
                    # Get the row count from the cache
                    rowCount <- .bigr.getCachedCount(object)
                    
                    # Show the count only if it is cached
                    if (bigr.getRowLimit() > 0) {
                        if (is.null(rowCount)) {
                            if (nrow(df) == bigr.getRowLimit()) {
                                cat("... " %++% " showing first " %++% bigr.getRowLimit() %++% " rows only.\n")
                            }
                        } else {
                            if (rowCount > bigr.getRowLimit()) {
                                cat("... " %++% (rowCount - bigr.getRowLimit()) %++% " more observations.\n")
                            }
                        }
                    }
                } else {
                    cat(paste(colnames(object), collapse="    "))
                    cat("\n<0 rows>\n")
                }
            } else {            
                cat(paste(colnames(object), collapse="    "))
                cat("\n<0 rows>\n")            
            }
            df <- NULL
            gc()
        }
        invisible(NULL);
    }
)

#' Displays a slice of a bigr.frame
#'
#' @param x a bigr.frame
#' @return NULL
#' @rdname print_frame
setGeneric("print")
setMethod(f = "print", signature = bigr.env$FRAME_CLASS_NAME, definition = 
    function(x, ...) {
        logSource <- "print"
        if (length(list(...)) > 0) {
            bigr.err(logSource, "unused argument(s)")
        }                      
        show(x)
    }
)

#' Displays the structure of a bigr.frame including column names and types, along with a
#' data slice and the total number of rows.
#' @param x a bigr.frame
#' @return NULL
#' @rdname str_frame
#' @keywords internal
setGeneric("str")
setMethod(f = "str", signature = bigr.env$FRAME_CLASS_NAME, definition = 
    function(object) {
        if (!is.null(object)) {
            
            cachedCount <- bigr.env$COUNT_CACHE[[object@tableExpression]]            
            
            # If the count has not been calculated yet
            if (!is.null(cachedCount)) {                
                cat("'" %++% bigr.env$FRAME_CLASS_NAME %++% "': " %++% nrow(object) %++% " obs. of " %++% ncol(object) %++% " variables:\n")
            } else {
                cat("'" %++% bigr.env$FRAME_CLASS_NAME %++% "': " %++% ncol(object) %++% " variables:\n")
            }
        
            dataFrame <- as.data.frame(head(object))
                
            ellipsis <- FALSE
            # Add ellipsis (i.e., "...") if there are more rows than shown
            if (!is.null(cachedCount)) {
                if (nrow(object) > bigr.env$DEFAULT_HEAD_ROWS) {
                    ellipsis <- TRUE
                }
            }
            for (i in 1 : ncol(object)) {
                firstElements <- ""
                # Get the first elements for each column
                if (nrow(dataFrame) > 0) {
                    if (object@coltypes[i] == "character") {
                        firstElements <- paste("\"" %++% (dataFrame)[,i] %++% "\"", collapse = " ")
                    } else {
                        firstElements <- paste((dataFrame)[,i], collapse = " ")
                    } 
                }
                spaces <- paste(rep(" ", max(nchar(object@colnames) - nchar(object@colnames[i]))), collapse="")
    
                # Concatenate the colnames, coltypes, and first elements
                cat(" $ " %++% object@colnames[i] %++% spaces %++% ": " %++% .bigr.getShortType(object@coltypes[i]) %++% " " %++% firstElements)
                if (ellipsis) {
                    cat(" ...")
                }
                cat("\n")                
            }
        }
    }
)

#' Computes some basic statistics on each colum of the given bigr.frame.
#'
#' If a column is character-typed, the counts for each category
#' will be computed. For numeric columns, max, min, and
#' quartiles will be calculated.
#' @param object a \code{bigr.frame}
#' @return a \code{table} with the statistics calculated from the \code{bigr.frame}
#' @rdname summary_frame
#' @keywords internal
setGeneric("summary")
setMethod(f = "summary", signature = bigr.env$FRAME_CLASS_NAME, definition = 
    function(object, formula) {        
        logSource <- "summary"
        bf <- object
        statList <- list()
        maxLength <- -1
        colnames <- c()
        formulaString <- ""
        
        # If formula is specified, route to the 'formula' version of summary
        if (! missing(formula))
            return(bigr.summary(object, formula))     
        
        # Assemble formula as a string        
        for (i in 1:length(bf@coltypes)) {
            type <- bf@coltypes[i]
            if (type == "character") {
                formulaString <- formulaString %++% "min(" %++% bf@colnames[i] %++% ") + " %++% 
                    "max(" %++% bf@colnames[i] %++% ")"
                colnames <- c(colnames, c("Min.", "Max."))
                if (i < length(bf@coltypes)) {
                    formulaString <- formulaString %++% "+"
                }                
            } else if (type == "numeric" | type == "integer") {
                formulaString <- formulaString %++%  "min(" %++% bf@colnames[i] %++% ") + " %++% 
                    "max(" %++% bf@colnames[i] %++% ") + " %++% 
                    "avg(" %++% bf@colnames[i] %++% ")"
                colnames <- c(colnames, c("Min.", "Max."))
                if (i < length(bf@coltypes)) {
                    formulaString <- formulaString %++% "+"
                }
            }
        }
        
        formulaString <- formulaString %++% "~ ."
        bigr.info(logSource, "Summary will be computed using formula: ")
        bigr.info(logSource, formulaString)        
        
        # Invoke bigr.summary(bigr.frame,formula) to compute statistics only if
        # there is at least one character or one numeric field
        df <- NULL
        if (!(all(coltypes(bf) == "logical"))) {
            df <- bigr.summary(bf, eval(parse(text=formulaString)))
        }
        
        # Get meta data  
        j <- 1
        for (i in 1:length(bf@coltypes)) {
            type <- bf@coltypes[i]
            colnames <- NULL
            if (type == "character") {
               colnames <- c("Min.", "Max.")
               values <- c(df[1, j], df[1, j+1])
               statList[[i]] <- paste(.bigr.align.strings(colnames), 
                                       .bigr.align.strings(values), sep=" :")
                j <- j + 2
            } else if (type == "numeric" | type == "integer") {
                values <- c(df[1, j], df[1, j+1], df[1, j+2])
                colnames <- c("Min.", "Max.", "Mean")
                statList[[i]] <- paste(.bigr.align.strings(colnames), 
                                       .bigr.align.strings(round(values, 3)), sep=" :")
                j <- j + 3
            } else if (type == "logical") {
                statList[[i]] <- "Class: logical" 
            }
            newLength <- length(statList[[i]])
            if (newLength > maxLength) {
                maxLength <- newLength
            }
        }
        bigr.infoShow(logSource, df)
        bigr.infoShow(logSource, statList[[i]])
        
        # Format the result as a table using a matrix as a temporary storage.
        nrows <- maxLength
        ncols <- length(bf@coltypes)
        resultMatrix <- matrix("", nrow=nrows, ncol=ncols)
        for (j in 1: ncols) {
            for (i in 1 : length(statList[[j]])) {
                resultMatrix[i, j] <- statList[[j]][i]
            }
        }
        resultTable <- as.table(resultMatrix)
        colnames(resultTable) <- colnames(bf)
        return(resultTable)
    }
)

#' This function downloads the contents of a bigr.frame into a data.frame.
#' Since R data.frames are held in memory, ensure that you have enough memory
#' on your system to accommodate the contents.
#' 
#' @title Download data from the server into a data.frame
#' @param x a bigr.frame
#' @return a data.frame
#' @rdname frame_as.data.frame
#' @seealso \link{as.vector}
#' @examples \dontrun{
#' 
#' airdf <- as.data.frame(air)
#' airha <- as.data.frame(air[air$UniqueCarrier == "HA",])
#' }
setGeneric("as.data.frame")
setMethod(f = "as.data.frame", signature = bigr.env$FRAME_CLASS_NAME, definition = 
    function(x, row.names=NULL, optional=NULL, ...) {
        logSource <- "as.data.frame"
        bigr.infoShow(list(...))
        if (length(list(...)) > 0) {
            bigr.err(logSource, "unused argument(s): (" %++% paste(list(...), collapse=", ") %++% ")")
        }
        if (!.bigr.isNullOrEmpty(row.names)) {
            bigr.err(logSource, "Parameter 'row.names' is not supported by as.data.frame")
        }        
        if (!.bigr.isNullOrEmpty(optional)) {
            bigr.err(logSource, "Parameter 'optional' is not supported by as.data.frame")
        }
        .bigr.executeJaqlQuery(.bigr.getJaqlExpression(x), x@colnames, coltypes=coltypes(x), limit=FALSE)
    }
)

#' The specified bigr.frame is attached to the R search path. This means that
#' the bigr.frame is searched by R when evaluating a variable, so objects in 
#' the bigr.frame can be accessed by simply giving their names.
#' 
#' @title Attach bigr.frame to search path
#' @param what (bigr.frame) The frame to attach
#' @param pos (integer) Specify position in search() where to attach.
#' @param name (character) Name to use for the attached database. Names
#'   starting with package: are reserved for library.
#' @param warn.conflicts (logical) If TRUE, warnings are printed about conflicts 
#' from attaching the database, unless that database contains an object
#' @examples \dontrun{
#' 
#' attach(air)
#' 
#' print(Distance)
#' 
#' # How many flights were flown by specific airlines?
#' length(UniqueCarrier[UniqueCarrier %in% c("UA", "DL")])
#' 
#' # Number of flights delayed by more than 15 minutes?
#' length(DepDelay[DepDelay >= 15])
#' }
setGeneric("attach")
setMethod(f = "attach", signature = bigr.env$FRAME_CLASS_NAME, definition = 
    function(what, pos = 2, name = deparse(substitute(what)), warn.conflicts = TRUE) {        
        logSource <- "attach"
        if (missing(what)) {
            what <- NULL
        }
        if (class(what) != bigr.env$FRAME_CLASS_NAME) {
            bigr.err(logSource, "This version of attach is only intended for bigr.frame's")
        }
        if (.bigr.isNullOrEmpty(what)) {
            bigr.err(logSource, "Invalid bigr.frame to be attached.")
        }
        bf <- what        
        newEnv <- new.env()
        for (i in 1:length(bf@coltypes)) {
            assign(x=bf@colnames[i], value=bf[, c(i)], envir=newEnv)
        }
        attach(newEnv, pos=pos, name=name, warn.conflicts=TRUE)
    }              
)

#' This is the BigR version of with(). It allows to access the columns of a bigr.frame by
#' simply referring to their name.
#'
#' attach() appends every column of a bigr.frame (as a bigr.vector) into a new environment. Then,
#' the given expression is evaluated into such environment.
#' 
#' @param data a bigr.frame
#' @param expr the expression to be evaluated by with()
#' @examples \dontrun{
#' > with(homes, zipcode)
#' > with(homes, homes[zipcode == "95141" & askingprice > 1000, c(1, 2, 3)]}
setGeneric("with")
setMethod(f = "with", signature = bigr.env$FRAME_CLASS_NAME, definition =               
    function(data, expr, ...) {
        logSource <- "with"
        if (missing(data)) {
            data <- NULL
        }
        if (class(data) != bigr.env$FRAME_CLASS_NAME) {
            bigr.err(logSource, "This version of attach is only intended for bigr.frame's")
        }
        if (.bigr.isNullOrEmpty(data)) {
            bigr.err(logSource, "Invalid bigr.frame to be attached.")
        }
        newEnv <- new.env()
        bf <- data
        
        for (i in 1:length(bf@coltypes)) {
            assign(x=bf@colnames[i], value=bf[, c(i)], envir=newEnv)            
        }
        eval(substitute(expr), envir=newEnv, enclos=newEnv)    
    }
)

#' Return the number of rows of a bigr.frame
#' 
#' The first time this method is called on a bigr.frame, the return value is
#' cached internally. Subsequent calls return the cached value.
#' @title Number of rows of a bigr.frame
#' @param x a bigr.frame
setGeneric("nrow")
setMethod("nrow", signature(x = bigr.env$FRAME_CLASS_NAME),
    function(x) {
        logSource <- "bigr.nrow"
        if (missing(x)) {
            x <- NULL
        }
        if (!.bigr.isNullOrEmpty(x)) {
            cachedCount <- bigr.env$COUNT_CACHE[[x@tableExpression]]
            
            # If the count is already cached, it will be returned right away, so
            # no query will be executed.
            if (!is.null(cachedCount)) {
                return(cachedCount)
            }  
            
            # Optimization: If reading from a text file, it should be read as lines
            # to compute the number of rows. This also saves the process to recode
            # na.string
            if (x@dataSource == bigr.env$TEXT_FILE) {
                
                # Create a bigr.frame with no column information. header is set to FALSE
                # to ensure the file is read as lines.
                bf <- new(bigr.env$FRAME_CLASS_NAME, dataSource = bigr.env$LINE_FILE, dataPath = x@dataPath, 
                          header = FALSE, localProcessing = x@localProcessing, envs = x@envs)
                
                # If there is a header, it will be counted so one unit would need to be
                # removed from the count.
                if (x@header) {
                    jaqlExpression <- .bigr.getJaqlExpression(bf) %++% " -> group into count($) - 1"
                } else {
                    jaqlExpression <- .bigr.getJaqlExpression(bf) %++% " -> group into count($)"
                }   
                df <- .bigr.executeJaqlQuery(jaqlExpression, limit=FALSE)
                if (.bigr.isNullOrEmpty(df)) {
                    bigr.err(logSource, "Could not calculate the number of rows")
                } else {
                    count <- as.integer(df[1,1])
                    
                    # Store the count in the cache
                    bigr.env$COUNT_CACHE[[x@tableExpression]] <- count                
                    return(count)
                }                
            } else {
                return (.bigr.count(x))
            }
        }
    }
)

#' Return the number of columns of a bigr.frame
#' @title Number of columns of a bigr.frame
#' @param x a bigr.frame
setGeneric("ncol")
setMethod("ncol", signature(x = bigr.env$FRAME_CLASS_NAME),
    function(x) {
        if (!.bigr.isNullOrEmpty(x@coltypes)) {
            return(length(x@coltypes))
        } else {
            return(NULL)
        }
    }
)

#' Returns the dimensions of a bigr.frame
#' 
#' @param x a bigr.frame
#' @title Dimemsions of a bigr.frame
#' @return A two-element vector representing the number of rows and columns
#'   respectively.
setGeneric("dim")
setMethod("dim", signature(x = bigr.env$FRAME_CLASS_NAME),
    function(x) {
        return(c(nrow(x), length(x@coltypes)))
    }
)

setGeneric("length")
setMethod("length", signature(x = bigr.env$FRAME_CLASS_NAME),
          function(x) {        
              ncol(x)
          }
)

#' as.bigr.frame uploads the contents of an R data.frame to a temporary
#' dataset on a BigInsights cluster, and presents the resulting dataset as a 
#' bigr.frame object. This function creates a temporary file in the /tmp/bigr
#' directory. This file is deleted as soon as the bigr.frame object that 
#' references the file goes out of scope. To provide a different name to the 
#' file, use bigr.persist().
#' 
#' @section Caveats: This mechanism is only designed to transfer small files 
#'   to HDFS.
#'   
#' @title Turn an R data.frame to a bigr.frame
#'   
#' @param    df a data.frame
#' @return   a bigr.frame
#' @examples \dontrun{
#' 
#' irisbf <- as.bigr.frame(iris)
#' irisbf <- bigr.persist(irisbf, dataSource="DEL", dataPath="iris.csv", 
#'                        header=T, del=",")
#' }
#' @seealso \link{as.bigr.vector}, \link{bigr.persist}, \link{Temporary 
#'   Files}
as.bigr.frame <- function(df) {
    logSource <- "as.bigr.frame"
    
    # Turn atomic vectors into data.frames
    if (class(df) %in% c("factor", bigr.env$SUPPORTED_DATA_TYPES)) {
        
        # The column name is derived from the argument
        colnames <- unlist(strsplit(deparse(substitute(df)), '\\$'))

        df <- data.frame(df)
        colnames(df) <- colnames[[length(colnames)]]        
    }
    
    # Do we have a data.frame?
    if (class(df) != "data.frame")
        bigr.err(logSource, "Invalid parameter, atomic vector or data.frame expected.")
    
    # Check if we have any rows?
    if (nrow(df) == 0)
        bigr.err(logSource, "Cannot turn an empty data frame into a bigr.frame.")
    
    
    coltypes <- coltypes(df)
    coltypes <- ifelse(coltypes == "factor", "character", coltypes)
    
    op <- options("useFancyQuotes")
    options("useFancyQuotes" = FALSE)
    # Quote all character columns
    for (i in 1:ncol(df)) {
        if (class(df[,i]) == "factor")
            df[,i] = ifelse(is.na(df[,i]), NA, as.character(df[,i]))
            
        if (class(df[,i]) %in% c("factor","character")) {
            df[,i] <- ifelse(is.na(df[,i]), NA, dQuote(df[,i]))
        }
    }
    options(op)
    
    # Generate a temporary filename
    jaqlExpression <- "csvout := bigrGetFilename('/tmp/bigr', 'as.bigr.frame', 'd'); csvout"
    csvout <- .bigr.execQuery(jaqlExpression)[1,1]
    
    # Tweak Big SQL logging to WARN+ only. This will ensure we don't long the
    # potentially large JaQL statement to insert data into HDFS.
    # .bigr.setBigSQLAuditing("WARN")

    chunkSize <- 10000
    chunkNum <- 0
    for (i in seq(1, nrow(df), chunkSize))
    {
        maxIndex <- min(nrow(df), i + chunkSize - 1)
        
        # Build a JaQL array
        rows <- apply(df[i:maxIndex,,drop=F], 1, function(x) { 
            x <- as.character(x)
            sprintf("'%s'", paste(ifelse(is.na(x), "", x), collapse=",")) 
        })
        op <- options("useFancyQuotes")
        options("useFancyQuotes" = FALSE)
        if (i == 1) {
            # first chunk have a header
            rows <- sprintf("['%s',%s]", 
                            paste(dQuote(colnames(df)),collapse=","),
                            paste(rows, collapse=","))
        } else {
            # subsequent chunks
            rows <- sprintf("[%s]", 
                            paste(rows, collapse=","))        
        }
        options(op)
        
        ##.bigr.execQuery(sprintf("%s -> write(lines('foo.txt'))", rows, csvout))
        
        # Write to a file
        .bigr.execQuery(sprintf("%s -> write(lines('%s/part-%.3d'))", rows, csvout, chunkNum))
        chunkNum <- chunkNum + 1
        
    }
    
    # Create a environment that holds metadata for any temporary files, and 
    # register a finalizer for it. These files will be removed when the environment
    # cannot be accessed.
    e <- new.env(parent = emptyenv())
    e$finals <- csvout
    reg.finalizer(e, .bigr.remove.files)
    envs <- list(e)

    bf <- new(bigr.env$FRAME_CLASS_NAME, dataPath=csvout, dataSource=bigr.env$TEXT_FILE, header=T, coltypes=coltypes,
              localProcessing=T, envs = envs)
    colnames(bf) <- colnames(df)
    coltypes(bf) <- coltypes
    
    # Go back to the default Big SQL logging level
    # .bigr.setBigSQLAuditing("INFO")
    
    # TODO: Need to reinstate the finalizer code
    # The finalizer needs to clean up the underlying file
    # bf@env$finals <- c(bf@env$finals, bf@dataPath)
    
    bf
}

#' as.bigr.vector uploads the contents of an R vector to a temporary dataset
#' on a BigInsights cluster, and presents the resulting dataset as a
#' bigr.vector object. This function creates a temporary file in the
#' /tmp/bigr directory. This file is deleted as soon as the bigr.vector
#' object that references the file goes out of scope.
#' 
#' @section Caveats: This mechanism is only designed to transfer small 
#'   datasets to HDFS.
#'   
#' @title Turn an R vector into a bigr.vector
#'   
#' @param    v a vector
#' @return   a bigr.vector
#' @examples \dontrun{
#' 
#' irisbv <- as.bigr.vector(unique(iris$Species))
#' }
#' @seealso \link{as.bigr.frame}, \link{Temporary Files}
as.bigr.vector <- function(v) {
    logSource <- "as.bigr.vector"
    
    if (! (class(v) %in% c("factor", bigr.env$SUPPORTED_DATA_TYPES))) {
        bigr.err(logSource, "Invalid parameter, atomic vector expected.")
    }

    # Check if we have any rows?
    if (length(v) == 0)
        bigr.err(logSource, "Cannot turn a zero-length vector into a bigr.vector.")
    
    bf <- as.bigr.frame(v)
    bf[,1]
}

#' This function sorts a bigr.frame by the given column(s).
#' 
#' @param bf a bigr.frame to be sorted
#' @param by a list of columns (i.e., bigr.vector's) to sort by, or a vector of character 
#' values containing the column names to sort by
#' @param decreasing an array of logical values specifying whether each column sort should be 
#' sorted in increasing or decreasing order
#' @return a sorted bigr.frame
bigr.sort <- function(bf, by, decreasing) {
    logSource <- "bigr.sort"
    
    # Check parameter integriy
    if (missing(bf)) {
        bf <- NULL
    }
    if (missing(by)) {
        by <- NULL
    }
    if (class(bf) != bigr.env$FRAME_CLASS_NAME) {
        bigr.err(logSource, "bigr.sort is only intended for bigr.frame's.")
    }
    if (class(by) == bigr.env$VECTOR_CLASS_NAME) {
        by <- list(by)
    }
    if (class(by) != "list" & class(by) != "character") {
        bigr.err(logSource, "A list of columns must be specified")
    }
    if (length(by) < 1) {
        bigr.err(logSource, "A list of columns must be specified")
    }
    if (missing(decreasing)) {
        decreasing <- rep(FALSE, length(by))
    }
    if (.bigr.isNullOrEmpty(decreasing)) {
        bigr.err(logSource, "Wrong value for argument 'decreasing': " %++% decreasing)
    }
    if (class(decreasing) != "logical") {
        bigr.err(logSource, "Value for argument 'decreasing' must be of type 'logical'")
    }
    
    # If decreasing is T or F, all columns will have the same decreasing value
    if (length(decreasing) == 1) {
        decreasing <- rep(decreasing, length(by))
    } else if (length(decreasing) != length(by)) {
        bigr.err(logSource, "Arguments 'by' and 'decreasing' must have the same length")
    }
    
    # The JaQL expression within the sort by clause
    sortByExpression <- ""
    i <- 1
    
    # For each column, obtain the column id, and append it to the sort by expression
    for (element in by) {
        bv <- NULL
        colExp <- ""
        
        # Account for columns as names
        if (class(element) == "character") {
            
            # Get column id's for the given column name
            colid <- match(element, bf@colnames) - 1            
            if (.bigr.isNullOrEmpty(colid)) {
                bigr.err(logSource, "All specified columns must belong to the given bigr.frame")                
            }
            colExp <- "$[" %++% colid %++% "]"
        # Account for columns as bigr.vector's
        } else if (class(element) == bigr.env$VECTOR_CLASS_NAME) {
            bv <- element
            if (!.bigr.is.compatible(bf, bv)) {
                bigr.err(logSource, "Sort by columns and target bigr.frame must come from the same data origin.")
            }
            
            # Get column id's for the given column name
            colExp <- bv@columnExpression
        } else {
            bigr.err(logSource, "Sort by columns must be of type 'bigr.vector' or 'character'")
        }        
        
        # Append desc keyword if necessary
        if (decreasing[i]) {
            sortByExpression <- sortByExpression %++% colExp %++% " desc"
        } else {
            sortByExpression <- sortByExpression %++% colExp
        }
        i <- i + 1
        
        # Append "," if necessary
        if (i <= length(by)) {
            sortByExpression <- sortByExpression %++% ","
        }        
    }
    bigr.info(logSource, sortByExpression)
    
    # Create the sorted bigr.frame
    newBf <- new(bigr.env$FRAME_CLASS_NAME, dataPath="", dataSource=bigr.env$TRANSFORM, header=FALSE, localProcessing=bf@localProcessing,
                        delimiter=bf@delimiter, colnames=bf@colnames, coltypes=bf@coltypes, envs = bf@envs)
    newBf@tableExpression <- bf@tableExpression %++% " -> sort by [" %++% sortByExpression %++% "]"
    newBf@columnExpression <- bf@columnExpression
    return (newBf)
}

#' This method allows to join two bigr.frame's. 
#' 
#' @param x the first bigr.frame to be joined
#' @param y the second bigr.frame to be joined
#' @param by a character vector specifying the join columns. If by is not specified,
#' the common column names in \code{x} and \code{y} will be used.
#' @param by.x a character vector specifying the joining columns for x. If by.x is not 
#' specified, the common column names in \code{x} and \code{y} will be used.
#' @param by.y a character vector specifying the joining columns for y. If by.y is not 
#' specified, the common column names in \code{x} and \code{y} will be used.
#' @param all.x a boolean value indicating whether all the rows in x should be including
#' in the join
#' @param all.y a boolean value indicating whether all the rows in y should be including
#' in the join
#' 
#' If all.x and all.y are set to FALSE, a natural join will be returned.
#' If all.x is set to TRUE and all.y is set to FALSE, a left outer join will be returned.
#' If all.x is set to FALSE and all.y is set to TRUE, a right outer join will be returned.
#' If all.x and all.y are set to TRUE, a full outer join will be returned. In this case,
#' columns in by.x and by.y will not be shown duplicated, but they will be combined discarding
#' non-existing values.
setGeneric("merge")
setMethod("merge", signature(x = bigr.env$FRAME_CLASS_NAME, y=bigr.env$FRAME_CLASS_NAME),
    function(x, y, by = intersect(names(x), names(y)),
        by.x = by, by.y = by, all = FALSE, all.x = all, all.y = all,
        sort = TRUE, suffixes = c(".x",".y"),
        incomparables = NULL, ...) {
        
        logSource <- "merge"        
        bigr.info(logSource, "Merging...")
        
        if (missing(x) | missing(y)) {
            bigr.err(logSource, "At least two bigr.frame's must be specified")
        }
        if (.bigr.isNullOrEmpty(by.x) | .bigr.isNullOrEmpty(by.y)) {
            bigr.err(logSource, "Parameters 'by.x' and 'by.y' cannot be NULL, NA, or empty")
        }
        if (.bigr.isNullOrEmpty(all.x) | .bigr.isNullOrEmpty(all.y)) {
            bigr.err(logSource, "Parameters 'all.x' and 'all.y' cannot be NULL, NA, or empty")
        }
        if (length(by.x) != length(by.y)) {
            bigr.err(logSource, "by.x and by.y must have the same length")
        }
        if (length(suffixes) != 2) {
            bigr.err(logSource, "Exactly two 'character' suffixes must be specified")
        }
        if (class(suffixes) != "character") {
            bigr.err(logSource, "Exactly two 'character' suffixes must be specified")
        }
        
        # Obtain the column ids for the WHERE clause
        xWhereColIds <- match(by.x, x@colnames) - 1 
        yWhereColIds <- match(by.y, y@colnames) - 1 
        bigr.info(logSource %++% ".x", xWhereColIds)
        bigr.info(logSource %++% ".y", yWhereColIds)
        
        # Check that columns belong to the bigr.frame's
        if (any(is.na(xWhereColIds)) | any(is.na(yWhereColIds))) {
            bigr.err(logSource, "Invalid column names to merge.")
        }
        
        # Check that column types match
        if (!all(x@coltypes[xWhereColIds + 1] == y@coltypes[yWhereColIds + 1])) {
            bigr.err(logSource, "Columns in by.x and by.y must have the same data types.")
        }
        
        # Build the WHERE clause
        whereClause <- paste("(x[" %++% xWhereColIds %++% "] == y[" %++% yWhereColIds %++% "])", collapse=" and ")
        
        # Column ids for the INTO clause
        xIntoColIds <- NULL
        yIntoColIds <- NULL

        # All x's columns which are not in by.x will be individually included in the INTO clause
        xIntoColIds <- seq(1:ncol(x))[-(xWhereColIds + 1)] - 1

        # All y's columns which are not in by.y will be individually included in the INTO clause
        yIntoColIds <- seq(1:ncol(y))[-(yWhereColIds + 1)] - 1
        
        # Obtain the column names and types
        joinNames <- x@colnames[xWhereColIds + 1]
        joinTypes <- x@coltypes[xWhereColIds + 1]
        xNames <- x@colnames[xIntoColIds + 1] 
        yNames <- y@colnames[yIntoColIds + 1]
        
        # Add suffixes for fields with common names
        for (i in 1:length(xNames)) {
            for (j in 1:length(yNames)) {
                if (xNames[i] == yNames[j]) {
                    xNames[i] <- xNames[i] %++% suffixes[1]
                    yNames[j] <- yNames[j] %++% suffixes[2]
                    
                }
            }
        }
        xTypes <- x@coltypes[xIntoColIds + 1]
        yTypes <- y@coltypes[yIntoColIds + 1]
        bigr.infoShow("xIntoColIds", xIntoColIds)
        bigr.infoShow("yIntoColIds", yIntoColIds)
        
        # Build the INTO clause
        intoClause <- paste("notNull(x[" %++% xWhereColIds %++% "], y[" %++% yWhereColIds %++% "])", collapse=", ") %++% ", " %++%
                      paste("x[" %++% xIntoColIds %++% "]", collapse=", ") %++% ", " %++%
                      paste("y[" %++% yIntoColIds %++% "]", collapse=", ")        
        
        # Add PRESERVE statements if necessary (for outer joins)
        xJoinClause <- "x"
        if (all.x) {
            xJoinClause <- "preserve x"
        }        
        yJoinClause <- "y"
        if (all.y) {
            yJoinClause <- "preserve y"
        }
        
        # Build the final JaQL expression
        joinExpression <- "join " %++% xJoinClause %++% " in (" %++% .bigr.getJaqlExpression(x) %++%
            "), " %++% yJoinClause %++% " in (" %++% .bigr.getJaqlExpression(y) %++%
            ") where " %++% whereClause %++% 
            " into [" %++% intoClause %++% "]"
        bigr.info(logSource, joinExpression)
        
        # Build the resulting bigr.frame
	# TODO: Need to determine localProcessing?
        resultBf <- new(bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", 
                        colnames=c(joinNames, xNames, yNames), coltypes=c(joinTypes,xTypes, yTypes),
                        envs = c(x@envs, y@envs))
        resultBf@tableExpression <- joinExpression
        resultBf@columnExpression <- ""
        
        # Sort if necessary
        if (sort == TRUE) {
            return(bigr.sort(resultBf, by=joinNames))
        } else {
            return(resultBf)
        }
    }
)

#' Given a bigr.frame, this function returns a new bigr.frame without the rows
#' that contain NA values.
#' 
#' @param object a bigr.frame
#' @return a bigr.frame which only contains rows with no NA values
setGeneric("na.omit")
setMethod("na.omit", signature(object = bigr.env$DATASET_CLASS_NAME),
    function(object, ...) {
        if (class(object) == bigr.env$FRAME_CLASS_NAME) {
            condition <- !is.na(object[, 1])
            for (i in 2:ncol(object)) {
                condition <- condition & !is.na(object[, i])
            }
            return(object[condition, ])
        } else if (class(object) == bigr.env$VECTOR_CLASS_NAME) {
            return(object[!is.na(object)])
        }
    }
)

#' Given a bigr.frame, this function returns a new bigr.frame without the rows
#' that contain NA values.
#' 
#' @param object a bigr.frame
#' @return a bigr.frame which only contains rows with no NA values
setGeneric("na.exclude")
setMethod("na.exclude", signature(object = bigr.env$DATASET_CLASS_NAME),
    function(object, ...) {
	na.omit(object)
    }
)

#' Save the bigr.frame object to a persistent directory
#'
#' @param x the bigr.frame object
#' @param dataSource the output data source (either TEXT_FILE, or BIGSQL)
#' @param dataPath the output data location
#' @param header whether or not the output will contain headers (only for text files)
#' @param delimiter the delimiter character (only for text files)
#' @return a bigr.frame object from the persisted data source
.bigr.frame.persist <- function(dataset, dataSource, dataPath, header, delimiter, localProcessing) {
    logSource <- ".bigr.frame.persist"  
    
    # Check for missing parameters and assign default values
    if (missing(header)) {
        header <- FALSE
    }
    if (missing(delimiter)) {
        delimiter <- bigr.env$DEFAULT_DELIMITER
    }
    if (missing(localProcessing)) {
        localProcessing <- bigr.env$DEFAULT_LOCAL_PROCESSING
    }
    
    # Create a new dataset with the corresponding output parameters
    outputDataset <- bigr.dataset.constructor(dataset, dataSource, dataPath, 
                                              delimiter, header, dataset@na.string, localProcessing,
                                              envs = list())
    
    # Update its table expression and column expression
    outputDataset@tableExpression <- dataset@tableExpression
    outputDataset@columnExpression <- dataset@columnExpression
    
    if (dataset@dataSource == outputDataset@dataSource &
            dataset@dataPath == outputDataset@dataPath) {
        bigr.err(logSource, 
                 sprintf("Source and target datasets cannot be identical: dataPath = %s, dataSource = %s ", 
                         dataSource, dataPath))
    }
    
    # Invoke method .bigr.write to actually export the data
    result <- .bigr.write(outputDataset)
    if (! result)
        return (result)
    
    if (bigr.env$FRAME_CLASS_NAME == class(dataset)) {
        bf <- new(bigr.env$FRAME_CLASS_NAME,dataSource = dataSource, dataPath = dataPath, header = header,
                  delimiter = delimiter, localProcessing = localProcessing,
                  colnames = dataset@colnames, coltypes = dataset@coltypes,
                  envs = list())
        return (bf)
    }
    else {
        return (result)
    }
}
