#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' groupApply partitions its input and applies an R function to each 
#' partition. The partitioning of the data and execution of the functions all
#' happen on the server and results are retained on the server as well.
#' 
#' There are several mechanisms to partition the data: via one or more 
#' columns, via a fixed number of batches, or both. To process the 
#' partitions, an instance of R is invoked for each partition and data from 
#' the partition is passed to R. The function is invoked on the data and 
#' results are consolidated. Depending on the configuration of the underlying
#' cluster, the partitions can be processed in parallel on different nodes of
#' the cluster. Results generated from each individual partition could be 
#' tabular (i.e. returned as a data.frame) or complex (i.e. any arbitrary R 
#' object. Tabular data is consolidated and presented as a bigr.frame, while 
#' R objects are assembled in a bigr.list. When returning tabular data, Big R
#' needs to know the shape of the output, and this information can be 
#' provided via an input "signature".
#' 
#' @section Configuration:
#'   
#'   groupApply partitions the underlying data source and attempts to process
#'   each partition in a Hadoop "reducer". How many partitions will be 
#'   actually run concurrently depends on the configuration of the underlying
#'   cluster. Specifically, the options "mapred.reduce.tasks" and 
#'   "mapred.tasktracker.reduce.tasks.maximum" play a big role. A user can 
#'   set these settings from Big R itself. Depending on how long your R 
#'   functions are designed to run, there may be a need to increase the 
#'   MapReduce timeout via "mapred.task.timeout".
#'   
#' @section Error handling and diagnostics:
#'   
#'   groupApply can fail for several reasons. The most common error scenario 
#'   faced by beginning users is when the R interpreter or the "bigr" package
#'   itself are not properly installed on all data nodes of the BigInsights 
#'   cluster. In addition, groupApply may also fail if any of the underying 
#'   MapReduce jobs fail to execute. Should any of these events happen, 
#'   groupApply issues a stack trace that describes the symptoms of the 
#'   problem. In some cases, it may be necessary to examine the Big SQL 
#'   server logs (bigsql.loq) to obtain additional information on the 
#'   problems. Should there be a problem in executing MapReduce jobs, it may 
#'   be necessary to examine the job logs via services such as Hadoop 
#'   JobTracker.
#'   
#'   In many cases, one or more instances of the user-specified R function 
#'   raise errors. These errors, along with all output that the R function(s)
#'   may produce on stdout and stderr, are captured. These can be accessed by
#'   bigr.logs().
#'   
#' @section IMPORTANT - Partition sizes and memory considerations:
#'   
#'   Given that Big R invokes the R interpreter for each partition, it is 
#'   important to ensure that each partition is only as big as can be handled
#'   by the R instance. For partitions that are too large, R may run out of 
#'   memory, and this will cause execution of the partition to fail. In such 
#'   cases, you may considing using sampling or other means to reduce 
#'   partition size. In addition, depending on average partition sizes, one 
#'   may want to tune the degree of parallelism (see Configuration above.)
#'   
#' @title Partitioned execution via column groups
#' @param data bigr.frame object
#' @param groupingColumns a bigr.vector or list of bigr.vector objects
#' @param rfunction function to apply to each partition
#' @param signature If specified, this is a data.frame that has the same 
#'   structure as the return value of "rfunction". This only needs to be 
#'   specified when returning tabular data.
#' @param numBatches If specified, indicates the # of partitions to divide 
#'   the entire input (groupingColumns not specified), or each group of the 
#'   input (groupingColumns also specified)
#' @param ... (optional) parameters that are passed to 'rfunction'
#' @return For tabular data, the return value is a bigr.frame. For 
#'   non-tabular data, the return value is a bigr.list.
#' @seealso \link{bigr.logs}, \link{bigr.frame}, \link{bigr.list}, 
#'   \link{bigr.set.server.options}
#' @examples \dontrun{
#' 
#' # Only select two airlines
#' air <- air[air$UniqueCarrier %in% c("UA", "HA"),]
#' 
#' # Returning tabular-data as a bigr.frame
#' means <- groupApply(air, air$UniqueCarrier,
#'                     function(df) {
#'                         return (data.frame(df$UniqueCarrier[1], 
#'                                            mean(df$Distance, 
#'                                            na.rm=T)))
#'                     },
#'                     signature = data.frame(carrier = "anystring", 
#'                                            avg = 1.0))
#' print(means)
#' 
#' bigr.logs()
#' 
#' bigr.logs(1)
#' 
#' # Returning non-tabular data such as complex R objects
#' models <- groupApply(data = air, 
#'                      groupingColumns=list(air$UniqueCarrier),
#'                      rfunction = function(df) {
#'                       predcols <- c('ArrDelay', 'DepDelay', 'DepTime', 
#'                                      'CRSArrTime', 'Distance')
#'                         m <- lm(ArrDelay ~ ., df[,predcols])
#'                         coef(m)
#'                      })
#' print(models)
#' 
#' model.ha <- bigr.pull(models$HA)
#' 
#' print(model.ha)
#' 
#' bigr.logs(model.ha, 1:2)
#' 
#' }

groupApply <- function(data, groupingColumns, rfunction, signature, ..., numBatches)
{
    # save the current time
    b4 <- Sys.time()
    
    # require this library for encode/decode
    library("base64enc")
    
    # logging set up
    logSource <- "groupApply"
    bigr.info(logSource, "Start groupApply processing...")
    
    # checking arguments
    .bigr.checkParameter(logSource, data, "bigr.frame")
    .bigr.checkParameter(logSource, groupingColumns, c("list", "bigr.vector"), isOptional=T)
    .bigr.checkParameter(logSource, rfunction, "function")
    .bigr.checkParameter(logSource, signature, "data.frame", isOptional=T)
    .bigr.checkParameter(logSource, numBatches, c("integer", "numeric"), isOptional=T)
    
    # either groupingColumns or numBatches must be specified
    if (missing(groupingColumns)) {
        if (missing(numBatches)) {
            bigr.err(logSource, "Either 'groupingColumns' or 'numBatches' must be specified.")
        }
        else {
            if (!is.numeric(numBatches) || (numBatches < 1)) {
                bigr.err(logSource, "Parameter 'numBatches' has an invalid value. A non-negative integer must be specified.")
            }
            typeOfGA <- "Batching"
        }
    }
    else {
        if (missing(numBatches)) {
            typeOfGA <- "Grouping"
        }
        else {
            if (!is.numeric(numBatches) || (numBatches < 1)) {
                bigr.err(logSource, "Parameter 'numBatches' has an invalid value. A non-negative integer must be specified.")
            }
            typeOfGA <- "GroupingAndBatching"            
        }

        if ("list" == class(groupingColumns)) {
            if ((length(groupingColumns) <= 0) ||
                all(sapply(groupingColumns, function(x) {class(x) == bigr.env$VECTOR_CLASS_NAME}) != rep(TRUE, length(groupingColumns)))) {
                bigr.err(logSource, "Parameter groupingColumns must be a list of bigr.vector objects.")
            }
        
            if (all(sapply(groupingColumns, function(x) {.bigr.is.compatible(data, x)}) != rep(TRUE, length(groupingColumns)))) {
                bigr.err(logSource, "Parameters 'data' and 'groupingColums' must be derived from the same data source.")
            }
        }
        else {
            if (!.bigr.is.compatible(data, groupingColumns)) {
                bigr.err(logSource, "Parameters 'data' and 'groupingColums' must be derived from the same data source.")
            }
        }
    }
    
    # optional parameters
    if (missing(signature)) {
        signature <- NULL
        if ("Batching" == typeOfGA) {
            bigr.err(logSource, "When using 'numBatches', groupApply can only return tabular data, and a signature must be specified.")
        }
    }
    
    # pack the connection credential and the bigr library version/built info to send to R server
    vb <- packageDescription("bigr", fields=c("Version", "Date"))
    scon <- c(bigr.env$CONNECTION@host, bigr.env$CONNECTION@port, bigr.env$CONNECTION@database, 
              bigr.env$CONNECTION@user, bigr.env$CONNECTION@password, vb[[1]], vb[[2]])
    scon <- base64encode(serialize(scon, connection=NULL, ascii=FALSE))
    
    # get the list of the arguments, the first element is the function name
    tempsys <- match.call()
    arglist <- as.list(tempsys)
    
    # get the function name
    streamfunc <- "arg_" %++% deparse(arglist[[1]])

    # get the function body and encode
    rfunction <- deparse(eval(arglist$rfunction))
    rfunction <- base64encode(serialize(rfunction, connection=NULL, ascii=FALSE))

    # send the rfunction to Jaql engine
    jaqlExpression <- streamfunc %++% "='" %++% rfunction %++% "'"
    .bigr.execUpdate(jaqlExpression)

    # generate the argument list
    ignored <- append(1, which(names(arglist) %in% c("data", "groupingColumns", "rfunction", "signature", "numBatches")))
  
    # the argument list to pass to rfunction
    parmlist <- arglist[-ignored]
    parmlist <- sapply(parmlist, eval)
  
    # serialize the argument list
    bigr.parmlist <- base64encode(serialize(parmlist, connection=NULL, ascii=FALSE))
  
    # send the argument list to Jaql server
    arglistname <- streamfunc %++% "_arglist"
    arglistPair <- arglistname %++% "='" %++% bigr.parmlist %++% "'"
    .bigr.execUpdate(arglistPair)
  
    # generate the unique temporary directory name for this function
    jaqlExpression <- "logdir := bigrGetFilename('/tmp/bigr', 'groupApply', 'd'); logdir"
    logdir <- .bigr.execQuery(jaqlExpression)
    if (is.null(logdir)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # create the logdir
    jaqlExpression <- "hdfsShell('-mkdir " %++% logdir %++% "')"
    jaqlret <- .bigr.execQuery(jaqlExpression)
    if (0 > jaqlret) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # the current log filename
    logfile <- logdir %++% "/R.log"
    
    # save the current log filename in the bigr.env
    bigr.env$LOGDIR <- logdir
    bigr.env$LOGFILE <- logfile

    # get the colname
    columnNames <- base64encode(serialize(colnames(data), connection=NULL, ascii=FALSE))
    
    # construct the groupApply_rFunc
    if (!is.null(signature) && ("data.frame" == class(signature))) {
        sigcheck <- paste(deparse(signature), collapse='')
        groupApply_rFunc <- "groupApply_rFunc=" %++% "bigrGetRFunc_groupRowApply_dataframe('" %++% streamfunc %++% "', '" %++% rfunction %++% "', '" %++% columnNames %++% "', '" %++% arglistname %++% "', '" %++% bigr.parmlist %++% "', '" %++% scon %++% "', '" %++% logdir %++% "', '" %++% sigcheck %++% "')"
    }
    else {
        groupApply_rFunc <- "groupApply_rFunc=" %++% "bigrGetRFunc_groupRowApply('" %++% streamfunc %++% "', '" %++% rfunction %++% "', '" %++% columnNames %++% "', '" %++% arglistname %++% "', '" %++% bigr.parmlist %++% "', '" %++% scon %++% "', '" %++% logdir %++% "')"
    }
    .bigr.execUpdate(groupApply_rFunc)
  
    # retrieve data types from the grouping columns
    numColumns <- ifelse("Batching" == typeOfGA, 0, ifelse("list" == class(groupingColumns), length(groupingColumns), 1))
  
    # generate the coltype and colname for the log file
    bigr.env$LOGCOLTYPE <- rep("character", numColumns+2)
    logColnames <- rep("group", numColumns)
    bigr.env$LOGCOLNAME <- c("status", paste(logColnames, seq_along(logColnames), sep=""), "logfile")
    
    # generate the temporary unique output filename
    jaqlExpression <- "csvout := bigrGetFilename(logdir, 'groupApply', 'csv'); csvout"
    csvout <- .bigr.execQuery(jaqlExpression)
    if (is.null(csvout)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }

    # warning that the factors in data.frame will be treated as characters
    if (!is.null(signature) && ("data.frame" == class(signature))) {
        if ("factor" %in% coltypes(signature))
            bigr.warn(logSource, "Factor(s) in signature are implicitly treated as character(s).")
    }
    
    # run the query on BigInsights server
    # generate the output schema from rfunction
    if (!is.null(signature) && ("data.frame" == class(signature))) {
        # user wants to return a bigr.frame
        sigclasses <- sapply(signature, class)
        jaqlType <- sapply(sigclasses, .bigr.getJaqlType)
        jaqlType <- paste("data",seq_along(jaqlType),":",jaqlType,"?",sep="",collapse=", ")
        outSchema <- paste("schema {", jaqlType, "}", sep="")
    }
    else {
        # user wants to return a bigr.list
        outSchema <- "schema {data : string}"
    }
    
    # generate log schema and grouping columns for Jaql statement
    if (0 == numColumns) {
        logSchema <- "schema {status : string, logfile : string}"
    }
    else if (1 == numColumns) {
        # grouping on single bigr.vector column
        if ("list" == class(groupingColumns)) {
            columns <- "[" %++% groupingColumns[[1]]@columnExpression %++% "]"
        }
        else {
            columns <- "[" %++% groupingColumns@columnExpression %++% "]"
        }
        if ("GroupingAndBatching" == typeOfGA) {
            grouptx <- "group1 : ($.group)[0]"
        }
        else if ("Grouping" == typeOfGA) {
            grouptx <- "group1 : group[0]"
        }
        logSchema <- "schema {status : string, group1 : string, logfile : string}"
        
    }
    else {
        # for list of bigr.vector, build the list of groups to be grouped
        # on the Jaql server
        columns <- sapply(groupingColumns, function(x) {x@columnExpression})
        columns <- paste(columns, collapse=", ")
        columns <- paste("[",columns,"]",sep="")
        
        if ("GroupingAndBatching" == typeOfGA) {
            grouptx <- rep("($.group)[", length(groupingColumns))
            grouptx <- paste("group",seq_along(grouptx),":",grouptx,seq_along(grouptx)-1, "]",sep="",collapse=", ")
        }
        else if ("Grouping" == typeOfGA) {
            grouptx <- rep("group[", length(groupingColumns))
            grouptx <- paste("group",seq_along(grouptx),":",grouptx,seq_along(grouptx)-1, "]",sep="",collapse=", ")
        }
        logSchema <- rep("string", length(groupingColumns))
        logSchema <- paste("group",seq_along(logSchema),":",logSchema,"?",sep="",collapse=", ")
        logSchema <- paste("schema {status:string,",logSchema,",logfile:string}",sep="")
    }
    
    # generate the input and result schemas for the R external function
    inputSchema <- .bigr.frame.jaqlInputSchema(data)
    resultSchema <- "schema [{status : string, " %++% substring(outSchema, 9, nchar(outSchema) - 1) %++% ", logfile : string}*]"

    # retrieve timeout option
    timeout <- getOption("bigr.r.timeout")
    if (is.null(timeout)) {
        timeout <- 180000
    }
    else {
        timeout <- as.numeric(timeout)
        if (is.na(timeout)) {
            timeout <- 180000
        }
    }
    
    # ask Jaql to generate the function to run rfunction
    jaqlExpression <- "insc = " %++% inputSchema %++% "; outsc = " %++% resultSchema %++% "; groupApply = externalRFn(rFunction=groupApply_rFunc, parameters=insc, result=outsc, timeout=" %++% timeout %++% ")"
    .bigr.execUpdate(jaqlExpression)
    
    # ask Jaql to generate the groupApply function
    if (is.null(signature) || ("data.frame" != class(signature))) {
        if (numColumns > 0) {
            # for bigr.list, since we don't care the group types, all are written and read as strings
            if ("list" == class(groupingColumns)) {
                outSchema <- rep("string", length(groupingColumns))
                outSchema <- paste("group",seq_along(outSchema),":",outSchema,sep="",collapse=", ")
            }
            else {
                outSchema <- "group1 : string"
            }
        
            outSchema <- paste("schema {", outSchema, ", data:string}", sep="")
        }
        
        if ("Grouping" == typeOfGA) {
            jaqlExpression <- "bigrGetGroupApplyFn(groupApply, '" %++% columns %++% "', '" %++% grouptx %++% "', csvout, " %++% outSchema %++% ", '" %++% logfile %++% "', '" %++% logSchema %++% "')"
        }
        else if ("GroupingAndBatching" == typeOfGA) {
            jaqlExpression <- "bigrGetBatchGroupApplyFn(groupApply, " %++% numBatches %++% ", '" %++% columns %++% "', '" %++% grouptx %++% "', csvout, " %++% outSchema %++% ", '" %++% logfile %++% "', '" %++% logSchema %++% "')"            
        }
    }
    else {
        # going to return a bigr.frame
        if ("GroupingAndBatching" == typeOfGA) {
            jaqlExpression <- "bigrGetBatchGroupApplyFn_dataframe(groupApply, " %++% numBatches %++% ", '" %++% columns %++% "', '" %++% grouptx %++% "', csvout, " %++% outSchema %++% ", '" %++% logfile %++% "', '" %++% logSchema %++% "')"
        }
        else if ("Grouping" == typeOfGA) {
            jaqlExpression <- "bigrGetGroupApplyFn_dataframe(groupApply, '" %++% columns %++% "', '" %++% grouptx %++% "', csvout, " %++% outSchema %++% ", '" %++% logfile %++% "', '" %++% logSchema %++% "')"
        }
        else {
            jaqlExpression <- "bigrGetBatchApplyFn_dataframe(groupApply, " %++% numBatches %++% ", csvout, " %++% outSchema %++% ", '" %++% logfile %++% "', '" %++% logSchema %++% "')"
        }
    }
    groupApplyFn <- .bigr.execQuery(jaqlExpression)
    if (is.null(groupApplyFn)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # run the groupApply on server
    jaqlExpression <- "res = " %++% .bigr.getJaqlExpression(data) %++% "->" %++% as.character(groupApplyFn)
    jaqlret <- .bigr.execQuery(jaqlExpression)
    if (is.null(jaqlret)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # Create a environment that holds metadata for any temporary files, and 
    # register a finalizer for it. These files will be removed when the environment
    # cannot be accessed.                        
    e <- new.env(parent = emptyenv())
    e$finals <- logdir
    reg.finalizer(e, .bigr.remove.files)
    envs <- list(e)
    
    # return either bigr.list or bigr.frame object
    if (is.null(signature) || ("data.frame" != class(signature))) {
        # read the .csv and generate the bigr.list
        result <- new (bigr.env$LIST_CLASS_NAME, dataSource=bigr.env$TEXT_FILE, dataPath=as.character(csvout), groupColumns=numColumns,
                       envs = envs)
    }
    else {
        # return bigr.frame
        result <- new (bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TEXT_FILE, dataPath=as.character(csvout), delimiter=",", colnames=names(signature), 
                       coltypes=sapply(signature, function(x) {if(class(x)=="factor") "character" else class(x)}), header=FALSE,
                       localProcessing = data@localProcessing, envs = envs)
    }
    
    if (!is.null(result)) {
        result@logInfo <- list(bigr.env$LOGFILE, bigr.env$LOGCOLNAME, bigr.env$LOGCOLTYPE)
    }
    else {
        bigr.err(logSource, "Failed to initialize the BigR dataset object...")
    }
    
    # log time and print
    dt <- difftime(Sys.time(), b4);
    cat("groupApply ran for " %++% round(dt,2) %++% units(dt) %++% "\n");
    
    # return message so that users know what to check
    capture.output({logs <- bigr.logs(result)})
    wlen <- length(grep('Warning', logs[[1]]))
    elen <- length(grep('Error', logs[[1]]))
    if ((wlen > 0) || (elen > 0)) {
        warning(wlen %++% " warnings and " %++% elen %++% " errors encountered. Use bigr.logs() to examine R execution logs.", call.=FALSE)
    }
    
    return(result)
}
