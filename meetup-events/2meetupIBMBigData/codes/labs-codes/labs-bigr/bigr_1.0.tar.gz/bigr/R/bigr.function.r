#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' Class bigr.function
#'
#' This class serves as an interface between R and JaQL functions. It provide mechanism to
#' register and call JaQL functions in R, given their name, arguments, and return types. 
#'
#'@section Slots:
#'  \describe{
#'    \item{\code{jaqlName}:}{\code{character} value specifying the name of the JaQL function}
#'    \item{\code{rName}:}{\code{character} value specifying the corresponding name of the function in R}
#'    \item{\code{argNames}:}{a \code{vector} of \code{character} values specifying the names of the function arguments}
#'    \item{\code{argTypes}:}{a \code{vector} of \code{character} values specifying the types of the function arguments}
#'    \item{\code{returnType}:}{\code{character} value specifying the return type of the function}
#'  }
#' @name bigr.function
#' @rdname bigr.function
#' @exportClass bigr.function
#' @keywords internal
setClass(bigr.env$FUNCTION_CLASS_NAME,
     representation(
         jaqlName = "character",
         rName = "character",
         argNames = "vector",
         argTypes = "vector",
         returnType = "character",
         returnAsVector = "logical"
     )        
)

#' Registers a customized JaQL function in BigR
#' 
#' @param rName the R function name
#' @param jaqlName the JaQL function name
#' @param argNames the names of the arguments
#' @param argTypes the data types of the arguments
#' @param returnType the return type of the function
#' @param returnAsVector the return value is coerced into a R vector using as.vector()
#' @return a boolean value indicating whether the function was successfully registered
#' @keywords internal
bigr.registerFn <- function(rName, jaqlName, argNames, argTypes, returnType, returnAsVector = F, is.generic=FALSE, fnEnv=.GlobalEnv) {
    logSource <- "bigr.registerFn"
    if (missing(rName)) {
        name <- NULL
    }
    if (missing(jaqlName)) {
        jaqlName <- rName
    }
    if (missing(argNames)) {
        argNames <- NULL
    }
    if (missing(argTypes)) {
        argTypes <- NULL
    }
    if (missing(returnType)) {
        returnType <- NULL
    }    
    if (.bigr.isNullOrEmpty(rName)) {
        bigr.err(logSource, "An R name is required in order to register a function.")
    }
    if (.bigr.isNullOrEmpty(jaqlName)) {
        bigr.err(logSource, "A JaQL name is required in order to register a function.")
    }
    if (.bigr.isNullOrEmpty(argNames)) {
        argNames <- ""
    }
    
    # Check that the data types are supported
    if (.bigr.isNullOrEmpty(argTypes)) {
        argTypes <- ""
        if (is.generic == TRUE) {
            bigr.err(logSource, "Cannot define a generic method with no parameters.")
        }
    } else if (!(all(argTypes %in% c(bigr.env$SUPPORTED_DATA_TYPES, "ANY")))) {
        bigr.err(logSource, "An unsupported data type was found in the argument definition.")
    }
    
    if (.bigr.isNullOrEmpty(returnType)) {
        bigr.err(logSource, "Return type must be specified.")
    }
    bigr.info(logSource, "Registering function: '" %++% rName %++% "'")
    
    # Check jaqlName
    if (!.bigr.validIdentifier(jaqlName)) {
        bigr.err(logSource, "Invalid JaQL function name: '" %++% jaqlName %++% "'")
    }
    # Check that argument names and types have the same length
    if (length(argTypes) != length(argNames)) {
        bigr.err(logSource, "Argument names and types must have the same length")
    }
    
    # Create bigr.function object 
    fn <- new(bigr.env$FUNCTION_CLASS_NAME, rName=rName, jaqlName=jaqlName, 
              argNames=argNames, argTypes=argTypes, returnType=returnType, returnAsVector=returnAsVector)    
    
    # The environment where the function will be placed
    #fnEnv <- parent.env(environment())
    
    fnInstruction <- NULL
    params <- paste(argNames, collapse=", ")    
    fnDef <- "function(" %++% params %++% ") {\n" %++%
        "args <- as.list(match.call(call=match.call()));\n" %++%
        "args[[1]] <- as.character(args[[1]]);\n" %++% 
        "do.call('bigr.callFn', args);\n" %++%
        "}\n"
    if (!is.generic) {
        fnInstruction <- fn@rName %++% " <- " %++% fnDef 
        eval(parse(text=fnInstruction), envir=fnEnv)        
    } else {            
        types <- paste(argNames %++% "='" %++% argTypes %++% "'", collapse=", ")
        paste(argTypes, collapse=", ")        
        
        ###################################################
        # Define generic method with atomic type parameters
        ###################################################
        
        fnExists <- FALSE
        #if (!isGeneric(fn@rName)) 
        #{        
            # Check if the function is already defined            
            if (exists(fn@rName)) {            
                if (is.function(eval(parse(text=fn@rName), envir=fnEnv))) {
                    fnExists <- TRUE
                    fnInstruction <-
                        "setGeneric('" %++% fn@rName  %++% "'); \n"                    
                }
            }
            # If the function was not defined priorly
            if (is.null(fnInstruction)) {
                fnInstruction <- "setGeneric('" %++% fn@rName  %++% "', def=" %++% fnDef %++% "); \n"
            }        
            bigr.info(logSource, fnInstruction)        
            eval(parse(text=fnInstruction), envir=fnEnv)
        #}
        #########################################################################
        # Define methods for all possible combination of atomic/bigr.vector types
        #########################################################################
        if (!.bigr.isNullOrEmpty(argTypes)) {
            typeComb <- .bigr.generateParameterTypeCombinations(argTypes)        
            # Remove the first combination (all atomic types) if the function already
            # existed. This is to prevent overwriting R functions.
            if (fnExists) {
                typeComb[[1]] <- NULL
            }
            for (i in 1:length(typeComb)) {
                signature <- paste(argNames %++% "='" %++% typeComb[[i]] %++% "'", collapse=", ")
                fnInstruction <-                
                    "setMethod('" %++% fn@rName %++% "', signature(" %++% signature %++% "),\n" %++%
                    fnDef %++%
                    "\n)"
                bigr.info(logSource, fnInstruction)        
                eval(parse(text=fnInstruction), envir=fnEnv)
                
            }
        }
    }
    
    # Assign the function to the package environment
  #  envirInstruction <- "environment(" %++% fn@rName %++% ") <- as.environment('package:" %++% bigr.env$PACKAGE_NAME %++% "')"
  #  bigr.info(logSource, envirInstruction)
  #  eval(parse(text=envirInstruction), envir=as.environment("package:" %++% bigr.env$PACKAGE_NAME))
    
    # Add the function to the global list of registered functions
    bigr.env$REGISTERED_FUNCTIONS[[rName]] <- fn
    bigr.info(logSource, "Successfully registered!")
    return(TRUE)
}

#' Invokes a previously registered customized function
#' 
#' @param rName the name of the function
#' @param ... the function arguments in the same order as in the JaQL function
#' @keywords internal
bigr.callFn <- function(rName, ...) {
    logSource <- "bigr.callFn"
    
    # Obtain the list of arguments
    arglist <- as.list(match.call())
    bigr.info(logSource, "Argument list: ")
    bigr.infoShow(logSource, arglist)    
    
    # Check the specified rName
    if (.bigr.isNullOrEmpty(rName)) {
        bigr.err(logSource, "Invalid function name.")
    }
    
    
    # Obtain the corresponding function object from the list of
    # registered functions.
    fn <- bigr.env$REGISTERED_FUNCTIONS[[rName]]
    
    # If the function was not found, throw an error
    if (.bigr.isNullOrEmpty(fn)) {
        bigr.err(logSource, "Function '" %++% rName %++% "' has not been registered.")
    }
    #######################################################################
    # Obtain the values of the arguments to be passed to the JaQL function
    #######################################################################
    
    # The tableExpression for the resulting bigr.vector
    tableExpression <- NULL            
    
    # The column expression for the resulting bigr.vector
    columnExpression <- NULL
    
    # A list of the argument values which will be filled using eval() function
    fnArgValues <-list()
    
    # Assemble a list of environments that the return might reference
    envs <- list()

    # If the function has no arguments
    if (.bigr.isNullOrEmpty(fn@argNames)) {
        columnExpression <- fn@jaqlName %++% "()"
    
    # If the function has at least one argument
    } else {
        # Check the number of arguments. Notice the first two arguments in arglist are
        # "bigr.callFn" and the rName
        if (length(fn@argNames) != length(arglist) - 2) {
            bigr.err(logSource, "Invalid number of arguments. " %++% length(fn@argNames) %++%
                         " were expected but " %++% (length(arglist) - 2) %++% " were found.")
        }
        
        # Obtain the corresponding value for each argument name
        for (i in 1 : length(fn@argNames)) {
            fnArgValues[[i]] <- eval(arglist[[i + 2]], sys.parent())
            if (class(fnArgValues[[i]]) == bigr.env$VECTOR_CLASS_NAME) {
                bv <- fnArgValues[[i]]
                envs <- c(envs, bv@envs)
                if (is.null(tableExpression)) {
                    tableExpression <- bv@tableExpression
                } else if (bv@tableExpression != tableExpression) {
                    bigr.err(logSource, "All bigr.vector arguments must be from the same data origin.")
                } 
                if ((fn@argTypes[i] != "ANY") & (fn@argTypes[i] != bv@dataType)) {
                    bigr.err(logSource, "Invalid data type for parameter '" %++% fn@argNames[i] %++% "'. '" %++% fn@argTypes[i] %++% 
                                 "' was expected" %++% " yet '" %++% bv@dataType %++% "' was found.")
                }
            } else if (class(fnArgValues[[i]]) != fn@argTypes[i]) {
                bigr.err(logSource, "Invalid data type for parameter '" %++% fn@argNames[i] %++% "'. '" %++% fn@argTypes[i] %++% 
                                "' was expected" %++% " yet '" %++% class(fnArgValues[[i]]) %++% "' was found.")
            }
        }
        bigr.info(logSource, "Argument values: ")
        bigr.infoShow(logSource, fnArgValues)
        
        # Build the JaQL column expression 
        columnExpression <- fn@jaqlName %++% "(" %++% 
            paste(.bigr.getColumnExpressions(fnArgValues), collapse=", ") %++% ")"    
    }    
    bigr.info(logSource, columnExpression)
    bvName <- fn@rName %++% "(" %++% paste(unlist(arglist)[3:length(arglist)], collapse = ", ") %++% ")"
    
    # Add some dummy value to the table expression in the case of all parameters being constant. 
    # E.g., mod(1,2) will be translated to [[]] -> transform mod(1,2). 
    if (.bigr.isNullOrEmpty(tableExpression)) {
        tableExpression <- bigr.env$EMPTY_TABLE_EXPRESSION
    }

    result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", 
                      name=bvName, dataType=fn@returnType, envs=envs)
    result@tableExpression <- tableExpression
    result@columnExpression <- columnExpression
    
    if (fn@returnAsVector)
        return (as.vector(result))
    else
        return (result)  
}

# This function returns the column expressions for a list of objects (bigr.dataset's or atomic data types)
.bigr.getColumnExpressions <- function(list) {
    if (.bigr.isNullOrEmpty(list)) {
        return(NULL)
    }
    output <- vector()
    i <- 1
    for (element in list) {
        
        # If the current element is a bigr.dataset, get its column expression
        if (inherits(element, bigr.env$DATASET_CLASS_NAME)) {
            output[i] <- element@columnExpression
        # If the current element is NULL/NA, use JaQL's null    
        } else if (is.null(element) | is.na(element)) {
            output[i] <- "null"
        # If the current element is an atomic data type, get its JaQL equivalent    
        } else if (class(element) %in% bigr.env$SUPPORTED_DATA_TYPES) {
            output[i] <- .bigr.getOperand(element)
        }
        i <- i + 1
    }
    return(output)
}

# This function generates all possible combinations of parameter data types
# (either bigr.vector or an atomic data type)
.bigr.generateParameterTypeCombinations <- function(argTypes) {
    k <- length(argTypes)
    combList <- list()
    n <- 2^k - 1
    for (i in 0:n) {
        t <- i
        comb <- argTypes
        j <- 1
        while (t > 0) {
            if (t %% 2 == 1) {
                comb[j] <- bigr.env$VECTOR_CLASS_NAME
            }
            j <- j + 1
            t <- floor(t / 2)
        }
        combList[[i + 1]] <- comb
    }
    return(combList)
}
