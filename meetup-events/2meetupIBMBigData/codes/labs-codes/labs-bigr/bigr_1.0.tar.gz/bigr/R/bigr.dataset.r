#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' Class bigr.dataset
#'
#' This class represents a proxy to a big data source, which could be a text file,
#' or a BigSQL data source. Classes \code{bigr.frame} and \code{bigr.vector}
#' extend from this class. \code{bigr.dataset} is a virtual class so it cannot be instantiated.
#'
#'@section Slots: 
#'  \describe{
#'    \item{\code{dataSource}:}{\code{"character"} value specifying the big data source. It could be either BIG_SQL or TEXT}
#'    \item{\code{dataPath}:}{\code{"character"} value specifying the big data location.}
#'    \item{\code{delimiter}:}{\code{"character"} value specifying the delimiter if dataSource is set to TEXT}
#'    \item{\code{header}:}{\code{"logical"} value specifying whether or not the dataset has headers if dataSource is set to TEXT}
#'    \item{\code{tableExpression}:}{\code{"character"} for internal use of BigR}
#'    \item{\code{columnExpression}:}{\code{"character"} for internal use of BigR}
#'    \item{\code{na.string}:}{if specified, all occurrences of the value of na.string will be interpreted as NA.}
#'    \item{\code{localProcessing}:}{\code{"logical"} value. MapReduce mode will be only used if set to \code{FALSE}.}
#'    \item{\code{logInfo}:}{\code{"list"} value saving the output/message logging info related to the bigr.frame or bigr.list objects}
#'    \item{\code{envs}:}{\code{"list"} list of environments referenced by the dataset object}
#'  }
#' @name bigr.dataset
#' @rdname bigr.dataset
#' @exportClass bigr.dataset
#' @keywords internal
setClass(bigr.env$DATASET_CLASS_NAME,
    representation(
        dataSource = "character", 
        dataPath = "character",
        delimiter = "character", 
        header = "logical",
        na.string = "character",
        localProcessing = "logical",
        tableExpression = "character",
        columnExpression = "character",
        rowCount = "numeric",
        logInfo = "list",
        envs = "list",
        "VIRTUAL"
    )    
)

#' \code{bigr.dataset.constructor} initializes a bigr.dataset with the specified parameters.
#'
#' @param dataSource the data source, i.e., either BIG_SQL or TEXT_FILE
#' @param dataPath the data location
#' @param delimiter the delimiter character if the data source is TEXT_FILE
#' @param header a boolean value indicating whether or not the data has headers
#' @param envs list of environments referenced by the object being constructed
#' @return a dataset initialized with the specified parameters
#' @keywords internal
bigr.dataset.constructor <- function(.Object, dataSource=NULL, dataPath="", delimiter="", 
                                     header=FALSE, na.string="", localProcessing=FALSE,
                                     envs) { 
    logSource <- "init-bigr.dataset"
    bigr.info(logSource, "Initializing bigr.dataset...")
    
    # Check that the connection is active
    if (is.null(bigr.env$CONNECTION)) {
        bigr.err(logSource, "The connection to BigInsights has not been established.")
    }
    if (!is.bigr.connected()) {
        bigr.err(logSource, "The connection to BigInsights has not been established.")
    }
    
    # Check dataSource
    if (.bigr.isNullOrEmpty(dataSource) | class(dataSource) != "character") {
        bigr.err(logSource, "Invalid data source.")
    }
    if (!(dataSource %in% bigr.env$DATA_SOURCES)) {
        bigr.err(logSource, "Invalid data source: '" %++% dataSource %++% "'.")
    }

    # Check dataPath only if the dataSource is not TRANSFORM
    if (dataSource != bigr.env$TRANSFORM) {
        if (.bigr.isNullOrEmpty(dataPath) | class(dataPath) != "character") {
            bigr.err(logSource, "Invalid data path.")
        }
    }
    
    # Check delimiter
    if (dataSource == bigr.env$BIG_SQL) {
        if (! .bigr.isNullOrEmpty(delimiter)) {
            bigr.err(logSource, "Argument 'delimiter' should not be specified for a BigSQL data source.")
        }
        delimiter <- bigr.env$DEFAULT_DELIMITER
    } else if (.bigr.isNullOrEmpty(delimiter)) {
        delimiter <- bigr.env$DEFAULT_DELIMITER
        # bigr.warn(logSource, "Delimiter was not specified. Default delimiter '" %++% delimiter %++% "' will be used")
    }
    if (class(delimiter) != "character" || nchar(delimiter) != 1) {
        bigr.err(logSource, "Invalid delimiter.")
    }
        
    # Check header
    if (dataSource != bigr.env$TEXT_FILE) {
        if (!missing(header) && header) {
            bigr.err(logSource, "Argument 'header' should only be specified for text files, not for " %++% dataSource)
        }            
    } else {        
        if (.bigr.isNullOrEmpty(header) | class(header) != "logical") {
            bigr.err(logSource, "Invalid header value.")
        }
        .Object@header <- header
    }

    # Check na.string
    if (.bigr.isNullOrEmpty(na.string)) {
        .Object@na.string <- bigr.env$DEFAULT_NA_STRING
    } else if (class(na.string) == "character") {
        .Object@na.string <- na.string
    } else {
        bigr.err(logSource, "Invalid value for argument 'na.string'. A 'character' value is expected.")
    }
    
    # Check localProcessing
    if (.bigr.isNullOrEmpty(localProcessing)) {
        .Object@localProcessing <- bigr.env$DEFAULT_LOCAL_PROCESSING
    } else {
        if (class(localProcessing) != "logical") {
            bigr.err(logSource, "Invalid value for argument 'localProcessing'. A 'boolean' value is expected.")
        } else {
            .Object@localProcessing <- localProcessing
        }
    }
    
    # For flat files, add a prefix to dataPath. This is useful during Big R testing
    if (dataSource == bigr.env$TEXT_FILE & substring(dataPath, 1, 1) != "/") {
        prefix <- getOption("bigr.dataPath.prefix")
        if (! is.null(prefix)) {
            bigr.info(logSource, "Adding bigr.dataPath.prefix " %++% prefix %++% " to dataPath: " %++% dataPath)
            dataPath <- prefix %++% dataPath
        }
    }

    # If "envs" is not specified, don't proceed!
    if (missing(envs)) {
        bigr.err(logSource, "INTERNAL ERROR: 'envs' not specified.")
    }

    # Assign object attributes
    .Object@dataSource <- dataSource
    .Object@dataPath <- dataPath
    .Object@delimiter <- delimiter
    .Object@columnExpression <- "" 
    .Object@tableExpression <- ""
    .Object@rowCount <- -1    
    .Object@logInfo <- list()
    .Object@envs <- envs
    
    bigr.info(logSource, "<OK>")
    return(.Object)
}

# Assembles the JaQL query for the given dataset based upon the corresponding
# columnExpression and tableExpression.
.bigr.getJaqlExpression <- function(ds) {
    if (missing(ds)) {
        ds <- NULL
    }
    if (.bigr.isNullOrEmpty(ds)) {
        return(NULL)
    }
    if (!inherits(ds, bigr.env$DATASET_CLASS_NAME)) {
        return(NULL)
    }
    if (.bigr.isNullOrEmpty(ds@columnExpression)) {
        return(ds@tableExpression)
    } else {
        return(ds@tableExpression %++% " -> transform [" %++% ds@columnExpression %++% "]")
    }
}

#' \code{head} returns the first n elements of the dataset.
#' If n is not specified, the default value MAX_HEAD_ROWS will be used.
#' @param x a bigr.dataset
#' @param n the number of elements to be returned
#' @return the first n elements of the dataset
setGeneric("head")
setMethod("head", signature = bigr.env$DATASET_CLASS_NAME, definition = 
    function(x, n) {
        logSource <- "head"
        if (missing(n)) {
            n <- bigr.env$DEFAULT_HEAD_ROWS
        }
        if (!.bigr.is.integer(n) | n < 1) {
            bigr.err(logSource, "Invalid number of rows: " %++% n)
        }
        if (!is.null(x)) {            
    
            # Create a replica of the original dataset, using TRANSFORM as dataSource
            result <- x
            result@dataSource <- bigr.env$TRANSFORM
            
            # Update the table expression and column expression for the 
            # resulting dataset
            result@tableExpression <- x@tableExpression %++% " -> top " %++% n
            result@columnExpression <- x@columnExpression
            return(result)
        } else {
            return(NULL)
        }        
    }
)

#' \code{tail} returns the last n elements of the dataset.
#' If n is not specified, the default value MAX_HEAD_ROWS will be used
#' @param x a bigr.dataset
#' @param n the number of elements to be returned
#' @return the last n elements of the dataset
setGeneric("tail")
setMethod(f = "tail", signature = bigr.env$DATASET_CLASS_NAME, definition = 
    function(x, n) {
        logSource <- "head"
        if (missing(n)) {
            n <- bigr.env$DEFAULT_HEAD_ROWS
        }
        if (!.bigr.is.integer(n) | n < 1) {
            bigr.err(logSource, "Invalid number of rows: " %++% n)
        }
        if (!is.null(x)) {
            
            # Create a replica of the original dataset, using TRANSFORM as dataSource
            result <- x
            result@dataSource <- bigr.env$TRANSFORM
            
            # Cache the count and pass it to lastK
            nrow <- .bigr.count(result)
            
            # Update the table expression and column expression for the 
            # resulting dataset
            result@tableExpression <- x@tableExpression %++% " -> lastK(" %++% n %++% ", " %++% nrow %++% ")"            
            result@columnExpression <- x@columnExpression
            return(result)
        } else {
            return(NULL)
        }        
    }    
)    

# Returns the number of elements of a dataset. In the case of bigr.frames, it will
# return the number of rows. This function is internally invoked by nrow (for bigr.frame's)
# and length (for bigr.vector's).
# Two optimizations are included:
# 1. A cache is maintained in bigr.env$COUNT_CACHE.  This is a list indexed by tableExpression.
# 2. If reading from a text file, lines() input adapter will be used instead of del().
.bigr.count <- function(x) {
    logSource <- "bigr.dataset.count"
    bigr.info(logSource, "Counting...")
    if (missing(x)) {
        x <- NULL
    }
    if (!.bigr.isNullOrEmpty(x)) {
        cachedCount <- bigr.env$COUNT_CACHE[[x@tableExpression]]
       
        # If the count has not been calculated yet
        if (is.null(cachedCount)) {            
            jaqlExpression <- .bigr.getJaqlExpression(x) %++% " -> group into count($)"
            df <- .bigr.executeJaqlQuery(jaqlExpression, limit=FALSE)
            if (.bigr.isNullOrEmpty(df)) {
                bigr.err(logSource, "Could not calculate the number of rows")
            } else {
                count <- as.integer(df[1,1])
                
                # Store the count in the cache
                bigr.env$COUNT_CACHE[[x@tableExpression]] <- count                
                return(count)
            }
        # If the count is already cached, it will be returned right away, so
        # no query will be executed.
        } else {
            return(cachedCount)
        }        
    }
}

#' Export (copy) a temporary bigr object into a named, persistent object.
#'
#' @param dataset a bigr.frame, bigr.vector or bigr.list that needs to be turned into
#' a persistent object.
#' @param dataSource the output data source (either TEXT_FILE, or BIGSQL)
#' @param dataPath the output data location
#' @param header whether or not the output will contain headers (only for text files)
#' @param delimiter the delimiter character (only for text files)
#' @return the new object of the persisted dataset
bigr.persist <- function(dataset, dataSource=bigr.env$TEXT_FILE, dataPath, header, delimiter, useMapReduce) {
    logSource <- "bigr.persist"
    
    # Check for missing parameters and assign default values
    if (missing(header)) {
        header <- FALSE
    }
    if (missing(delimiter)) {
        delimiter <- bigr.env$DEFAULT_DELIMITER
    }

    # Check if the hidden option (bigr.use.map.reduce) is set. If so,
    # it overrides anything the user may have specified. This is only used during Big R
    # testing, and it allows us to gain some predictability in the output.
    useMapReduceOption <- getOption("bigr.use.map.reduce")
    if (! is.null(useMapReduceOption)) {
        useMapReduce <- useMapReduceOption
    }
    
    if (missing(useMapReduce)) {
        localProcessing <- bigr.env$DEFAULT_LOCAL_PROCESSING
    } else {
        localProcessing <- !useMapReduce
    }
    
    # make sure dataset exists
    if (missing(dataset)) {
        bigr.err(logSource, "Argument dataset is required.")
    }
    
    if (!(class(dataset) %in% c(bigr.env$FRAME_CLASS_NAME, bigr.env$VECTOR_CLASS_NAME, bigr.env$LIST_CLASS_NAME))) {
        # only support these three types of dataset
        bigr.err(logSource, "Argument dataset is invalid. Only bigr.frame, bigr.list and bigr.vector are supported.")
    }
    
    if ((bigr.env$FRAME_CLASS_NAME == class(dataset)) || (bigr.env$VECTOR_CLASS_NAME == class(dataset))) {
        # bigr.frame persist
        return (.bigr.frame.persist(dataset, dataSource, dataPath, header, delimiter, localProcessing))
    }
    else if (bigr.env$LIST_CLASS_NAME == class(dataset)) {
        # bigr.list persist
        return (.bigr.list.persist(dataset, dirname(dataPath), basename(dataPath)))
    }
    else {
        # TODO: bigr.vector persist
        return (NULL)
    }
}
