#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' \code{!} computes the negation of a logical bigr.vector.
#' @name NOT
#' @param \code{x} a \code{bigr.vector}
#' @return the logical negation of \code{x} as a bigr.vector
#' @rdname log_not
setGeneric("!")
setMethod("!", bigr.env$VECTOR_CLASS_NAME,
    function(x) {
        .bigr.unaryLogicOperation("!", x)
    }
)

#' \code{is.na} compares each element of a bigr.vector 
#' to \code{NA}.
#' 
#' @param x a bigr.vector
#' @return a bigr.vector with boolean values indicating whether each element in \code{x} is \code{NA}
#' @rdname log_na
setGeneric("is.na")
setMethod("is.na", bigr.env$VECTOR_CLASS_NAME,
    function(x) {
        .bigr.unaryComparisonOperation("is.na", x)
    }
)

#' Compares each element of a \code{bigr.vector} with 
#' every element in a given \code{vector}. The given \code{bigr.vector} and the
#' given \code{vector} must have the same data type.
#'
#' @name IN
#' @param x a bigr.vector
#' @param table a vector of values to be compared with
#' @return a bigr.vector of boolean values indicating whether each
#' element in \code{x} belongs to \code{table}
#' @rdname log_in
setGeneric("%in%")
setMethod("%in%", bigr.env$VECTOR_CLASS_NAME,
    function(x, table) {
        logSource <- "%in%"
        # TODO: If table >>, a join is preferred
        cond <- ""
        
        if (.bigr.isNullOrEmpty(table)) {
            bigr.err(logSource, "Parameter table must contain at least one value.")
        }
        # Append quote marks if strings are provided
        if (class(table) == "character") {
            table <- "'" %++% table %++% "'"
        }
        
        # Re-write %in% operator as a sequence of == operators combined with OR
        i <- 1
        while (i < length(table)) {
            cond <- cond %++% "(" %++% x@columnExpression %++% " == " %++% table[i] %++% ") or "            
            i <- i + 1
        }
        
        # Append the last condition, which does not include OR
        cond <- cond %++% "(" %++% x@columnExpression %++% " == " %++% table[length(table)] %++% ")"

		# Create the resulting bigr.vector
		result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", name=bigr.env$DEFAULT_COLNAMES, dataType="logical",
                              envs = x@envs)
		
        result@tableExpression <- x@tableExpression
        result@columnExpression <- "(" %++% cond %++% ")"
        return(result)
    }
)

#' Comparison operations (>, >=, <, <=, ==, !=) operate on two bigr.vectors, 
#' or on a bigr.vector and an atomic R value. The atomic values can be of 
#' type \code{character}, \code{logical}, \code{numeric}, or \code{integer}. 
#' These operators are typically used to construct filtering conditions on 
#' bigr.frames and bigr.vectors.
#' @title Comparison operators (>, >=, <, <=, ==, !=)
#' @name Comparison operators
#' @section Usage:
#' 
#'   \code{x op y}
#'   
#' @aliases > >= < <= == !=
#' @param x a bigr.vector
#' @param y a bigr.vector or an atomic R value
#' @return a bigr.vector of boolean values that represents the result of the 
#'   comparison operation between each element in \code{x} and each 
#'   corresponding element in \code{y}. If \code{y} is an R atomic data type,
#'   it is effectively replicated into a vector that has the same length as
#'   \code{x}.
#' @examples \dontrun{
#' air[air$UniqueCarrier == "HA",]
#' 
#' length(air$DepDelay[air$DepDelay >= 15])
#' }
#' @rdname rel_ops

setGeneric(">")
setMethod(">", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryRelationalOperation(">", e1, e2)
    }
)

setGeneric(">=")
setMethod(">=", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryRelationalOperation(">=", e1, e2)}
)

setGeneric("<")
setMethod("<", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryRelationalOperation("<", e1, e2)
    }
)

setGeneric("<=")
setMethod("<=", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryRelationalOperation("<=", e1, e2)
    }
)

setMethod("==", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryRelationalOperation("==", e1, e2)
    }
)

setGeneric("!=")
setMethod("!=", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryRelationalOperation("!=", e1, e2)
    }
)

#' "Logic" group generic functions compute logical operations (&, |)
#' on two bigr.vectors, or on a bigr.vector and an atomic R value of type \code{logical}.
#' 
#' @name Logic group generic functions
#' @title Logical operators (&, |)
#' @param e1 a bigr.vector
#' @param e2 a bigr.vector or an R atomic data type of type "logical"
#' @return a bigr.vector of type "logical" 
#' @examples \dontrun{
#' homesEastExpensive <- homes[homes$district == "east" & homes$saleprice > 500,]
#' homesEastorWest <- homes[homes$district == "east" | homes$district == "west",]}
#' @rdname logic_ops

setGeneric("&")
setMethod("&", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryLogicOperation("&", e1, e2)
    }
)

setGeneric("|")
setMethod("|", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryLogicOperation("|", e1, e2)
    }
)

#' \code{binaryRelationalOperation} is a generic function that performs any binary
#' relational operation between two bigr.vector's or a bigr.vector and a numeric value.
#' It is internally invoked by the <, <=, >, >=, =, and == operators. If both operators are bigr.vector's,
#' they are required to be from the same data origin or the same bigr.frame.
#' @param e1 a bigr.vector
#' @param e2 a bigr.vector or a numeric, character or logical value
#' @return a bigr.vector with the result of the relational 
#' @keywords internal
.bigr.binaryRelationalOperation <- function(operator, e1, e2) {
    logSource <- "binaryRelationalOperation"
    
    # If both operators are bigr.vectors, then they must come from the same
    # origin, i.e., same table expression
    if ((class(e1) == bigr.env$VECTOR_CLASS_NAME) && (class(e2) == bigr.env$VECTOR_CLASS_NAME)) {
        if (e1@tableExpression != e2@tableExpression) {
            bigr.err(logSource, "Cannot perform a relational operation on two " %++%
                         "big vectors from different data origins")
            return(NULL)
        }
    } else if ((class(e1) !=bigr.env$ VECTOR_CLASS_NAME) && (class(e2) != bigr.env$VECTOR_CLASS_NAME)) {
        bigr.err(logSource, "Binary relational operations are only for bigr.vector's")
        return(NULL)    
    
    # If only e1 is a bigr.vector
    } else if (class(e1) == bigr.env$VECTOR_CLASS_NAME) {
        if (e1@dataType == "numeric" | e1@dataType == "integer") {
            if (!.bigr.is.numeric.scalar(e2)) {
                bigr.err(logSource, "Type mismatch. A numeric value was expected but a '" %++% class(e2) %++% "' was found")
                return(NULL)
            }
        
        # If e1 is not a numeric bigr.vector, its dataType (either logical or character)
        # must match e2's type
        } else if (e1@dataType != class(e2)) {
            bigr.err(logSource, "Incompatible types: '" %++% e1@dataType %++% "' and '" %++%
                         class(e2) %++% "'")
            return(NULL)
        }
        
    # If only e2 is a bigr.vector
    } else if (class(e2) == bigr.env$VECTOR_CLASS_NAME) {
        if (e2@dataType == "numeric" | e2@dataType == "integer") {
            if (!.bigr.is.numeric.scalar(e1)) {
                bigr.err(logSource, "Type mismatch. A numeric value was expected but a '" %++% class(e1) %++% "' was found.")
                return(NULL)
            }
            
            # If e2 is not a numeric bigr.vector, its dataType (either logical or character)
            # must match e1's type
        } else if (class(e1) != e2@dataType) {
            bigr.err(logSource, "Incompatible types: '" %++% class(e1) %++% "' and '" %++% e2@dataType %++% "'")
            return(NULL)
        }
    }
    
    # Get operands and operator in the JaQL format
    x <- .bigr.getOperand(e1)
    y <- .bigr.getOperand(e2)
    operator <- .bigr.getJaqlLogicOperator(operator)
    if (is.null(operator)) {
        return(NULL)
    }

    envs <- list()
    if (inherits(e1, bigr.env$DATASET_CLASS_NAME))
        envs <- c(envs, e1@envs)
    if (inherits(e2, bigr.env$DATASET_CLASS_NAME))
        envs <- c(envs, e2@envs)
    
    # Create the resulting bigr.vector
    result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", name=bigr.env$DEFAULT_COLNAMES, dataType="logical",
                  envs = envs)
    result@tableExpression <- e1@tableExpression
    result@columnExpression <- "(" %++% x %++% " " %++% operator %++% " " %++% y %++% ")"
    return(result)
}

#' \code{binaryLogicOperation} is a generic function that performs any binary
#' logic operation between two bigr.vector's. It is internally invoked by the &, and | operators. 
#' Both bigr.vector's are required to be from the same data origin or the same bigr.frame.
#' @param e1 a bigr.vector
#' @param e2 a bigr.vector
#' @return a bigr.vector with the result of the relational operation
#' @keywords internal
.bigr.binaryLogicOperation <- function(operator, e1, e2) {
    logSource <- "binaryLogicOperation"
    
    # If both operators are bigr.vectors, then they must come from the same
    # origin, i.e., same table expression
    if ((class(e1) == bigr.env$VECTOR_CLASS_NAME) && (class(e2) == bigr.env$VECTOR_CLASS_NAME)) {
        if (e1@tableExpression != e2@tableExpression) {
            bigr.err(logSource, "Cannot perform a logic operation on" %++%
                      "two big vectors from different data origins")
            return(NULL)
        }
    } else if ((class(e1) != bigr.env$VECTOR_CLASS_NAME) && (class(e2) != bigr.env$VECTOR_CLASS_NAME)) {
        bigr.err(logSource, "Binary logical operations are only for bigr.vector's")
        return(NULL)
    }
    
    # Check that bigr.vector's are logic operators, since (a+b) & (b+c) does not make sense
    if (class(e1) == bigr.env$VECTOR_CLASS_NAME) {
        if (e1@dataType != "logical") {
            bigr.err(logSource, "Cannot perform a binary logic operation on non-logic expressions")
            return(NULL)
        }
    } else { # Check for constant values
        if (class(e1) != "logical" | length(e1) != 1) {
            bigr.err(logSource, "Cannot perform a binary logic operation a '" %++% class(e1) %++% "' operand")
            return(NULL)
        }
    }
    if (class(e2) == bigr.env$VECTOR_CLASS_NAME) {
        if (e2@dataType != "logical") {
            bigr.err(logSource, "Cannot perform a binary logic operation on non-logic expressions")
            return(NULL)
        }
    } else { # Check for constant values
        if (class(e2) != "logical" | length(e2) != 1) {
            bigr.err(logSource, "Cannot perform a binary logic operation a '" %++% class(e2) %++% "' operand")
            return(NULL)
        }
    }
    
    # Get operands and operator in the JaQL format
    x <- .bigr.getOperand(e1)
    y <- .bigr.getOperand(e2)
    operator <- .bigr.getJaqlLogicOperator(operator)
    if (is.null(operator)) {
        return(NULL)
    }
    
    envs <- list()
    if (inherits(e1, bigr.env$DATASET_CLASS_NAME))
        envs <- c(envs, e1@envs)
    if (inherits(e2, bigr.env$DATASET_CLASS_NAME))
        envs <- c(envs, e2@envs)

    # Create the resulting bigr.vector
	result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", name=bigr.env$DEFAULT_COLNAMES, dataType="logical",
                      envs = envs)
    result@tableExpression <- e1@tableExpression
    result@columnExpression <- "(" %++% x %++% " " %++% operator %++% " " %++% y %++% ")"
    return(result)
}


#' \code{unaryLogicOperation} is a generic function that performs any unary
#' arithmetic operation on a bigr.vector. It is internally invoked by the ! operator
#' @param x a bigr.vector
#' @return a bigr.vector with the result of the logic operation
#' @rdname internal.bigr.unaryLogicOperation
#' @keywords internal
.bigr.unaryLogicOperation <- function(operator, x) {
    logSource <- "unaryLogicOperation"
    if (class(x) != bigr.env$VECTOR_CLASS_NAME) {
        bigr.err(logSource, "Unary logic operations are only for bigr.vectors")
        return(NULL)
    }
    # Check that given bigr.vector is from an logic operation since
    # !(a+b) does not make sense
    if (x@dataType != "logical") {
        bigr.err(logSource, "Cannot perform a unary logic operation on a non-logical column.")
        return(NULL)
    }
    
    # Obtain operands and operator in the JaQL format
    operand <- .bigr.getOperand(x)
    operator <- .bigr.getJaqlLogicOperator(operator)
    if (is.null(operator)) {
        return(NULL)
    }
    
    # Create the resulting bigr.vector
	result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", 
                  name=bigr.env$DEFAULT_COLNAMES, dataType="logical", envs=x@envs)
    result@tableExpression <- x@tableExpression
    result@columnExpression <- operator %++% "(" %++% operand %++% ")"
    return(result)
}

#' \code{unaryComparisonOperation} is a generic function that performs any unary
#' comparison operation on a bigr.vector. It is internally invoked by the is.na operator
#' @param x a bigr.vector
#' @return a bigr.vector with the result of the comparison operation
#' @rdname internal.bigr.unaryComparisonOperation
#' @keywords internal
.bigr.unaryComparisonOperation <- function(operator, x) {
    logSource <- "unaryComparisonOperation"
    if (class(x) != bigr.env$VECTOR_CLASS_NAME) {
        bigr.err(logSource, "Unary comparison operations are only for bigr.vectors")
        return(NULL)
    } 
    
    # Obtain operands and operator in the JaQL format
    operand <- .bigr.getOperand(x)
    operator <- .bigr.getJaqlLogicOperator(operator)
    if (is.null(operator)) {
        return(NULL)
    }
    
    # Create the resulting bigr.vector
    result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", 
                  name=bigr.env$DEFAULT_COLNAMES, dataType="logical", envs=x@envs)
    result@tableExpression <- x@tableExpression
    result@columnExpression <- operator %++% "(" %++% operand %++% ")"
    return(result)
}

#' \code{ifelse} allows for recoding a bigr.vector or a bigr.frame's column(s) based on a given condition. 
#' The result will be returned as a new \code{bigr.vector} while the original column(s) will remain intact.
#' 
#' Nested \code{ifelse} constructs are also supported, and recode conditions may contain
#' different columns from the same bigr.frame.
#' 
#' @param test a logical bigr.vector specifying a condition
#' @param yes the recode value if the condition is TRUE
#' @return a recoded bigr.vector
setGeneric("ifelse")
setMethod("ifelse", bigr.env$VECTOR_CLASS_NAME,
    function(test, yes, no) {
        logSource <- "ifelse"
        
        # Check for parameter integrity
        if (missing(yes)) {
            yes <- NULL
        }
        if (missing(no)) {
            no <- NULL
        }        
        if (.bigr.isNullOrEmpty(test) | is.null(yes) | is.null(no)) {
            bigr.err(logSource, "ifelse cannot take NULL parameters")
            return(NULL)
        }
        
        # test must be a logical bigr.vector
        if (class(test) != bigr.env$VECTOR_CLASS_NAME) {
            bigr.err(logSource, "ifelse requires the given condition to be a logical bigr.vector")
            return(NULL)
        }        
        if (test@dataType != "logical") {
            bigr.err(logSource, "ifelse requires the given condition to be a logical bigr.vector")
            return(NULL)
        }
        
        # yes and no must have the same data type
        yesType <- NULL
        noType <- NULL
        if (class(yes) == bigr.env$VECTOR_CLASS_NAME) {
            yesType <- yes@dataType
        } else if (is.na(yes)) {
            yesType <- "NA"
        } else {
            yesType <- class(yes)
        }
        if (class(no) == bigr.env$VECTOR_CLASS_NAME) {
            noType <- no@dataType    
        } else if (is.na(no)) {
            noType <- "NA" 
        } else {
            noType <- class(no)
        }
        
        # If types do not match and none of yes and no are NA, then an error is thrown.
        if (yesType != noType &&
                (yesType != "NA" && noType != "NA")) {
            bigr.err(logSource, "The specified values for yes and no must have the same data type.")
        }
        resultType <- "character"
        
        # If any of yes or no are NA, they should be passed as null. Else,
        # yes/no could be bigr.vectors or primitive types, so the corresponding
        # JaQL operand expression should be obtained
        yesExp <- ""
        noExp <- ""
        if (yesType == "NA") {
            yesExp <- "null"
        } else {
            yesExp <- .bigr.getOperand(yes)
            resultType <- yesType
        }
        if (noType == "NA") {
            noExp <- "null"
        } else {
            noExp <- .bigr.getOperand(no)
            resultType <- noType
        }
        
        envs <- list()
        if (inherits(yes, bigr.env$DATASET_CLASS_NAME))
            envs <- c(envs, yes@envs)
        if (inherits(no, bigr.env$DATASET_CLASS_NAME))
            envs <- c(envs, no@envs)
        
        result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", 
                      name=bigr.env$DEFAULT_COLNAMES, dataType=resultType, envs=envs)
        result@tableExpression <- test@tableExpression
        result@columnExpression <- "if (" %++% test@columnExpression  %++% ") (" %++% yesExp %++% ") else (" %++% noExp %++% ")"
        return(result)
    }
)

# \code{getJaqlLogicOperator} maps R operators to JaQL operators.
# @param x an R operator
# @return the corresponding JaQL operator
.bigr.getJaqlLogicOperator <- function(op) {
    logSource <- "getJaqlLogicOperator"
    if (op == ">" || op == "<" || op == "<=" || op == ">=" || op == "==" || op == "!=") {
        return(op)
    } else if (op == "&") {
        return("and")
    } else if (op == "|") {
        return("or")
    } else if (op == "is.na") {
        return("isnull")
    } else if (op == "!") {        
        return("not")
    } else {
        bigr.err(logSource, "Operator '" %++% op %++% "' is not supported")
        return(NULL)
    }
}
