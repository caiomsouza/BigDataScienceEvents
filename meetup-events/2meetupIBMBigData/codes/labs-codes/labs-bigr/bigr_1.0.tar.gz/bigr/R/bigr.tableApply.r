#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# tableApply
#
# This function will apply a function on the whole bigr.frame as one table

# tableApply function
#
# @param data bigr.frame object
# @param rfunction the text of the function to apply on the bigr.frame
# @param signature to indicate whether the result is a bigr.list or a bigr.frame
# @return either a bigr.list or bigr.frame
tableApply <- function(data, rfunction, signature, ...)
{
    # save the current time
    b4 <- Sys.time()
    
    # require this library for encode/decode
    library("base64enc")
    
    # logging set up
    logSource <- "tableApply"
    bigr.info(logSource, "Start tableApply processing...")
    
    # checking arguments
    .bigr.checkParameter(logSource, data, "bigr.frame")
    .bigr.checkParameter(logSource, rfunction, "function")
    .bigr.checkParameter(logSource, signature, "data.frame", isOptional=T)
    
    if (missing(signature)) {
        signature <- NULL
    }
    
    # pack the connection credential and the bigr library version/built info to send to R server
    vb <- packageDescription("bigr", fields=c("Version", "Date"))
    scon <- c(bigr.env$CONNECTION@host, bigr.env$CONNECTION@port, bigr.env$CONNECTION@database, 
              bigr.env$CONNECTION@user, bigr.env$CONNECTION@password, vb[[1]], vb[[2]])
    scon <- base64encode(serialize(scon, connection=NULL, ascii=FALSE))
    
    # get the list of the arguments, the first element is the function name
    tempsys <- match.call()
    arglist <- as.list(tempsys)

    # get the function name
    streamfunc <- "arg_" %++% deparse(arglist[[1]])

    # get the function body
    rfunction <- deparse(eval(arglist$rfunction))
    rfunction <- base64encode(serialize(rfunction, connection=NULL, ascii=FALSE))

    # send the rfunction to Jaql
    jaqlExpression <- streamfunc %++% "='" %++% rfunction %++% "'"
    .bigr.execUpdate(jaqlExpression)

    # generate the argument list
    ignored <- append(1, which(names(arglist) %in% c("data", "rfunction", "signature")))

    # the argument list to pass to rfunction
    parmlist <- arglist[-ignored]
    parmlist <- sapply(parmlist, eval)
  
    # serialize the argument list
    bigr.parmlist <- base64encode(serialize(parmlist, connection=NULL, ascii=FALSE))
  
    # send the argument list to Jaql server
    arglistname <- streamfunc %++% "_arglist"
    arglistPair <- arglistname %++% "='" %++% bigr.parmlist %++% "'"
    .bigr.execUpdate(arglistPair)
  
    # generate the unique temporary directory name for this function
    jaqlExpression <- "logdir := bigrGetFilename('/tmp/bigr', 'tableApply', 'd'); logdir"
    logdir <- .bigr.execQuery(jaqlExpression)
    if (is.null(logdir)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # create the logdir TODO: check the error and handle it
    jaqlExpression <- "hdfsShell('-mkdir " %++% logdir %++% "')"
    jaqlret <- .bigr.execQuery(jaqlExpression)
    if (0 > jaqlret) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # the current log filename
    logfile <- logdir %++% "/R.log"
    bigr.env$LOGDIR <- logdir
    bigr.env$LOGFILE <- logfile
    
    # get the colname
    columnNames <- base64encode(serialize(colnames(data), connection=NULL, ascii=FALSE))
    
    # construct the tableApply_rFunc
    if (!is.null(signature) && ("data.frame" == class(signature))) {
        sigcheck <- paste(deparse(signature), collapse='')
        tableApply_rFunc <- "tableApply_rFunc=" %++% "bigrGetRFunc_groupRowApply_dataframe('" %++% streamfunc %++% "', '" %++% rfunction %++% "', '" %++% columnNames %++% "', '" %++% arglistname %++% "', '" %++% bigr.parmlist %++% "', '" %++% scon %++% "', '" %++% logdir %++% "', '" %++% sigcheck %++% "')"
    }
    else {
        tableApply_rFunc <- "tableApply_rFunc=" %++% "bigrGetRFunc_groupRowApply('" %++% streamfunc %++% "', '" %++% rfunction %++% "', '" %++% columnNames %++% "', '" %++% arglistname %++% "', '" %++% bigr.parmlist %++% "', '" %++% scon %++% "', '" %++% logdir %++% "')"
    }
    .bigr.execUpdate(tableApply_rFunc)
    
    # generate the coltype and colname for the log file
    bigr.env$LOGCOLTYPE <- c("character", "character")
    bigr.env$LOGCOLNAME <- c("status", "logfile")
    
    # generate the temporary unique output filename
    jaqlExpression <- "csvout := bigrGetFilename(logdir, 'tableApply', 'csv'); csvout"
    csvout <- .bigr.execQuery(jaqlExpression)
    if (is.null(csvout)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }

    # warning that the factors in data.frame will be treated as characters
    if (!is.null(signature) && ("data.frame" == class(signature))) {
        if ("factor" %in% coltypes(signature))
            bigr.warn(logSource, "Factor(s) in signature are implicitly treated as character(s).")
    }
    
    # run the query on Jaql server
    logSchema <- "schema {status : string, logfile : string}"
    if (!is.null(signature) && ("data.frame" == class(signature))) {
        # user wants to return a bigr.frame
        sigclasses <- sapply(signature, class)
        jaqlType <- sapply(sigclasses, .bigr.getJaqlType)
        jaqlType <- paste("data",seq_along(jaqlType),":",jaqlType,"?",sep="",collapse=", ")
        outSchema <- paste("schema {", jaqlType, "}", sep="")
    }
    else {
        # user wants to return a bigr.list
        outSchema <- "schema {data : string}"
    }
    
    # generate the input and result schemas for the R external function
    inputSchema <- .bigr.frame.jaqlInputSchema(data)
    resultSchema <- "schema [{status : string, " %++% substring(outSchema, 9, nchar(outSchema) - 1) %++% ", logfile : string}*]"

    # retrieve timeout option
    timeout <- getOption("bigr.r.timeout")
    if (is.null(timeout)) {
        timeout <- 180000
    }
    else {
        timeout <- as.numeric(timeout)
        if (is.na(timeout)) {
            timeout <- 180000
        }
    }
    
    # ask Jaql to generate the function to run rfunction
    jaqlExpression <- "insc = " %++% inputSchema %++% "; outsc = " %++% resultSchema %++% "; tableApply = externalRFn(rFunction=tableApply_rFunc, parameters=insc, result=outsc, timeout=" %++% timeout %++% ")"
    .bigr.execUpdate(jaqlExpression)
    
    # ask Jaql to generate the tableApply function
    if (is.null(signature) || ("data.frame" != class(signature))) {
        # add a dummy group column
        outSchema <- "schema {group : string, data : string}"
        jaqlExpression <- "bigrGetTableApplyFn(tableApply, csvout, " %++% outSchema %++% ", '" %++% logfile %++% "', '" %++% logSchema %++% "')"
    }
    else {
        # going to return a bigr.frame
        jaqlExpression <- "bigrGetTableApplyFn_dataframe(tableApply, csvout, " %++% outSchema %++% ", '" %++% logfile %++% "', '" %++% logSchema %++% "')"

    }
    tableApplyFn <- .bigr.execQuery(jaqlExpression)
    
    # run the tableApply on server
    jaqlExpression <- "res = " %++% .bigr.getJaqlExpression(data) %++% "->" %++% as.character(tableApplyFn)
    jaqlret <- .bigr.execQuery(jaqlExpression)
    if (is.null(jaqlret)) {
        bigr.err(logSource, "Failed to execute query on BigInsights server, check whether the connection exists...")
    }
    
    # Create a environment that holds metadata for any temporary files, and 
    # register a finalizer for it. These files will be removed when the environment
    # cannot be accessed.                            
    e <- new.env(parent = emptyenv())
    e$finals <- logdir
    reg.finalizer(e, .bigr.remove.files)
    envs <- list(e)
    
    if (is.null(signature) || ("data.frame" != class(signature))) {
        # read the .csv and generate the bigr.list
        result <- new (bigr.env$LIST_CLASS_NAME, dataSource=bigr.env$TEXT_FILE, dataPath=as.character(csvout), 
                       groupColumns=1, envs=envs)
    }
    else {
        # return bigr.frame        
        result <- new (bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TEXT_FILE, dataPath=as.character(csvout), delimiter=",", colnames=names(signature), 
                       coltypes=sapply(signature, function(x) {if(class(x)=="factor") "character" else class(x)}), header=FALSE, 
                       localProcessing = data@localProcessing, envs=envs)
    }
    
    if (!is.null(result)) {
        result@logInfo <- list(bigr.env$LOGFILE, bigr.env$LOGCOLNAME, bigr.env$LOGCOLTYPE)
    }
    
    # log time and print
    dt <- difftime(Sys.time(), b4); 
    cat("tableApply ran for " %++% round(dt,2) %++% units(dt) %++% "\n");
    
    # return message so that users know what to check
    capture.output({logs <- bigr.logs(result)})
    wlen <- length(grep('Warning', logs[[1]]))
    elen <- length(grep('Error', logs[[1]]))
    if ((wlen > 0) || (elen > 0)) {
        warning(wlen %++% " warnings and " %++% elen %++% " errors encountered. Use bigr.logs() to examine R execution logs.", call.=FALSE)
    }
    
    return(result)
}
