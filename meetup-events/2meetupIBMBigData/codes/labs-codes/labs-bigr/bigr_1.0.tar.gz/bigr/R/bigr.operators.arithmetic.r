#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' Big R supports standard operations (+, -, *, /) on two bigr.vectors, or on
#' a bigr.vector and a single numeric value. The bigr.vector(s) must have an
#' underlying data type of "numeric" or "integer".
#' @name Arithmetic operators
#' @title +, -, *, /
#' @aliases + - * /
#' @param x a bigr.vector
#' @param y a bigr.vector or a numeric value
#' @return a bigr.vector that holds result of the arithmetic operation
#' @usage x \+ y
#' @examples \dontrun{
#' 
#' # Compute difference between actual and scheduled time
#' diff <- air$CRSElapsedTime - air$ActualElapsedTime
#' 
#' # Compute average speed in miles per hour
#' speed <- air$Distance / (air$ActualElapsedTime / 60)}
#' @rdname arith

setGeneric("+")
setMethod("+", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        if (missing(e2)) {
            e2 <- 0
        }
        .bigr.binaryArithmeticOperation("+", e1, e2)
    }
)

setGeneric("+")
setMethod("+", signature(e1 = "numeric", e2 = bigr.env$VECTOR_CLASS_NAME),
          function(e1, e2) {
              e2 + e1              
          }
)

setGeneric("-")
setMethod("-", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        # e1 can never be missing since it's the one which allows
        # this method to be dispatched. If missing(e2), it means
        # -bigr.vector.
        if (missing(e2)) {
            .bigr.binaryArithmeticOperation("*", e1, -1)
        } else {
            .bigr.binaryArithmeticOperation("-", e1, e2)
        }
    }
)

setGeneric("-")
setMethod("-", signature(e1 = "numeric", e2 = bigr.env$VECTOR_CLASS_NAME),
          function(e1, e2) {
              -(e2 - e1)
          }
)

setGeneric("*")
setMethod("*", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryArithmeticOperation("*", e1, e2)
    }
)

setGeneric("*")
setMethod("*", signature(e1 = "numeric", e2 = bigr.env$VECTOR_CLASS_NAME),
          function(e1, e2) {
              e2 * e1
          }
)


setGeneric("/")
setMethod("/", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        # In JaQL, dividing longs yields another long. To return a double,
        # one of the operands must be a double. If any of the passed in
        # bigr.vectors is a number, turn it into a double.
        if (e1@dataType == "integer") {
            e1 <- as.numeric(e1)
        } else if (class(e2) == "bigr.vector") {
            if (e2@dataType == "integer")
                e2 <- as.numeric(e2)
        }
        .bigr.binaryArithmeticOperation("/", e1, e2)
    }
)

setGeneric("/")
setMethod("/", signature(e1 = "numeric", e2 = bigr.env$VECTOR_CLASS_NAME),
          function(e1, e2) {
              # In JaQL, dividing longs yields another long. To return a
              # double, one of the operands must be a double, hence
              # the use of "as.numeric" below
              if (e2@dataType == "integer") {
                  e2 <- as.numeric(e2)
              }
              .bigr.binaryArithmeticOperation("/", e1, e2)
          }
)

setGeneric("^")
setMethod("^", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryArithmeticOperation("pow", e1, e2, infix=F)
    }
)

setGeneric("^")
setMethod("^", signature(e1 = "numeric", e2 = bigr.env$VECTOR_CLASS_NAME),
          function(e1, e2) {
              .bigr.binaryArithmeticOperation("pow", e1, e2, infix=F)
          }
)

setGeneric("%%")
setMethod("%%", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        .bigr.binaryArithmeticOperation("mod", e1, e2, infix=F)
    }
)

setGeneric("%%")
setMethod("%%", signature(e1 = "numeric", e2 = bigr.env$VECTOR_CLASS_NAME),
          function(e1, e2) {
              .bigr.binaryArithmeticOperation("mod", e1, e2, infix=F)
          }
)

setGeneric("%/%")
setMethod("%/%", bigr.env$VECTOR_CLASS_NAME,
    function(e1, e2) {
        as.integer(.bigr.binaryArithmeticOperation("/", e1, e2))
    }
)

setGeneric("%/%")
setMethod("%%", signature(e1 = "numeric", e2 = bigr.env$VECTOR_CLASS_NAME),
      function(e1, e2) {
          as.integer(.bigr.binaryArithmeticOperation("/", e1, e2))
      }
)

#' \code{binaryArithmeticOperation} is a generic function that performs any binary
#' arithmetic operation between two bigr.vector's or a bigr.vector and a numeric value.
#' It is internally invoked by the +, -, *, and / operators. If both operators are bigr.vector's,
#' they are required to be from the same data origin or the same bigr.frame.
#' @param e1 a bigr.vector or a numeric value
#' @param e2 a bigr.vector or a numeric value
#' @param infix operator is considered as infix (T), or prefix (F)
#' @return a bigr.vector with the result of the arithmetic operation
#' @rdname internal.bigr.binaryArithmeticOperation
#' @keywords internal
.bigr.binaryArithmeticOperation <- function(operator, e1, e2, infix = T) {
    logSource <- "binaryArithmeticOperation"
    tableExpression <- NULL
    # Check that the operands are valid
    if (.bigr.isNullOrEmpty(e1) | .bigr.isNullOrEmpty(e2)) {
        bigr.err(logSource, "Cannot perform arithmetic operations on NULL, NA, or empty operands")
    }
    
    # Check that the operator is valid
    if (.bigr.isNullOrEmpty(operator)) {
        bigr.err(logSource, "Cannot perform arithmetic operations on NULL, NA, or empty operators")
    }    
    
    # Check that the operator is supported
    if (!(operator %in% c("+", "-", "*", "/", "pow", "mod"))) {
        bigr.err(logSource, "Binary arithmetic operator '" %++% operator %++% "' is not supported")
    }
    
    # Check that bigr.vectors are arithmetically operable
    if (class(e1) == bigr.env$VECTOR_CLASS_NAME) {
        if (e1@dataType != "numeric" & e1@dataType != "integer") {
            bigr.err(logSource, "Cannot perform an arithmetic operation on a '" %++% 
                         e1@dataType %++% "' bigr.vector")
        }
        tableExpression <- e1@tableExpression
    } else { # Check that constants are valid
        if (!.bigr.is.numeric.scalar(e1)) {
            bigr.err(logSource, "Invalid operand for arithmetic operation: '" %++% 
                         class(e1) %++% "'")
        }
    }
    if (class(e2) == bigr.env$VECTOR_CLASS_NAME) {
        if (e2@dataType != "numeric" & e2@dataType != "integer") {
            bigr.err(logSource, "Cannot perform an arithmetic operation on a '" %++% 
                         e2@dataType %++% "' bigr.vector")
        }
        tableExpression <- e2@tableExpression
    } else { # Check that constants are valid
        if (!.bigr.is.numeric.scalar(e2)) {
            bigr.err(logSource, "Invalid operand for arithmetic operation: '" %++% 
                         class(e2) %++% "'")
        }
    }
    
    # If both operators are bigr.vectors, then they must come from the same
    # origin, i.e., same table expression    
    if ((class(e1) == bigr.env$VECTOR_CLASS_NAME) && (class(e2) == bigr.env$VECTOR_CLASS_NAME)) {
        if (e1@tableExpression != tableExpression) {
            bigr.err(logSource, "Cannot perform an arithmetic operation on two big vectors " %++% 
                         "from different data origins")
        }
    }
    
    # Get operands in the JaQL representation
    x <- .bigr.getOperand(e1)
    y <- .bigr.getOperand(e2)
    
    envs <- list()
    if (inherits(e1, bigr.env$DATASET_CLASS_NAME))
        envs <- c(envs, e1@envs)
    if (inherits(e2, bigr.env$DATASET_CLASS_NAME))
        envs <- c(envs, e2@envs)
    
    # Create the resulting bigr.vector
    result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", 
                  name=bigr.env$DEFAULT_COLNAMES, dataType="numeric", envs=envs)
    result@tableExpression <- tableExpression
    if (infix) {
        result@columnExpression <- "(" %++% x %++% " " %++% operator %++% " " %++% y %++% ")"
    }
    else {
        result@columnExpression <- operator %++% "(" %++% x %++% ", " %++% y %++% ")"
    }
    return(result)
}

#' \code{unaryArithmeticOperation} is a generic function that performs any unary
#' arithmetic operation on a bigr.vector.
#'
#' @param x a bigr.vector
#' @return a bigr.vector with the result of the arithmetic operation
#' @rdname internal.bigr.unaryArithmeticOperation
#' @keywords internal
.bigr.unaryArithmeticOperation <- function(operator, x) {
    logSource <- "unaryArithmeticOperation"
    
    # Check that the operands are valid
    if (.bigr.isNullOrEmpty(x)) {
        bigr.err(logSource, "Cannot perform arithmetic operations on NULL, NA, or empty operands")
    }
    
    # Check that the operator is valid
    if (.bigr.isNullOrEmpty(operator)) {
        bigr.err(logSource, "Cannot perform arithmetic operations on NULL, NA, or empty operators")
    }
    
    # Check that the operator is supported
    #if (!(operator %in% c("abs"))) {
    #    bigr.err(logSource, "Unary arithmetic operator '" %++% operator %++% "' is not supported")
    #}
    
    # Check that bigr.vector is arithmetically operable
    if (x@dataType != "numeric" & x@dataType != "integer") {
        bigr.err(logSource, "Cannot perform an arithmetic operation on a '" %++% x@dataType %++% "' bigr.vector")
    }
    
    # Get operand in the JaQL representation
    operand <- .bigr.getOperand(x)
    
    # Create the resulting bigr.vector
    result <- new(bigr.env$VECTOR_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath="", 
                  name=bigr.env$DEFAULT_COLNAMES, "numeric", envs=x@envs)
    result@tableExpression <- x@tableExpression
    result@columnExpression <- operator %++% "(" %++% operand %++% ")"
    return(result)
}

#' \code{getOperand} converts a bigr.vector or numeric value into its 
#' JaQL representation.
#' @param x a bigr.vector
#' @return the JaQL representation of x
#' @rdname internal.bigr.getOperand
#' @keywords internal
.bigr.getOperand <- function(x) {
    if (class(x) == bigr.env$VECTOR_CLASS_NAME) {
        return(x@columnExpression)
    } else if (is.na(x)) {
        return("'NA'")
    } else if (class(x) == "character") {
        return("'" %++% toString(x) %++% "'")
    } else if (class(x) == "logical") { 
        return(tolower(toString(x)))
    } else if (class(x) == "numeric" | class(x) == "integer") {
        return(toString(x))
    } else {
        return(NULL)
    }
}

#'
#' Math - Define family of generic functions
setMethod("Math", 
  signature(x = "bigr.vector"),
  function (x) {
      op <- .Generic
      logSource <- op
      
      # Some operators are not supported because of lack of support in JaQL
      # These have been commented out.
      legalops <- c("abs", "sign", "sqrt", "ceiling", "floor", "trunc", 
                    "log", "log10", "log1p", # "log2", 
                    "exp", "expm1", 
                    "acos", # "acosh", 
                    "asin", # "asinh", 
                    "atan", # "atanh", 
                    "cos",  # "cosh", 
                    "sin",  # "sinh", 
                    "tan"   # "tanh",
                            # "cummax", "cummin", "cumprod", "cumsum"
                            # "gamma", "lgamma", "digamma", "trigamma"
                    )
      
      # Validate if we support the requested operator
      if (! (op %in% legalops)) {
          bigr.err(logSource, sprintf("Operation %s currently not supported", op))
      }

      return (.bigr.unaryArithmeticOperation(op, x))
  })

