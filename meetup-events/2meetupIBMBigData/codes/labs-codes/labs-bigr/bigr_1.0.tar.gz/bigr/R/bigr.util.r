#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' Print a small subset of the contents of the object. For objects of class
#' bigr.vector and bigr.frame, the number of rows printed can be controlled by
#' calling bigr.setRowLimit().
#' @name show
#' @title Show an object
#' @param object Any Big R object
#' @return an invisible NULL.
#' @examples \dontrun{
#' > bf <- bigr.frame(dataPath = "syscat.tables", dataSource = "BIGSQL")
#' > show(bf)}
#' @rdname show_all
NULL


#' Compactly displays the basic structure of any Big R object. This includes
#' column names, column types and a small sample of the data.
#' @param object Any Big R object
#' @return an invisible NULL.
#' @rdname str_all
#' @examples \dontrun{
#' > bf <- bigr.frame(dataPath = "syscat.tables", dataSource = "BIGSQL")
#' > str(bf)}
#' NULL

# bigr.util
#
# This file contains utility functions that can be used all
# accross the project

# A method to easily concatenate two strings
#' @keywords internal
"%++%" <- function(x, y) {
    paste(x, y, sep = "")
}

# An environment to store BigR variables
cat("Attaching...")
bigr.env <- new.env()

with(bigr.env, {
# This package's name
    PACKAGE_NAME <- "bigr";
    
# LOG LEVEL constants
    BIGR_HOME <- Sys.getenv("BIGR_HOME");
    INFO_LOG_LEVEL <- 4;
    WARN_LOG_LEVEL <- 2;
    ERR_LOG_LEVEL <- 1;
    NO_LOG_LEVEL <- 0;
    DEFAULT_LOG_LEVEL <- ERR_LOG_LEVEL + WARN_LOG_LEVEL;
    LOG_LEVEL <- DEFAULT_LOG_LEVEL;
    
# bigr.connection constants
    
    # Bigr path
    BIGR_HOME <- Sys.getenv("BIGR_HOME");
    
    # JaQL module paths
    JAQL_MODULES <- c("BigR.jaql",
                      "DataManipulation.jaql",
                      "Analytics.jaql",
                      "Apply.jaql",
                      "Sampling.jaql");
    
    # Default database to be used if none is specified
    DEFAULT_DATABASE <- "default";
    
    # The bigr.connection class name
    CONNECTION_CLASS_NAME <- "bigr.connection";
    
    # The maximum number of rows to be returned by a JaQL query
    DEFAULT_ROW_LIMIT <- 50;
    
# bigr.dataset constants
    DATASET_CLASS_NAME <- "bigr.dataset";
    
    # Possible data sources
    TEXT_FILE <- "DEL";
    DEL <- "DEL";
    LINE_FILE <- "LINE"
    BIG_SQL <- "BIGSQL";
    TRANSFORM <- "TRANSF"; # When a bigr.dataset is the result of a transformation (e.g., projection or filtering)
    
    EMPTY_TABLE_EXPRESSION <- "[[]]";
    
    # A list of supported data formats
    DATA_SOURCES <- c(TEXT_FILE, BIG_SQL, TRANSFORM, LINE_FILE);
    
    # Supported data types
    DATA_TYPES <- c(character="string", 
                    character="varchar",
                    character="timestamp",
                    character="array",
                    numeric="double",
                    numeric="float", 
                    numeric="real",
                    numeric="numeric",
                    numeric="decimal",
                    numeric="bigint",
                    integer="long", 
                    integer="tinyint", 
                    integer="smallint", 
                    integer="int", 
                    logical="boolean", 
                    factor="string")
    
    SUPPORTED_DATA_TYPES <- c("character", "numeric", "integer", "logical");
    
    # The number of rows returned by head and tail methods
    DEFAULT_HEAD_ROWS <- 6;
    
    # The default delimiter for text files
    DEFAULT_DELIMITER <- ",";
    
    # NA string
    DEFAULT_NA_STRING <- "";
    
    # Local processing
    DEFAULT_LOCAL_PROCESSING <- FALSE;
    
    # If no rows are returned by a query
    EMPTY_DATA <- data.frame();

    # A global bigr.connection object
    CONNECTION <- NULL;
    
    COUNT_CACHE <- list()
        
# bigr.vector constants
    
    # The bigr.vector class name
    VECTOR_CLASS_NAME <- "bigr.vector";

# bigr.frame constants

    # The bigr.frame class name
    FRAME_CLASS_NAME <- "bigr.frame";
    
    # The default column names if none specified
    DEFAULT_COLNAMES <- c("V1");
    
    UNKNOWN_COLNAMES <- c("<UNKNOWN>");
    
    # The default column types if none specified
    DEFAULT_COLTYPES <- c("character");
    
    DEFAULT_NBINS = 10;
    
    # Aggregate functions for numeric columns
    ALL_AGGREGATE_FUNCTIONS = c("count", "countNA", "countnonNA", "min", "max", "sum", "avg", "mean", "sd", "var");
    
    RESERVED_WORDS = c(ALL_AGGREGATE_FUNCTIONS);
    
    ALL_NOMINAL_AGGREGATE_FUNCTIONS = c("count", "countNA", "countnonNA", "min", "max");    

    # Default aggregate functions for numeric columns
    DEFAULT_NUMERIC_AGGREGATE_FUNCTIONS = c("countnonNA", "min", "max", "sum", "mean");
    
    # Aggregate functions for nominal columns
    DEFAULT_NOMINAL_AGGREGATE_FUNCTIONS = c("countnonNA", "min", "max");
    
    # The list of aggregate functions which always return a numeric value
    NUMERIC_TYPE_AGGREGATE_FUNCTIONS = c("count", "sum", "mean", "countNA", "countnonNA");
    
    ALL_COLUMNS = ".";
    
# bigr.function constants
    
    FUNCTION_CLASS_NAME <- "bigr.function";
    
    REGISTERED_FUNCTIONS <- list();
 
    
# bigr.sampling constants
    RANDOM_SEED <- 71

    # The bigr.list class name
    LIST_CLASS_NAME <- "bigr.list";
    
    # warnings and errors log file
    LOGDIR <- "";
    LOGFILE <- "";
    LOGCOLTYPE <- c();
    LOGCOLNAME <- c();
    
    # JDBC class name
    JDBC_CLASS_NAME <- "bigr.jdbc";

    # Random numbers / RNG support
    DEFAULT_RNG <- "bigr.default.rng"
}) # End with


# Checks whether a given object is NULL or empty.
#
# This function returns true if the given object is NULL, NA, "". Also, if
# it is an array which only contains NULL, NA or "" values.
# @param x an object or variable to be evaluated
# @return a logical value indicating whether the given object is NULL, NA or empty
# @rdname internal.bigr.isNullOrEmpty
# @keywords internal
.bigr.isNullOrEmpty <- function(x) {
    logSource <- ".bigr.isNullOrEmpty"
    if (missing(x)) {
        bigr.err(logSource, 
                 sprintf("A value for parameter '%s' must be specified.", deparse(substitute(x))))
    }
    if (class(x) == bigr.env$FRAME_CLASS_NAME | class(x) == bigr.env$VECTOR_CLASS_NAME
        | class(x) == bigr.env$DATASET_CLASS_NAME) {
        return(FALSE)
    }    
    if (is.null(x)) {
        return(TRUE)  
    } else if (length(x) < 1) {
        return(TRUE)
    }
    if (class(x) == "character" | class(x) == "numeric" | class(x) == "logical" | class(x) == "integer") {
        if (all(is.na(x) | is.null(x) | x == "") ) {
            return(TRUE)
        }
    }
    return(FALSE)
}

.bigr.hasNullOrEmpty <- function(x) {
    logSource <- ".bigr.isNullOrEmpty"
    if (.bigr.isNullOrEmpty(x)) {
        return(TRUE)
    }
    for (i in 1:length(x)) {
        if (.bigr.isNullOrEmpty(x[i])) {
            return(TRUE)
        }
    }    
    return(FALSE)
}

#' This method checks whether a bigr.frame and a bigr.vector are compatible.
#' Four cases were identified:
#' 
#' Case 1: bigr.sort(bf[,-11], bf$UniqueCarrier)                     NOT COMPATIBLE
#' Case 2: bigr.sort(bf, list(bf$UniqueCarrier))            COMPATIBLE
#' Case 3: bigr.sort(bf, list(toLower(bf$UniqueCarrier)))   COMPATIBLE
#' Case 4: bigr.sort(airline, homes$zipcode)                     NOT COMPATIBLE
.bigr.is.compatible <- function(bf, bv) {    
    if (class(bf) != bigr.env$FRAME_CLASS_NAME) {
        return(FALSE)
    }
    if (class(bv) != bigr.env$VECTOR_CLASS_NAME) {
        return(FALSE)
    }
    return(bv@tableExpression == .bigr.getJaqlExpression(bf))
}

# Checks if two vectors are equals
.bigr.equals <- function(a, b) {
    logSource <- ".bigr.equals"
    if (!is.vector(a) | !is.vector(b)) {
        bigr.err(logSource, "Cannot apply equals function to non-vector operands")
    }
    if (is.null(a) | is.null(b)) {
        return(FALSE)
    }
    if (length(a) != length(b)) {
        return(FALSE)
    }
    if (all(a == b)) {
        return(TRUE)
    } else {
        return(FALSE)
    }
}

# Indicates whether a string pattern is contained into a given string x
.bigr.contains <- function(x, pattern) {
    logSource <- "contains"
    if (!.bigr.isNullOrEmpty(x) & !.bigr.isNullOrEmpty(pattern)) {
        if (class(x) != "character" | class(pattern) != "character") {
            bigr.err(logSource, "Contains cannot be applied to " %++% class(x) %++% ", " %++% class(pattern))
        }
        return(regexec(pattern, x, fixed=TRUE)[[1]][1] != -1)    
    } else {
        return(FALSE)
    }
}

# Maps a JaQL data type to the corresponding R type
.bigr.getJaqlType <- function(rType) {
    if (.bigr.isNullOrEmpty(rType) | class(rType) != "character") {
        return(NULL)
    }
    if (rType %in% names(bigr.env$DATA_TYPES)) {
        return(bigr.env$DATA_TYPES[[rType]])
    } else {
        return(NULL)
    }
}

# Maps an R data type to the corresponding JaQL type
.bigr.getRType <- function(jaqlType) {
    if (is.null(jaqlType) | class(jaqlType) != "character") {
        return(NULL)
    }
    if (jaqlType %in% bigr.env$DATA_TYPES) {    
        pos = match(jaqlType, bigr.env$DATA_TYPES)
        return(names(bigr.env$DATA_TYPES)[pos])
    } else {
        return(NULL)
    }
}

#' Given a vector of \code{character}, appends the corresponding number of spaces at the
#' end of each element, in order to make them all have the same length.
#'
#' @param x an array of strings to be aligned
#' @return an array of aligned strings
#' @rdname internal.bigr.align.strings
#' @keywords internal
.bigr.align.strings <- function(x) {    
    maxLength <- -1
    for (i in 1:length(x)) {
        newLength <- nchar(x[i]) 
        if (newLength > maxLength) {
            maxLength <- newLength
        }
    }    
    for (i in 1:length(x)) {
        spaces <- paste(rep(" ", maxLength - nchar(x[i])), sep="", collapse="")
        x[i] <- x[i] %++% spaces
    }
    return(x)    
}


#' Checks whether a given value is an integer number
#'
#' @param x the number to be checked
#' @return \code{TRUE} if \code{x} is an integer. \code{FALSE} otherwise.
#' @rdname internal.bigr.is.integer
#' @keywords internal
.bigr.is.integer <- function(x) {
    if (.bigr.isNullOrEmpty(x)) {
        return(FALSE)
    }
    if (length(x) != 1) {
        return(FALSE)
    }
    if (!is.numeric(x)) {
        return(FALSE)
    }
    if (x != trunc(x)) {
        return(FALSE)
    }
    return(TRUE)
}
#' Changes the maximum number of rows/elements to be displayed by BigR.
#'
#' @param rowLimit the maximum number of rows/elements to be displayed
bigr.setRowLimit <- function(rowLimit) {
    logSource <- "bigr.setRowLimit"
    if (!.bigr.is.integer(rowLimit)) {
        bigr.err(logSource, "Row limit must be a positive integer value.")
    }
    if (rowLimit < 0) {
        bigr.err(logSource, "Row limit must be a positive integer value.")
    }
    options(bigr.row.limit = rowLimit)
    invisible(TRUE)
}

bigr.getRowLimit <- function() {
    getOption("bigr.row.limit")
}

# TODO: Check for copyright issues
#' Returns the number of days from the beginning of the Julian calendar.
#'
#' @keywords internal
.bigr.JDN <- function(month, day, year) {
    a <- floor((14 - month) / 12)
    y <- (year + 4800) - a
    m <- month + 12 * a - 3
    JDN <- day + floor((153 * m + 2) / 5) + 365 * y + floor(y / 4) - 32083
    return(JDN)
}

#' Returns the system time in milliseconds since January 1, 2000.
#'
#' @keywords internal
.bigr.currentTimeMillis <- function() {
    sysDate = as.character(Sys.time())
    year = as.integer(substring(sysDate, 1, 4))
    month = as.integer(substring(sysDate, 6, 7))
    day = as.integer(substring(sysDate, 9, 10))
    sysTime = format(Sys.time(), "%H:%M:%OS3")
    hour = as.integer(substring(sysTime, 1, 2))
    min = as.integer(substring(sysTime, 4, 5))
    sec = as.integer(substring(sysTime, 7, 8))
    millis = as.integer(substring(sysTime, 10, 12))
    
    # Get the number of days from January 1, 2000
    JDN <- .bigr.JDN(month, day, year) - 2451545
    JDN * 24 * 3600 * 1000 + hour * 3600 * 1000 + min * 60 * 1000 + sec * 1000 + millis
}

# This function returns the element count of a bigr.dataset if
# it has been cached. Otherwise, it returns NULL.
.bigr.getCachedCount <- function(dataset) {
    bigr.env$COUNT_CACHE[[dataset@tableExpression]]
}

.bigr.getShortType <- function(type) {
    if (type == "character") {
        "chr"
    } else if (type == "numeric") {
        "num"
    } else if (type == "logical") {
        "logi"
    } else if (type == "integer") {
        "int"
    } 
}

##################################################################################
# The following methods are used for the remote execution / JaQL to R invocation #
##################################################################################

#' Return the Jaql input schema for the bigr.frame
#'
#' @param data the bigr.frame object
#' @return JSON schema for the bigr.frame
#' @keywords internal
.bigr.frame.jaqlInputSchema <- function(data) {
    jaqlTypes <- sapply(data@coltypes, .bigr.getJaqlType)
    sc <- "schema {data: [ [" %++% paste(jaqlTypes, collapse=", ") %++% "]* ]}"
}

#' retrieve the data type of the bigr.vector object
#'
#' @param x  the bigr.vector object
#' @return the data type for the bigr.vector object
#' @keywords internal
bigr.Vector.getDataType <- function(x) {
    return (x@dataType)
}

#' Search for the JDBC driver path under CLASSPATH or bigr root directory
#' 
#' @return the JDBC driver jar file path for BigSQL server
#' @return jdbc driver path
#' @keywords internal
.bigr.getJDBCDriverPath <- function() {
    logSource <- ".bigr.getJDBCDriverPath"
    
    driverPath <- ""
    # search CLASSPATH first
    if ("Windows" == Sys.info()["sysname"]) {
        classpath <- unlist(strsplit(Sys.getenv("CLASSPATH"), ";"))
    } else {
        classpath <- unlist(strsplit(Sys.getenv("CLASSPATH"), ":"))
    }
    idx <- as.numeric(grep("bigsql-jdbc-driver", classpath))
    if (length(idx) > 0) {
        driverPath <- classpath[idx[[1]]]
        if (length(idx) > 1) {
            warning("Two or more jdbc drivers are found, " %++% driverPath %++% "is used. If you want to use other drivers, please pass the driverPath through bigr.connect")
        }
        
    } else {
        # search package root
        bigrRoot <- system.file(package=bigr.env$PACKAGE_NAME)
        bigrRootFiles <- list.files(bigrRoot)
        idx <- as.numeric(grep("bigsql-jdbc-driver", bigrRootFiles))
        if (length(idx) > 0) {
            driverPath <- bigrRoot %++% "/" %++% bigrRootFiles[idx[[1]]]
            if (length(idx) > 1) {
                bigr.warn(logSource, "Two or more jdbc drivers are found, " %++% driverPath %++% "is used. If you want to use other drivers, please pass the driverPath through bigr.connect")
            }
        }
    }
    
    if ("" == driverPath) {
        bigr.err(logSource, "Cannot find BigSQL JDBC Driver...")
    }
    return (driverPath)
}

#' Returns a numbered list of log files or shows the log file content for the
#' specified log file produced through the *Apply function.
#' 
#' Each instance of an *Apply function (groupApply, rowApply and tableApply) 
#' that executes on a BigInsights cluster can write output to "stdout" or 
#' "stderr". Big R captures this output and preserves it in the form of log 
#' files. bigr.logs() can be used to show a numbered list of log files 
#' generated by an *Apply call. In addition, the same function can be used to
#' examine the detailed output in any specific log file. In the case of 
#' groupApply(), the log files are tagged with the grouping columns, and this
#' makes it easier to correlate groups with their corresponding log files. In
#' the case of tableApply(), only one log file is produced.
#' 
#' @title Display output generated by *Apply functions
#' @param ... (optional) A bigr.frame or bigr.list object whose log files are 
#'   to be displayed. If this parameter is not specified, log files of the 
#'   the most recently executed *Apply call are displayed.
#' @param ... (optional) A numeric vector identifying the number(s) of the
#'   log file(s) whose contents are  to be displayed. If not specified,
#'   merely a list of log files is returned
#' @seealso \link{groupApply}, \link{rowApply}, \link{tableApply}
bigr.logs <- function(...)  {
    logSource <- "bigr.logs"
    
    # Validate parameters
    args <- list(...)
    if (length(args) > 2) {
        bigr.err(logSource, "No more than two arguments must be specified.")
    }
    
    # Parse arguments
    x <- NULL
    nth <- NULL
    for (i in seq(length.out=length(args))) {
        if (class(args[[i]]) %in% c("bigr.list", "bigr.frame")) {
            if (! is.null(x))
                bigr.err(logSource, "Only one object of class bigr.list or bigr.frame must be provided.")
            x <- args[[i]]
        } else if (class(args[[i]]) %in% c("integer", "numeric")) {
            if (! is.null(nth))
                bigr.err(logSource, "Only one object of class integer or numeric must be provided.")
            nth <- as.integer(args[[i]])
        } else {
            bigr.err(logSource, sprintf("Parameter #%d has invalid class %s", 
                                        i, dQuote(class(args[[i]]))))
        }
    }
    
    # Return list of log files, OR, actual contents
    if (is.null(nth)) {
        # nth is missing, just return list of log files
        
        if (is.null(x))
            return(.bigr.getLogFiles())
        else
            return(.bigr.getLogFiles(x))
    } else {
        # nth is specified, return log file contents
        if (is.null(x))
            capture.output({files <- .bigr.getLogFiles()})
        else
            capture.output({files <- .bigr.getLogFiles(x)})
        
        if (is.null(files) || ("data.frame" != class(files))) {
            bigr.err(logSource, "Could not load log files." %++%
                         "Either they have been deleted or they are corrupt.")
        }
        else {
            if (! all(nth %in% 1:nrow(files))) {
                bigr.err(logSource, "Invalid log file number(s) specified. Log files are numbered from 1 to " %++% nrow(files) %++% ".")
            }

            for (i in nth) {
                cat("##################### Log file " %++% i %++% " #####################\n")
                .bigr.showLogFile(files[i, "logfile"])
                cat("\n")
            }
        }
    }
}

#' Returns the data.frame that contains the log filename for each group or batch
#' @param x optional or the bigr.frame or bigr.list object that has a log summary file
#' @return all log filenames and status when the bigr.frame or bigr.list are genearted through *apply functions
#' @keywords internal
.bigr.getLogFiles <- function(x) {
    logSource <- ".bigr.getLogFiles"
    logfile <- NULL
    if (missing(x)) {
        logdir <- bigr.env$LOGDIR
        logfile <- bigr.env$LOGFILE
        logcolnames <- bigr.env$LOGCOLNAME
        logcoltypes <- bigr.env$LOGCOLTYPE
    }
    else if ((bigr.env$LIST_CLASS_NAME == class(x)) || (bigr.env$FRAME_CLASS_NAME == class(x))) {
        if (0 == length(x@logInfo)) {
            bigr.err(logSource, "The object does not have any log files associated...")
        }
        logdir <- dirname(x@dataPath)
        logfile <- x@logInfo[[1]]
        logcolnames <- x@logInfo[[2]]
        logcoltypes <- x@logInfo[[3]]
    }
    
    if (is.null(logfile)) {
        bigr.err(logSource, "The object does not have any log files associated...")
    }
    else {
        p <- as.data.frame(new(bigr.env$FRAME_CLASS_NAME, bigr.env$TEXT_FILE, logfile, ",", logcolnames, logcoltypes, header=FALSE, envs=list()))
        n <- length(logcoltypes)
        p[,n] <- paste(logdir, "/", p[,n],sep="")
        for (i in c(2:n)) {
            if (all((p[,i] %in% c("true", "false", NA)) == TRUE)) {
                p[,i] <- toupper(p[,i])
            }
        }
        print(p[, -grep("^logfile$", names(p)), drop=FALSE])
        invisible(p)
    }
}

#' Returns all the log entries for a particular processing
#' @param x log filename
#' @return the logging entries in the log file
#' @keywords internal
.bigr.showLogFile <- function(x) {
    print(.bigr.execQuery("localRead(lines(location='" %++% x %++% "'))"), right=FALSE)
}

# .bigr.checkParameter
#
# Utility function used to raise errors when invalid parameter values are specified.
.bigr.checkParameter <- function(logSource, parm, expectedClasses, expectedValues, 
                                 isOptional = F, isNullOK = F, isSingleton=T) {

    # If the parm is missing, and it's optional, everything is OK
    if (missing(parm) & isOptional)
        return(T)

    # If param is not missing, do a quick check for NULLs
    if (! missing(parm)) {
        if (is.null(parm) & isNullOK)
            return(T)
    }
    
    # Format the parameter name
    parmName <- as.character(substitute(parm))

    # Format expected classes, if passed in.
    ecStr <- NULL
    evStr <- NULL
    if (! missing(expectedClasses)) {
        ecStr <- dQuote(expectedClasses)
        ecStr <- paste(ecStr, collapse=", ")
        if (length(expectedClasses) > 1)
            ecStr <- "(" %++% ecStr %++% ")"
        
    }

    # Format expected values, if passed in
    if (! missing(expectedValues)) {
        if (length(expectedValues) > 1) {
            if (is.character(expectedValues))
                evStr <- dQuote(expectedValues)
            else
                evStr <- expectedValues
            evStr <- paste(evStr, collapse=", ")
            evStr <- "(" %++% evStr %++% ")"
        }
        else {
            evStr <- ifelse(is.null(expectedValues), "NULL", 
                            ifelse(is.character(expectedValues), 
                                   dQuote(expectedValues), expectedValues))
        }
    }

    # Check if parameter is missing
    if (missing(parm)) {        
        if (! is.null(ecStr))
            error <- sprintf("Parameter %s is missing: Expected %s.", dQuote(parmName), ecStr)
        else
            error <- sprintf("Parameter %s is missing: Expected %s.", dQuote(parmName), evStr)
        bigr.err(logSource, error)
    }
    
    # Check parameter classes, if passed in.
    if (! missing(expectedClasses)) {
        if (! (class(parm) %in% expectedClasses)) {            
            error <- sprintf("Parameter %s has invalid class: Expected %s, specified %s", 
                             dQuote(parmName), ecStr, dQuote(class(parm)))
            bigr.err(logSource, error)            
        }
    }
    
    if (! missing(expectedValues)) {
        # Check for NULL equivalency right away
        if (is.null(parm)) {
            if (is.null(expectedValues))
                return (T)
        } else {
            if (all(parm %in% expectedValues))
                return (T)
        }
        if (class(parm) %in% c("logical", "integer", "numeric", "character")) {
            specified <- ifelse(is.null(parm), "NULL", 
                            ifelse(is.character(parm), dQuote(parm), parm))
        } else {
            specified <- "object of class " %++% dQuote(class(parm))
        }
        error <- sprintf("Parameter %s has invalid value: Expected %s, specified %s. ",
                         dQuote(parmName), evStr, specified)
        bigr.err(logSource, error)
    }
    
    # Check if parameter is an atomic value
    if (class(parm) %in% c("logical", "integer", "numeric", "character")) {
        if (length(parm) != 1 & isSingleton) {        
            error <- sprintf("Parameter %s must be a singleton value.", dQuote(parmName))
            bigr.err(logSource, error)
        }
    }

    return (F)
}

#'
#' .bigr.compare
#' 
#' Perform comparisons between two objects. The typical use case for this function
#' involves passing in one R object (say, a data.frame), and another BigR object (e.g.,
#' a bigr.frame). It internally converts the BigR object into its equivalent R form,
#' and invokes the compare() function to do the actual work. compare() comes to us from
#' the "compare" package on CRAN.
#' 
#' This is a utility function intended to be used during unit testing / FVT / etc. 
#' It is not a part of the core BigR functionality.
#' 
#' @param a                 first R or BigR object
#' @param b                 second R or BigR object
#' @param compareOutputs    if T, invoke "show" on both objects and compare the stdout
#' @param ...               arguhemts to be passed to compare()
#' @keywords internal

.bigr.compare <- function(a, b, compareOutputs = T, ...) {
    require(compare)
    
    capture <- function(expr) {
        paste(capture.output(expr), collapse="\n")
    }
    
    cls <- class(a)
    a2 <- a
    if (cls == "bigr.frame")
        a2 <- as.data.frame(a)
    else if (cls == "bigr.vector")
        a2 <- as.vector(a)
    
    cls <- class(b)
    b2 <- b
    if (cls == "bigr.frame")
        b2 <- as.data.frame(b)
    else if (cls == "bigr.vector")
        b2 <- as.vector(b)
    
    # First compare data structures
    cmpdata <- compare(a2, b2, ...)
    xcmpdata <- cmpdata$result
    
    # Grab outputs
    xcmpoutput <- T
    if (compareOutputs) {
        outa <- capture(show(a))
        outb <- capture(show(b))
        #cat("outa: ", outa, "\n")
        #cat("outb: ", outb, "\n")
        
        cmpoutput <- compare(outa, outb)
        xcmpoutput <- cmpoutput$result
    }
    
    if (xcmpdata == F | xcmpoutput == F) {
        warning(sprintf("Difference: %s vs. %s (Data: %s, Output: %s)", 
                        deparse(substitute(a)),
                        deparse(substitute(b)),
                        ifelse(xcmpdata, "similar", "different"),
                        ifelse(xcmpoutput, "similar", "different")),
                call.=F, immediate.=F)
        warning(paste("Data comparison flags: ", capture(print(cmpdata))), call.=F)
        if (compareOutputs) {
            warning(paste("Output comparison flags: ", capture(print(cmpoutput))), call.=F)
        }
        
        cat("---", deparse(substitute(a)), "\n")
        print(a)
        cat("---", deparse(substitute(b)), "\n")
        print(b)
    }
}

#' .bigr.remove.files
#' 
#' Delete files and directories from HDFS. Called by the finalizer.
#' 
#' @param e                 environment that holds names of files/directories
#' @keywords internal
.bigr.remove.files <- function(e) {
    logSource <- ".bigr.remove.files"
    # goes through the files in the list and tries to remove each of them from the BigInsights cluster
    # if the connection has dropped, the finalizer will not remove these files
    if (length(e$finals) > 0) {
        sapply(e$finals, function(x) {
            bigr.info(logSource, "Removing files " %++% x)
            if (is.bigr.connected()) {
                .bigr.execQuery("hdfsShell('-rmr " %++% x %++% "')")
            }
        })
    }    
}

#' Big R statements are translated into JaQL and Big SQL statements, which 
#' are then turned into MapReduce jobs. Execution of these jobs is influenced
#' by numerous Hadoop / MapReduce options. These options are usually 
#' specified in site-wide configuration files on the BigInsights cluster. 
#' They can also be specified on a per-job basis. This function provides an 
#' easy way to set these options from Big R itself, and these setting only 
#' apply to the current Big R session.
#' 
#' @name bigr.set.server.option
#' @title Set a Hadoop/MapReduce option
#' @rdname bigr.set.server.option
#' @param option the option string
#' @param value  the value
#' @examples \dontrun{
#' bigr.set.server.option("mapred.reduce.tasks", 10)}
#' @seealso \link{bigr.get.server.option}

bigr.set.server.option <- function(option, value) {
    logSource <- "bigr.set.server.option"
    
    .bigr.checkParameter(logSource, option, "character")
    .bigr.checkParameter(logSource, value, c("character", "integer", "numeric"))
    
    query <- sprintf('setOptions({conf:{"%s":"%s"}});', option, value)
    result <- .bigr.execQuery(query)
    if (result[1,1] != "true")
        bigr.err(logSource, sprintf("Could not set '%s' to value %s.", option, value))
}

#' List the values of one or more Hadoop/MapReduce options that apply to the 
#' current Big R session.
#' 
#' @name bigr.get.server.option
#' @title Get Hadoop/MapReduce options
#' @param option  (optional) If specified, returns the value of the specified
#'   option. This option may have previously been set by the user via 
#'   bigr.set.server.option(), and if so, that value is returned. If the 
#'   value of the option hasn't been set, then the value from the default
#'   Hadoop JobConf is returned. If "option" is not specified, return all
#'   options that were previously set via bigr.set.server.option().
#' @rdname bigr.get.server.option
#' @examples \dontrun{
#' bigr.get.server.option()
#' bigr.get.server.option("mapred.reduce.tasks")}
#' @seealso \link{bigr.set.server.option}
bigr.get.server.option <- function(option) {
    logSource <- "bigr.get.server.option"
    
    .bigr.checkParameter(logSource, option, "character", isOptional=T)
    
    # First, grab any options that've already been set
    sets <- .bigr.executeJaqlQuery("fields(getOptions().conf) -> transform [ $[0], $[1] ];",
                                   colnames=c("option", "value"),
                                   coltypes=c("character", "character"),
                                   limit=F)
    
    if (missing(option)) {
        # Return all options set in *this* session
        return(sets)
    }
    else {
        # Find for a specific option. If the option was set, return that.
        # Otherwise, return the default from the JobConf.
        if (nrow(sets) > 0) {
            idx <- which(sets[,1] == option)
            if (length(idx) > 0) {
                sets <- sets[idx,]
                rownames(sets) <- NULL
                return(sets)
            }
        }
        
        default <- .bigr.executeJaqlQuery(sprintf("[[ '%s', readConf('%s') ]];", 
                                                  option, option),
                                          colnames=c("option", "value"),
                                          coltypes=c("character", "character"),
                                          limit=F)
        return(default)
    }
}

bigr.generateFileName <- function() {
    jaqlExpression <- "file := bigrGetFilename('/tmp/bigr', 'sample_', 'd'); file"
    .bigr.execQuery(jaqlExpression)[1,1]    
}

#' During the execution of Big R functions, temporary files may be generated. 
#' Some of these files are created on HDFS, while others are created on the 
#' local file system of the data nodes. All temporary files on HDFS are placed 
#' under the /tmp/bigr/directory. Some of the functions that create these files 
#' are as.bigr.frame, groupApply, rowApply, tableApply, and bigr.sample. In many
#' cases, the temporary files have a prefix that identifies the function that 
#' created them. The lifetime of these temporary files is dependent on the 
#' lifetime of the R objects that refer to them. For e.g., as.bigr.frame() 
#' creates a temporary file on HDFS, and the resulting bigr.frame object 
#' references this file. If this R object is no longer accessible via the R 
#' environment, it is garbage collected and the underlying temporary file is 
#' deleted. However, this mechanism doesn't work if the connection to 
#' BigInsights is lost. In such a case, the temporary files are left behind on 
#' the cluster, and they need to be manually cleaned up. Should there be a need 
#' to manually clean up such files on HDFS, one only needs to examine the
#' /tmp/bigr directory.
#' 
#' @name Temporary Files
#' @title Temporary Files and garbage collection
#' @rdname tempfiles
NULL
