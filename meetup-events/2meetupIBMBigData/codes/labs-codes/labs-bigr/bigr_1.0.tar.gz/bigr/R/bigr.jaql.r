#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

.bigr.jaql.jaqlInvocation <- function(funName, params) {
    jaqlStatement <- funName%++% "(" %++% paste(params, collapse=", ") %++% ")"
}

.bigr.jaql.getGroupByJaqlSchema <- function(jaqlTypes, groupname, grouptype) {
    "schema { " %++% groupname %++% " : " %++% grouptype %++% ", data: [ [" %++% paste(jaqlTypes, collapse=", ") %++% "]* ]}"
}

.bigr.jaql.getSchema <- function(colnames, coltypes) {
    jaqlTypes <- sapply(coltypes, bigr:::.bigr.getJaqlType)
    "schema { " %++% paste(colnames, jaqlTypes, sep=": ", collapse=", ") %++% " } "
}


