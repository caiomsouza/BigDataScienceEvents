#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' Class bigr.connection
#'
#' This class provides methods to handle a JDBC connection to BigSQL and allows to execute
#' JaQL queries and updates.
#'
#'@section Slots:
#'  \describe{
#'    \item{\code{host}:}{\code{character} value specifying the host name for the JDBC connection}
#'    \item{\code{port}:}{\code{numeric} value specifying the port number for the JDBC connection}
#'    \item{\code{database}:}{\code{character} value specifying the database name for the JDBC connection}
#'    \item{\code{user}:}{\code{character} value specifying the user name for the JDBC connection}
#'    \item{\code{password}:}{\code{character} value specifying the password for the JDBC connection}
#'    \item{\code{driverPath}:}{\code{character} value specifying the JDBC driver .jar location}
#'    \item{\code{connected}:}{\code{logical} value specifying whether the connection is active or not}
#'    \item{\code{jdbcObj}:}{a JDBC driver as an instance of class \code{bigr.jdbc}}
#'  }
#' @name bigr.connection
#' @rdname bigr.connection
#' @exportClass bigr.connection
#' @keywords internal
setClass(bigr.env$CONNECTION_CLASS_NAME,
         representation(
             host = "character",
             port = "numeric",
             database = "character",
             user = "character",
             password = "character",
             driverPath = "character",
             connected = "logical",
             jdbcObj = bigr.env$JDBC_CLASS_NAME,
             connectionString = "character"
         ), prototype(
             host = "",
             port = 0,
             database = "default",
             user = "biadmin",
             password = "biadmin",
             driverPath = "",
             connected = FALSE,
             jdbcObj = NULL,
             connectionString = ""
         )        
)

#' bigr.connect attempts to establish a JDBC connection to BigInsights. For the
#' call to be successful, there needs to be a Big SQL server running at the
#' specified host. In addition, the user must have the proper credentials. As
#' Big R statements are executed, they are transparently converted into
#' corresponding SQL and JaQL statements, and these are executed within the
#' context of the established connection.
#' 
#' @title Connect to BigInsights
#' @param host (character) IP address of the Big SQL server
#' @param port (integer) port of the Big SQL server
#' @param database (character) not used, may be omitted
#' @param user (character) user name for the connection
#' @param password (character) password of the user
#' @param driverPath (character) Optional location of the Big SQL JDBC driver
#'   JAR file. This option is typically not specified, and Big R uses the
#'   default driver that is bundled with the package itself. This option is used
#'   to override the default driver. Alternatively, a driver may also be
#'   specified via the CLASSPATH environment variable.
#' @return TRUE if the connection was successful, FALSE otherwise.
#' @examples \dontrun{
#' bigr.connect(host="131.45.112.15", port=7052, 
#'              user="biadmin", password="xxx")}
bigr.connect <- function(host, port, database, user, password, driverPath) {
    logSource <- "bigr.connect"
    
    require(rJava)
            
    .bigr.checkParameter(logSource, host, "character")
    .bigr.checkParameter(logSource, port, c("integer","numeric"))
    .bigr.checkParameter(logSource, user, "character")
    .bigr.checkParameter(logSource, password, "character")
    .bigr.checkParameter(logSource, driverPath, "character", isOptional=T)
    
    # Check for missing/NULL parameters
    if (missing(database)) {
        database <- NULL
    }
    
    if (missing(driverPath)) {
        driverPath <- NULL
    }
    
    if (.bigr.isNullOrEmpty(database)) {
        database <- bigr.env$DEFAULT_DATABASE
    }
    
    # Search for BigSQL JDBC driver path if it is not specified
    if (.bigr.isNullOrEmpty(driverPath)) {
        driverPath <- .bigr.getJDBCDriverPath()
    } else if (! file.exists(driverPath)) {
        bigr.err(logSource, "Cannot open the JDBC driver: " %++% dQuote(driverPath))
    }

    bigr.info(logSource, "Parameters have been validated")
    
    # Create a connection object
    .Object <- new(bigr.env$CONNECTION_CLASS_NAME)
    .Object@host = host
    .Object@port = port
    .Object@user = user
    .Object@password = password
    .Object@driverPath = driverPath    
    .Object@connectionString = "jdbc:bigsql://" %++% host %++% ":" %++% port %++% "/" %++% 
        database %++% ":user=" %++% user %++% ";password=" %++% password
    
    # Connect to BigSQL
    bigr.info(logSource, "Loading JDBC driver...")
    
    tryCatch({
        # Put all JDBC connection related info into a list and invoke JDBC code to connect
        jdbcProp <- list(driverPath=.Object@driverPath, connectionString=.Object@connectionString)
        jdbcOj <- NULL
        jdbcObj <- .bigr.jdbc.connect(jdbcProp)

        if (!is.null(jdbcObj)) {
            .Object@connected <- !is.null(jdbcObj@jdbcConnection)
        }
        
        # If connection was successfull, set JaQL on.
        if (!.Object@connected) {
            bigr.err(logSource, "Could not establish a JDBC connection. " %++%
                         "Check connection parameters and ensure that Big SQL server is running.")
        } else {
            .Object@jdbcObj <- jdbcObj
            bigr.env$CONNECTION <- .Object
            if (!.bigr.setJaqlOn()) {
                bigr.err(logSource, "Could not intialize JaQL engine. " %++%
                             "Check the Big SQL server log file on the BigInsights cluster.")
            }
        }
        bigr.info(logSource, "Connected.")
    
        # Load JaQL Modules
        bigr.info(logSource, "Loading JAQL modules...")
        if (.bigr.loadJaqlModules()) {
            bigr.info(logSource, "JaQL modules were successfully loaded.")
        } else {
            bigr.warn(logSource, "Could not load JaQL modules." %++%
                          "Check the Big SQL server log file on the BigInsights cluster.")
        }
        
        # Register a default RNG, and set a seed. The seed itself is random.
        # However, a user is expected to specify their own seed using bigr.set.seed().
        bigr.set.seed(as.integer(runif(1, 1, 1e4)))
        
        # Set R option "bigr.r.timeout" to be 90% of Hadoop's 
        # "mapred.task.timeout", and with a lower limit of 1 minute. *Apply()
        # functions use the value of "bigr.r.timeout", and pass that to JaQL.
        timeout <- bigr.get.server.option("mapred.task.timeout")
        timeout <- timeout[1,2]
        if (is.na(timeout)) {
            timeout <- 180000  # 3 minutes
        } else {
            timeout <- max(as.integer(as.integer(timeout) * 0.9), 60000)
        }

        bigr.setRowLimit(bigr.env$DEFAULT_ROW_LIMIT)

        options(bigr.r.timeout = timeout)    
    }, error = function(e) {        
        errorMessage <- toString(e)
        bigr.info(logSource, errorMessage)
        
        # Decode error message to provide the user a more meaningful output
        if (.bigr.contains(errorMessage, "UnknownHostException")) {
            bigr.err(logSource, "Cannot connect to the specified host: '" %++% host %++% "'.")
        } else if (.bigr.contains(errorMessage, "Connection timed out")) {
            bigr.err(logSource, "Cannot establish a JDBC connection to Big SQL server. Connection timed out." %++% 
                         "Check that you have access to the specified host and Big SQL server is running.")
        } else if (.bigr.contains(errorMessage, "ConnectException") | 
                       .bigr.contains(errorMessage, "port out of range")) {
            bigr.err(logSource, "The connection was refused by the specified host. " %++% 
                         "Check that the port is correct and Big SQL server is running.")
        } else if (.bigr.contains(errorMessage, " java.sql.SQLException: Could not establish connection to")) {
            bigr.err(logSource, "Cannot connect to Big SQL. " %++% 
                         "Check that you have access to the specified host and Big SQL server is running")
        } else if (.bigr.contains(errorMessage, "BigRResultSet")) {
            bigr.err(logSource, "Required library 'BigRResultSet' could not be found.")
        } else {
            bigr.err(logSource, "Connection could not be established. " %++%
                         "Verify connection parameters. ")
        }
    })
    invisible(.Object@connected)
    if (.Object@connected) {
        # Clear the cached counts since the new connection could contain files with identical names
        # but different contents.
        # Also, this is a way to refresh the count in case the file is modified.
        bigr.env$COUNT_CACHE <- list()
    }
}

#' Displays the parameters and status of a \code{bigr.connection}.
#' @return NULL
#' @rdname show_connection
#' @keywords internal
setMethod(f = "show", signature = bigr.env$CONNECTION_CLASS_NAME, definition = 
    function(object) {
        cat("bigr.connection\n")
        cat("Status: ")
        if (object@connected == TRUE) {
            cat("<connected>")
        } else {
            cat("<offline>")
        }
        cat("\nConnection string: '" %++% object@connectionString %++% "'")
    }
)

#' Attempt to re-establish a JDBC connection to Big SQL using the same 
#' credentials that were specified in an earlier bigr.connect() call. If no 
#' prior call to bigr.connect() had been made, an exception is raised. If there 
#' exists an active connection, it is dropped and a new connection is attempted.
#' 
#' @title Reconnect to BigInsights
#' @return an invisible boolean indicating whether or not the connection was
#'   successful
#' @examples \dontrun{
#' > bigr.reconnect()}

bigr.reconnect <- function() {
    logSource <- "bigr.reconnect"
    
    # Check if a connection has been previously made
    if (.bigr.isNullOrEmpty(bigr.env$CONNECTION)) {
        bigr.err(logSource, "Cannot reconnect since no previous connection was previously established.")
    }
    
    # Terminate current connection
    bigr.disconnect()
    
    # Re-connect
    bigr.connect(bigr.env$CONNECTION@host, bigr.env$CONNECTION@port, bigr.env$CONNECTION@database, 
                 bigr.env$CONNECTION@user, bigr.env$CONNECTION@password, bigr.env$CONNECTION@driverPath)
    return(is.bigr.connected())
}

# Enables JaQL as the query language for BigSQL
.bigr.setJaqlOn <- function() {
    logSource <- ".bigr.setJaqlOn"
    if (is.bigr.connected()) {
        .bigr.jdbc.update("set jaql on")
        return(TRUE)
    } else {
        bigr.err(logSource, "Cannot initialize the JaQL engine since a connection is not active.")
        return(FALSE)
    }
}

# Checks that a JaQL expression is neither NULL nor empty
.bigr.validateJaql <- function(jaqlExpression) {
    if (.bigr.isNullOrEmpty(jaqlExpression)) {
        return(FALSE)
    }
    return(nchar(jaqlExpression) > 0)
}

#' Check whether an active connection still exists to Big SQL server 
#'
#' @title Check connection to BigInsights
#' @return a boolean indicating whether the connection is active or not.
is.bigr.connected <- function() {
    logSource <- "is.bigr.connected"
    if (.bigr.isNullOrEmpty(bigr.env$CONNECTION)) {
        bigr.info(logSource, "Connection is null")
        return(FALSE)
    } 
    
    if (!.bigr.jdbc.isValid()) {
        bigr.env$CONNECTION@connected = FALSE
    }
        
    return(bigr.env$CONNECTION@connected)
}

#' Executes a given JaQL query. If the query failed, an error is thrown.
#' Parameters colnames, coltypes, and limit are optional.
#' @param jaqlExpression the query to be executed
#' @param colnames the column names to be assigned to the resulting data.frame
#' @param coltypes the column types to be assigned to the resulting data.frame
#' @param limit indicates whether or not the resulting data.frame should be truncated
#' by the default getOption("bigr.row.limit"). If limit is not specified, it will be set to TRUE.
#' @return a data.frame with the result of the query
#' @rdname internal.bigr.executeJaqlQuery
#' @keywords internal
.bigr.executeJaqlQuery <- function(jaqlExpression, colnames, coltypes, limit, shouldReconnect=FALSE) {
    logSource <- ".bigr.executeJaqlQuery"
    
    # Check for missing parameters
    if (missing(colnames)) {
        colnames <- NULL
    }
    if (missing(coltypes)) {
        coltypes <- NULL
    }
    if (missing(limit)) {
        limit <- TRUE
    }
    if (missing(jaqlExpression)) {
        jaqlExpression <- NULL
    }    
    resultSet <- NULL
    query <- jaqlExpression 
    bigr.env$exceptionString <- ""
    exceptionMessage <- ""
    output <- tryCatch({
        
        # Check that the connection is active and the given query is not
        # null or empty.
        if (is.bigr.connected() & .bigr.validateJaql(jaqlExpression)) {
            # Append JaQL function to truncate rows if limit=TRUE
            if (limit) {
                if (.bigr.isNullOrEmpty(getOption("bigr.row.limit"))) {
                    bigr.setRowLimit(bigr.env$DEFAULT_ROW_LIMIT)
                }
                if (!.bigr.is.integer(getOption("bigr.row.limit"))) {
                    bigr.setRowLimit(bigr.env$DEFAULT_ROW_LIMIT)
                }
                if (getOption("bigr.row.limit") > 0) {
                    # Check if the return type of the query is an array            
                    bigr.info(logSource, "Checking query schema...")
                    schemaQuery <- "schemaof(" %++% query %++% ")"
                    bigr.info(logSource, schemaQuery)
                    qSchema <- .bigr.jdbc.query(schemaQuery)[[1]]                
                    if (.bigr.contains(qSchema, "[")) {
                        query <- query %++% " -> top " %++% getOption("bigr.row.limit")
                    }
                }
            }
            bigr.info(logSource, "Executing JaQL query: " %++% query)
            
            # Execute the query and measure its execution time
            timeBefore <- .bigr.currentTimeMillis()
            bigr.info(logSource, "Invoking jdbc driver's query method with parameters: ")
            bigr.info(logSource, "Colnames")
            bigr.info(logSource, colnames)
            bigr.info(logSource, "Coltypes")
            bigr.info(logSource, coltypes)            
            resultSet <- .bigr.jdbc.query(query, colnames=colnames, coltypes=coltypes)
            timeAfter <- .bigr.currentTimeMillis()
            elapsedTime <- (timeAfter - timeBefore) / 1000
            bigr.info(logSource, "Query execution time: " %++% elapsedTime %++% " s.")
        } else {
            if (.bigr.validateJaql(jaqlExpression)) {
                bigr.err(logSource, "Cannot execute statement. The connection to BigInsights is not active.")
            } else {
                bigr.info(logSource, "Invalid query: " %++% query)
            }
            return(NULL)
        }
        resultSet
    }, error = function(e) {        
        bigr.info(logSource, "An error was caught executing the query: " %++% query)
        bigr.env$exceptionString <- as.character(e)
        return(NULL)
    })
    if (is.null(output)) {        
        if (!bigr.testConnection()) {            
            if (shouldReconnect == TRUE) {
                bigr.infoUser(logSource, "Connection to BigInsights was lost. Reconnecting ...")                
                if (bigr.reconnect()) {
                    if (bigr.testConnection()) {
                        bigr.infoUser(logSource, "Reconnection was successful")
                    } else {
                        bigr.err(logSource, "Unable to reconnect to BigInsights.")
                    }
                } else {
                    bigr.err(logSource, "Unable to reconnect to BigInsights.")
                }
                return(.bigr.executeJaqlQuery(jaqlExpression, colnames, coltypes, limit=limit, shouldReconnect=FALSE))
            } else {
                if (.bigr.isNullOrEmpty(bigr.env$CONNECTION)) {
                    bigr.err(logSource, "A connection to BigInsights is needed before running this statement. Call bigr.connect().")
                } else {
                    bigr.err(logSource, "Connection to BigInsights was lost. Call bigr.reconnect() to try and restore it.")
                }
            }
        } else {
            errorMessage <- ""
            if (.bigr.contains(x=bigr.env$exceptionString, "java.lang.NumberFormatException: For input string: ")) {
                value <- strsplit(bigr.env$exceptionString, split="\"", fixed=T)[[1]][2]
                errorMessage <- "An alphanumeric value ('" %++% value %++% "') was found in a numeric column. Try changing the corresponding column type to 'character'. This could also occur if the file has headers but attribute 'header' was set to FALSE."
            } else if (.bigr.contains(bigr.env$exceptionString, "Wrong number of fields on input at position")) {
                errorMessage <- "The number of columns specified in colnames/coltypes does not match the number of columns in the dataset."
            } else {
                lines <- strsplit(bigr.env$exceptionString, "\n")[[1]]
                if (length(lines) > 3) {
                    errorMessage <- paste(lines[1:3], collapse="\n")
                } else {
                    errorMessage < bigr.env$exceptionString
                }
            }
            bigr.info(logSource, bigr.env$exceptionString)
            bigr.err(logSource, errorMessage)
        }
    } else {    
        return(output)
    }
}

#' Executes a given JaQL update. It returns a boolean value indicating whether the
#' update was successful or not. 
#' @param jaqlExpression the JaQL update to be executed
#' @return a boolean value indicating whether the update was successful or not. 
#' @rdname internal.bigr.executeJaqlUpdate
#' @keywords internal
.bigr.executeJaqlUpdate <- function(jaqlExpression) {
    logSource = ".bigr.executeJaqlUpdate"    
    if (missing(jaqlExpression)) {
        jaqlExpression <- NULL
    }
    output <- tryCatch({        
        #bigr.info(logSource, "Executing JaQL update: " %++% jaqlExpression)
        
        # Check that the connection is active and the JaQL update is valid
        if (is.bigr.connected() & .bigr.validateJaql(jaqlExpression)) {
            
            # Execute the update and measure its execution time
            timeBefore <- .bigr.currentTimeMillis()        
            result <- .bigr.jdbc.update(jaqlExpression)
            timeAfter <- .bigr.currentTimeMillis()
            elapsedTime <- (timeAfter - timeBefore) / 1000
            bigr.info(logSource, "Update execution time: " %++% elapsedTime %++% " s.")        
            return(is.null(result))
        } else {
            return(FALSE)
        }    
    }, error = function(e) {
        bigr.info(logSource, e)
        bigr.err(logSource, "Error executing JaQL update statement: " %++% jaqlExpression)
        return(NULL)
    })
}

#' Loads JaQL modules, which are .jaql files specified in bigr.env$JAQL_MODULES.
#' The entire content of these files will be executed as a JaQL update.
#' JaQL modules contain common functions supporting most of BigR data operations.
#' JaQL module files should not contain // comments
#' @rdname internal.bigr.loadJaqlModules
#' @keywords internal
.bigr.loadJaqlModules <- function() {
    logSource <- "loadJaqlModules"
    if (is.bigr.connected()) {
        for (i in 1 : length(bigr.env$JAQL_MODULES)) {
            .bigr.loadJaqlModule(bigr.env$JAQL_MODULES[i])
        }
    } else {
        bigr.err(logSource, "Cannot load JaQL modules since a connection to BigInsights is not active")
    }
    return(TRUE)
}

#' Loads a single JaQL module, thus, a .jaql file contaning common functions 
#' supporting most of BigR data operations. 
#' JaQL module files should not contain // comments
#' @param moduleFile a source JaQL file (.jaql)
#' @return a boolean value indicating whether or not the JaQL module
#' could be loaded.
#' @rdname internal.bigr.loadJaqlModule
#' @keywords internal
.bigr.loadJaqlModule <- function(moduleFile) {
    logSource = "loadJaqlModule"
    if (missing(moduleFile)) {
        moduleFile <- NULL
    }
    if (.bigr.isNullOrEmpty(moduleFile)) {
        bigr.err(logSource, "Internal error: Invalid JaQL module.")
    }
    if (is.bigr.connected()) {
        # Read JaQL file into a character variable by concatenating
        # all lines.
        modulePath <- system.file("jaql", moduleFile, package="bigr", mustWork=T)
        bigr.info(logSource, "Loading JaQL module '" %++% modulePath %++% "'...")
        lines <- readLines(modulePath)
        module <- paste(lines, collapse="\n")
        if (.bigr.validateJaql(module)) {
            # Execute all instructions in the module file
            return(.bigr.executeJaqlUpdate(module))
        } else {
            bigr.err(logSource, "Unable to load JaQL module '" %++% moduleFile %++% "'")
        }
    }  else {
        bigr.err(logSource, "Connection is not active")
    }
    return(FALSE)
}

#' Executes a sample query to test whether the connection is active
#' @keywords internal
bigr.testConnection <- function() {
    logSource <- "bigr.testConnection"
    bigr.info(logSource, "Testing connection...")
    if (!.bigr.jdbc.isValid()) {
        return (FALSE)
    }
    
    result <- tryCatch({
        .bigr.jdbc.query("1")        
    }, error = function(e) {
        bigr.info(logSource, "Error executing query: " %++% e)
        if (.bigr.contains(as.character(e), "java.lang.ClassNotFoundException: BigRResultSet")) {
            bigr.err(logSource, "Required library 'BigRResultSet' could not be found.")
        }
        NULL
    })
    if (.bigr.isNullOrEmpty(result)) {
        bigr.info(logSource, "Result was null")
        return(FALSE)
    }
    if (result[1,1] == "1") {
        return(TRUE)
    }
    return(FALSE)
}

#' Disconnect from BigInsights
#' 
#' @return a boolean indicating whether or not the connection was terminated.
#' @examples \dontrun{
#' > bigr.disconnect()}
bigr.disconnect <- function() {
    logSource <- "bigr.disconnect"
    bigr.info(logSource, "Disconnecting...")
    if (is.null(bigr.env$CONNECTION)) {
        invisible(FALSE)
    } else {
        bigr.env$CONNECTION@connected <- FALSE
        .bigr.jdbc.disconnect(bigr.env$CONNECTION@jdbcObj)
        invisible(TRUE)
    }
}

#' \code{bigr.server.connect} called by the R server code with the credentials
#' from client.
#'
#' @param connection holds the client side bigr.env$CONNECTION object
#' @return a logical value indicating whether or not the connection was successful
#' @keywords internal
.bigr.server.connect <- function(connection) {
    logSource <- ".bigr.server.connect"
    bigr.info(logSource, "Trying to establish connection...")
    
    if (missing(connection) || is.null(connection)) {
        bigr.err(logSource, "Cannot connect to BigInsights as no client connection credentials were provided.")
    }
    else if ("character" != class(connection)) {
        bigr.err(logSource, "Cannot connect to BigInsights as the client credentials were invalid")
    }
    
    # checking for package version and built mismatch
    vb <- packageDescription("bigr", fields=c("Version", "Date"))
    if (!identical(vb[[1]], connection[[6]]) || !identical(vb[[2]], connection[[7]])) {
        warning("The bigr package installed on one or more nodes of the cluster does not match the package installed on the client.\n" %++% 
                "Client Version: " %++% connection[[6]] %++% " Built: " %++% connection[[7]] %++%
                "\nServer Version: " %++% vb[[1]] %++% " Built: " %++% vb[[2]], call.=FALSE, immediate.=TRUE)
    }
    
    # update the JDBC driver path since the server's JDBC driver diffs from the client
    connection <- c(connection, .bigr.getJDBCDriverPath())
    
    # connect
    bigr.connect(connection[[1]], as.integer(connection[[2]]), connection[[3]], 
                 connection[[4]], connection[[5]], connection[[8]])
    
    return(is.bigr.connected())
}

#' Execute a given Jaql query. This is a simpler version of bigr.executeJaqlQuery.
#' @param jaqlExpression the query to be executed
#' @return a data.frame with the result of the query
#' @keywords internal
.bigr.execQuery <- function(jaqlExpression) {
    logSource <- ".bigr.execQuery"
    bigr.info(logSource, "Executing the Jaql Query: " %++% jaqlExpression)
    resultSet <- NULL
    if (is.bigr.connected()) {
        b4 <- Sys.time()
        resultSet <- .bigr.jdbc.query(queryText=jaqlExpression)
        dt <- difftime(Sys.time(), b4)
        bigr.info(logSource, "Query ran for " %++% round(dt,2) %++% units(dt))
    }
    else {
        bigr.err(logSource, "The statement could not be executed because there is no active connection to BigInsights."); 
    }
    return (resultSet)
}

#' Execute a given Jaql update. This is a simpler version of bigr.executeJaqlUpdate.
#' If the update was successful, TRUE is returned. Otherwise, it returns FALSE
#' @param jaqlExpression the query to be executed
#' @return TRUE/FALSE
#' @keywords internal
.bigr.execUpdate <- function(jaqlExpression) {        
    logSource = ".bigr.execUpdate"
    bigr.info(logSource, "Executing the Jaql Update: " %++% jaqlExpression)
    if (is.bigr.connected()) {
        b4 <- Sys.time()
        result <- .bigr.jdbc.update(jaqlExpression)
        dt <- difftime(Sys.time(), b4)
        bigr.info(logSource, dt %++% units(dt))
        return(is.null(result))
    } else {
        return(FALSE)
    }
}
