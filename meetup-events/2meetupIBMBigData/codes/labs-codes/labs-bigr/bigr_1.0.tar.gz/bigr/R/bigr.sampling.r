#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' This method sets the seed for the BigR random number generator. 
#' @param seed a positive integer number
bigr.set.seed <- function(x) {
    logSource <- "bigr.set.seed"
    
    # Parameter validation
    if (missing(x)) {
        x <- NULL
    }
    if (.bigr.isNullOrEmpty(x)) {
        bigr.err(logSource, "Invalid random seed.")
    }
    if (!.bigr.is.integer(x)) {
        bigr.err(logSource, "Invalid random seed.")
    }
    if (x <= 0) {
        bigr.err(logSource, "Invalid random seed.")
    }
    
    # Set this seed against the default RNG. This will make random01() work.
    bigr.registerRNG(bigr.env$DEFAULT_RNG, x)
    
    # Assign new value to the corresponding variable in the BigR environment
    bigr.env$RANDOM_SEED <- x    
}

#' Generate one or more samples from a bigr.frame.
#' 
#' Two sampling methods are supported:
#' 
#' 1. Random sampling: Generate a random subset of the given bigr.frame with 
#' the specified size in the form of either a percentage or an exact number 
#' of samples. In this case, only one of \code{perc} or \code{nsamples} must 
#' be specified.
#' 
#' 2. Partitioned sampling: Split the given bigr.frame into the specified 
#' number of randomly generated, non-overlapping subsets. In this case, only 
#' \code{data} and \code{perc} should be specified.
#' 
#' @name bigr.sample
#' @title Random sampling
#' @usage bigr.sample(data, perc, nsamples)
#' @param data (bigr.frame) The data to sample from
#' @param perc (numeric) For random sampling, an atomic value between (0, 1) 
#'   that represents the sampling percentage. For partitioned sampling, a 
#'   vector of numerics in the interval (0, 1), such that their sum is 
#'   exactly 1.
#' @param nsamples (integer) exact sample size (i.e. number of rows) to draw
#' @return For random sampling, a single bigr.frame is returned. For
#'   partitioned sampling, a list of bigr.frames is returned, and each
#'   bigr.frame in the list represents a partition.
#' 
#' @examples \dontrun{
#' 
#' # Generate a 10% random sample of data
#' airs <- bigr.sample(air, 0.1)
#' bigr.persist(air, dataSource = "DEL", dataPath = "airline_10percent",
#'              header = T, delimiter = F)
#' 
#' # Randomly split the data into training (70%) and test (30%) sets
#' airsplit <- bigr.sample(air, c(0.7, 0.3))
#' 
#' # Randomly split the data for 10-fold cross-validation
#' aircv <- bigr.sample(air, rep(0.1, 10))
#' 
#' # Randomly draw 10000 rows from the dataset
#' air10k <- bigr.sample(air, nsamples=10000)
#' }
#' @seealso \link{bigr.set.seed}, \link{bigr.persist}
#'
NULL

# bigr.sample
#      Note that 'byrow' is currently undocumented.
bigr.sample <- function(data, perc, nsamples, byrow) {
    logSource <- "bigr.sample"

    # Parameter validation
    if (missing(data)) {
        data <- NULL
    }
    if (missing(perc)) {
        perc <- NULL
    }
    if (missing(nsamples)) {
        nsamples <- NULL
    }
    if (missing(byrow)) {
        byrow <- NULL
    }
    
    if (.bigr.isNullOrEmpty(data)) {
        bigr.err(logSource, "A dataset must be specified")   
    }    
    if (.bigr.isNullOrEmpty(perc) && .bigr.isNullOrEmpty(nsamples) && .bigr.isNullOrEmpty(byrow)) {
        bigr.err(logSource, "One of perc, nsamples, or byrow must be specified.")
    }
    if (!.bigr.isNullOrEmpty(perc) && !.bigr.isNullOrEmpty(nsamples)) {
        bigr.err(logSource, "Only one of perc and nsamples can be specified.")
    }
    if (!.bigr.isNullOrEmpty(byrow) && !.bigr.isNullOrEmpty(nsamples)) {
        bigr.err(logSource, "Only one of byrow and nsamples can be specified.")
    }
    if (!.bigr.isNullOrEmpty(byrow) && !.bigr.isNullOrEmpty(perc)) {
        bigr.err(logSource, "Only one of perc and byrow can be specified.")
    }
    if (class(data) != bigr.env$FRAME_CLASS_NAME) {
        bigr.err(logSource, "The specified dataset must be a '" %++% bigr.env$FRAME_CLASS_NAME %++% "'")
    }
    
    # Random sampling with an exact number of samples
    if (!.bigr.isNullOrEmpty(nsamples)) {
        if (!.bigr.is.integer(nsamples)) {
            bigr.err(logSource, "The number of samples (nsamples) must be a positive integer number")
        }
        if (nsamples > nrow(data)) {
            bigr.err(logSource, "The specified sample size (nsamples) cannot be greater than the dataset's number of rows")
        }
        if (nsamples < 1) {
            bigr.err(logSource, "The specified sample size (nsamples) cannot be below 1")
        }
        jaqlExpr <- "uniformSampling2(" %++% 
            .bigr.getJaqlExpression(data) %++% ", " %++% 
            nsamples %++% ", " %++% nrow(data) %++% ", " %++% 
            bigr.env$RANDOM_SEED %++% 
            ")"
        file = as.character(.bigr.executeJaqlQuery(jaqlExpr, limit=FALSE));
        bigr.info(logSource, "Sample was saved to: " %++% as.character(file))
        
        # Create a environment that holds metadata for any temporary files, and 
        # register a finalizer for it. These files will be removed when the environment
        # cannot be accessed.        
        e <- new.env(parent = emptyenv())
        e$finals <- file
        reg.finalizer(e, .bigr.remove.files)
        envs <- list(e)
        
        sampleBf <- new(bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TEXT_FILE, 
                        dataPath=file, colnames=data@colnames, coltypes=data@coltypes, 
                        delimiter=data@delimiter, localProcessing=data@localProcessing, na.string=data@na.string,
                        envs = envs)
        return(sampleBf)		
    }	
    
    # Random sampling with sample sizes provided as percentage(s)
    if (!.bigr.isNullOrEmpty(perc)) {
        if (!is.numeric(perc)) {
            bigr.err(logSource, "The specified value for perc must be a real number within the interval (0, 1)")
        }
        # Single percentage specified
        if (length(perc) == 1) {
            if (perc <= 0 | perc >= 1) {
                bigr.err(logSource, "The specified value for perc must be within the interval (0, 1)")
            }
            jaqlExpr <- "uniformSampling1(" %++% 
                .bigr.getJaqlExpression(data) %++% ", " %++% 
                perc %++% ", " %++% 
                bigr.env$RANDOM_SEED %++% 
                ")"
            file = as.character(.bigr.executeJaqlQuery(jaqlExpr), limit=FALSE);
            bigr.info(logSource, "Sample was saved to: " %++% file)
            
            # Create a environment that holds metadata for any temporary files, and 
            # register a finalizer for it. These files will be removed when the environment
            # cannot be accessed.                    
            e <- new.env(parent = emptyenv())
            e$finals <- file
            reg.finalizer(e, .bigr.remove.files)
            envs <- list(e)
            
            sampleBf <- new(bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TEXT_FILE, 
                            dataPath=file, colnames=data@colnames, coltypes=data@coltypes, 
                            delimiter=data@delimiter, localProcessing=data@localProcessing, na.string=data@na.string, 
                            envs = envs)
            return(sampleBf)		
        } else {
            return(bigr.partitionedSampling(data, perc) )
            
            # Old partitioned sampling
            if (1 == 2) {
                # Partitioned sampling
                if (any(perc <= 0 | perc >= 1)) {
                    bigr.err(logSource, "The specified values for perc must be within the interval (0, 1)")
                }
                if (sum(perc) != 1) {
                    bigr.err(logSource, "The specified values for perc must add up to 1")
                }		    
                
                bigr.info(logSource, "Generating roulette...")
                
                # Generate a roulette to be passed to JaQL
                roulette <- perc
                for (i in 2:length(roulette)) {
                    roulette[i] <- roulette[i - 1] + roulette[i]
                }
                
                # Build JaQL expression and run JaQL query
                jaqlExpr <- "rouletteSampling(" %++% 
                    .bigr.getJaqlExpression(data) %++% 
                    ", [" %++% paste(roulette, collapse=", ") %++% "], " %++%
                    bigr.env$RANDOM_SEED %++%
                    ")"
                df <- .bigr.executeJaqlQuery(jaqlExpr, limit=FALSE)            		    
                
                # Get a list of file paths corresponding to each partition
                bigr.info(logSource, "Generating bigr.frame's...")
                fileList <- df$file            
                bigr.info(logSource, "Samples were saved to: " %++% paste(fileList, collapse="\n"))
                
                # Build the list of resulting bigr.frame's (one per file)            
                bfSamples <- .bigr.build.frames(data, fileList)
                if (is.null(bfSamples)) {
                    bigr.err(logSource, "Samples could not be created to HDFS. Check for permissions and " %++%
                                 "available space in HDFS")
                }
                return(bfSamples)
            }
        }	    	
    }	
    
    # Systematic sampling
    if (!.bigr.isNullOrEmpty(byrow)) {
        if (!.bigr.is.integer(byrow)) {
            bigr.err(logSource, "Specified value for byrow must be a positive integer number")
        }
        if (byrow > nrow(data)) {
            bigr.err(logSource, "Specified value for byrow cannot exceed the dataset number of rows.")
        }
        if (byrow < 1) {
            bigr.err(logSource, "Specified value for byrow must be greater than zero.")
        }
        
        # Build JaQL expression and run JaQL query
        jaqlExpr <- "systematicSampling(" %++% .bigr.getJaqlExpression(data) %++% ", " %++% byrow %++% ")"
        df <- .bigr.executeJaqlQuery(jaqlExpr, limit=FALSE)   
        
        # Get a list of file paths corresponding to each partition
        fileList <- df$file
        
        # Build the list of resulting bigr.frame's (one per file)            
        bfSamples <- .bigr.build.frames(data, fileList)
        if (is.null(bfSamples)) {
            bigr.err(logSource, "Samples could not be created to HDFS. Check for permissions and " %++%
                         "available space in HDFS")
        }
        return(bfSamples)
    }
}

bigr.partitionedSampling <- function(data, perc) {
    logSource <- "bigr.partitionedSampling"
    # Partitioned sampling
    if (any(perc <= 0 | perc >= 1)) {
        bigr.err(logSource, "The specified values for perc must be within the interval (0, 1)")
    }
    if (sum(perc) != 1) {
        bigr.err(logSource, "The specified values for perc must add up to 1")
    }    	    
    
    bigr.info(logSource, "Generating roulette...")
    ncols <- ncol(data)
    
    # Generate a roulette to be passed to JaQL
    roulette <- c(0, perc)
    for (i in 2:length(roulette)) {
        roulette[i] <- roulette[i - 1] + roulette[i]
    }
    
    # Build JaQL expression and run JaQL query        
    jaqlExpr <- .bigr.getJaqlExpression(data) %++% "\n-> transform [" %++%
        paste("$[" %++% (seq(1:ncols) - 1), "]", collapse=", ", sep="") %++%        
        ", random01()]\n"
        
    
    fileList <- NA
    i <- 0
    for (i in 1:(length(roulette) - 2)) {
        fileList[i] <- bigr.generateFileName()
        jaqlExpr <- jaqlExpr %++% "-> tee (-> filter ($[" %++% (ncols) %++% "] > " %++% roulette[i] %++%
                    ") and ($[" %++% (ncols) %++% "] <= " %++% roulette[i + 1] %++% ") " %++% 
                    "-> transform [" %++% paste("$[" %++% (seq(1:ncols) - 1), "]", collapse=", ", sep="") %++% "]" %++%
                    "-> write(del('" %++% fileList[i] %++% "')))\n"
    }
    i <- length(roulette) - 1
    fileList[i] <- bigr.generateFileName()
    jaqlExpr <- jaqlExpr %++% "-> filter ($[" %++% (ncols) %++% "] > " %++% roulette[i] %++%
        ") and ($[" %++% (ncols) %++% "] <= " %++% roulette[i + 1] %++% ") " %++% 
        "-> transform [" %++% paste("$[" %++% (seq(1:ncols) - 1), "]", collapse=", ", sep="") %++% "]" %++%
        "-> write(del('" %++% fileList[i] %++% "'))\n"
    
    df <- .bigr.executeJaqlQuery(jaqlExpr, limit=FALSE)            		    
    
    # Get a list of file paths corresponding to each partition
    bigr.info(logSource, "Generating bigr.frame's...")
    bigr.info(logSource, "Samples were saved to: " %++% paste(fileList, collapse="\n"))
    
    # Build the list of resulting bigr.frame's (one per file)            
    bfSamples <- .bigr.build.frames(data, fileList)
    if (is.null(bfSamples)) {
        bigr.err(logSource, "Samples could not be created to HDFS. Check for permissions and " %++%
                     "available space in HDFS")
    }
    return(bfSamples)
}

#' This method builds a list of bigr.frame's given a list of file locations.
#' @param data a factory bigr.frame which specifies all common parameters for the bigr.frame's to be created
#' @param fileList a vector of character values specifying the file locations for each bigr.frame.
#' @keywords internal
.bigr.build.frames <- function(data, fileList) {
    if (.bigr.isNullOrEmpty(fileList)) {
        return(NULL)
    }
    bfSamples <- list()
    for (i in 1:length(fileList)) {
        
        # Create a environment that holds metadata for any temporary files, and 
        # register a finalizer for it. These files will be removed when the environment
        # cannot be accessed.                
        e <- new.env(parent = emptyenv())
        e$finals <- fileList[i]
        reg.finalizer(e, .bigr.remove.files)
        envs <- list(e)
        
        bfSamples[[i]] <- new(bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TEXT_FILE, 
                              dataPath=fileList[i], colnames=data@colnames, coltypes=data@coltypes, 
                              delimiter=data@delimiter, localProcessing=data@localProcessing, 
                              na.string=data@na.string, envs = envs)
    }
    return(bfSamples)
}
