#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

# bigr.catalog.r
#
# This file contains functions that provide access to the Big SQL catalog.
#

#' Returns a data.frame describing database tables
#' 
#' @title List Big SQL database tables
#' @param fulltablename (character) Name of the table. Can be a simple regular expression
#'   such as "syscat.*"
#' @param expand (logical) Controls whether the regular expression is expanded.
#'   Defaults to TRUE.
#' @examples \dontrun{
#' bigr.listTables("system.dual")
#' bigr.listTables("system.*")
#' bigr.listTables("*.dual")
#' bigr.listTables("*.*")}
#' @seealso \code{\link{bigr.listColumns}}
bigr.listTables <- function(fulltablename = "*.*", expand = T) {
    logSource <- "bigr.listTables"
        
    bigr.info(logSource, "Get tablenames matching: " %++% fulltablename)

    if (.bigr.isNullOrEmpty(fulltablename) | fulltablename == '*') {
        fulltablename <- '*.*'
    }
    .bigr.checkParameter(logSource, expand, expectedValues=c(T, F))
    
    nameparts <- unlist(strsplit(fulltablename, "\\."))
    if (length(nameparts) <= 1) {
        schemaname <- "default"
        tablename <- nameparts[1]
    } else if (length(nameparts) == 2) {
        schemaname <- nameparts[1]
        tablename <- nameparts[2]
    } else {
        bigr.err(logSource, "Invalid tablename specified: '" %++% fulltablename %++% "'")
    }
    
    qry <- "syscattables "   
    if (!expand | (schemaname != '*' & tablename != '*')) {
        # Finding an exact match
        qry <- qry %++% ' -> filter $.schemaname == "' %++% schemaname %++% '"' %++%
                        '   and  $.tablename  == "' %++% tablename %++% '"'
    }
    else if (schemaname != '*') {
        qry <- qry %++% ' -> filter $.schemaname  == "' %++% schemaname %++% '"'
    }
    else if (tablename != '*') {
        qry <- qry %++% ' -> filter $.tablename  == "' %++% tablename %++% '"'
    }
    
    bigr.info(logSource, "Executing query: " %++% qry)
    
    return (.bigr.execQuery(qry))
}

#' Returns a data.frame describing database columns
#' 
#' @title List Big SQL database columns 
#' @param fulltablename (character) Name of the table. Can be a simple regular expression
#'   such as "syscat.*"
#' @param expand (logical) Controls whether the regular expression is expanded.
#'   Defaults to TRUE.
#' @examples \dontrun{
#' bigr.listColumns("system.dual")
#' bigr.listColumns("system.*")
#' bigr.listColumns("*.dual")
#' bigr.listColumns("*.*")}
#' @seealso \code{\link{bigr.listColumns}}

bigr.listColumns <- function(fulltablename = "*.*", expand = T) {
    logSource <- "bigr.listColumns"
    
    .bigr.checkParameter(logSource, expand, expectedValues=c(T, F))
    
    # Ensure that the table exists. This is inefficient.
    tables <- bigr.listTables(fulltablename, expand)
    if (is.null(tables) | nrow(tables) == 0)
        return (data.frame())
    
    cols <- data.frame()
    for (i in seq_along(tables[,1])) {
        name <- paste(tables[i,1], tables[i,2], sep=".")
        query <- sprintf(
                    'syscatColumns -> filter $.schemaname == "%s" and $.tablename == "%s"',
                     tables[i,1], tables[i,2])
        bigr.info(logSource, "Executing query: " %++% query)
        
        cols <- rbind(cols, .bigr.execQuery(query))
    }
    cols$type <- tolower(cols$type)
    return (cols);
}

#' List files on the BigInsights file system
#'
#' @param pathExpression Name of a file/directory, or a simple glob. Hidden files, i.e. files whose 
#' names start with a period (".")) are not returned
#' @param directoryOnly  Should only the directory be returned (TRUE), or should the directory contents be returned (FALSE)? Default is FALSE.
#' @param compact Return only selected fields (TRUE), or all of them (FALSE)?
#' @examples \dontrun{
#' bigr.listfs("/tmp")
#' bigr.listfs("/home/biadmin/*")}
bigr.listfs <-function(pathExpression, directoryOnly = FALSE, compact = TRUE) {
    
    logSource <- "bigr.listColumns"
    if (missing(pathExpression))
        pathExpression = "/";

    colnames <- c("path", "owner", "length", "blockSize", "permission", "group", "accessTime", "modifyTime", "replication")
    if (compact)
        colnames <- colnames[1:5]
    
    colnames <- paste("$.", colnames, sep="", collapse=", ")
    qry <- sprintf("ls('%s', %s) -> transform { %s };",
                   pathExpression, ifelse(directoryOnly, "true", "false"), colnames)
    df <- .bigr.execQuery(qry)
    
    # Remove the fs prefix (e.g. "hdfs://localhost:9000") from the filenames
    prefix <- .bigr.execQuery("ls('/', true) -> transform { $.path }")[1,1]
    df$path <- sub(prefix, "/", df$path)
    
    df
}

