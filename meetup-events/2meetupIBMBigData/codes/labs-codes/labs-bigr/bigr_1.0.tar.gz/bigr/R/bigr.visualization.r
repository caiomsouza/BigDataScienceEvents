#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' This function generates a boxplot for a given formula or bigr.vector.
#'
#' If a formula is passed as parameter, it must specify:
#' 
#' 1. A bigr.frame as the data origin
#' 2. A bigr.vector with the target column for the boxplot
#' 3. One or more grouping columns separated by the + operator (see example below)
#'
#' @param formula a formula or a bigr.vector specifying the data source
#' @param data optional bigr.vector
#' @return a ggplot with the generated boxplot
#' @examples \dontrun{
#' # Render a boxplot of the saleprice column in bigr.frame homes:
#' bigr.boxplot(homes$saleprice)
#'
#' # Render a boxplot of the saleprice column in bigr.frame homes for each distinct zipcode:
#' bigr.boxplot(homes$saleprice ~ homes$zipcode)
#'
#' # Render a boxplot of the saleprice column in bigr.frame homes for each distinct 
#' combination of zipcode and floor.
#' bigr.boxplot(homes$saleprice ~ homes$zipcode + homes$floors)}
#' @keywords internal
bigr.boxplot <- function (formula, data=NULL) {
    logSource <- "bigr.boxplot"
  
    # Require ggplot library
    require(ggplot2)
  
    # Invoke method bigr.boxplot.stats to compute plot statistics
    boxplotData <- bigr.boxplot.stats(formula, data)
  
    # Get axis labels
    targetColname <- boxplotData[[1]]
    groupByColnames <- boxplotData[[2]]
  
    # Get box plot stats (i.e., quartiles, max, min)
    boxplotStats <- boxplotData[[3]]
  
    # Build the plot with the specified statistics
    plot <- NULL
  
    # If grouping columns were specified
    if (length(groupByColnames) > 0) {
        plot <- ggplot(boxplotStats, aes(x = class, ymin = Min, lower = Q1, 
                                     middle = Median, upper = Q3, ymax = Max))
    } else {
        plot <- ggplot(boxplotStats, aes(x = "", ymin = Min, lower = Q1, 
                                     middle = Median, upper = Q3, ymax = Max))
    }

    # Parameter stat="identity" specifies that the input data for the plot
    # are precomputed statistics.
    plot <- plot + geom_boxplot(stat = "identity")

    # Add axis labels
    plot <- plot + ylab(targetColname)
    plot <- plot + xlab(paste(groupByColnames, collapse = ", "))
    
    # Return/display the plot
    return(plot)
}

#' This function computes statistics to render a boxplot. These are: minimum, maximum,
#' and quartiles.
#'
#' If a formula is passed as parameter, it must specify:
#' 
#' 1. A bigr.frame as the data origin
#' 2. A bigr.vector with the target column for the boxplot
#' 3. One or more grouping columns separated by the + operator (see example below)
#'
#' @param formula a formula or a bigr.vector specifying the data source
#' @param data optional bigr.vector
#' @return a data.frame with the computed statistics
#' @examples \dontrun{
#' --Calculate boxplot statistics for the saleprice column in bigr.frame homes:
#' bigr.boxplot.stats(homes$saleprice)
#' 
#' -- Calculate boxplot statistics for the saleprice column in bigr.frame homes for each distinct zipcode:
#' bigr.boxplot.stats(homes$saleprice ~ homes$zipcode)
#' 
#' -- Calculate boxplot statistics for the saleprice column in bigr.frame homes for each distinct 
#' combination of zipcode and floor.
#' bigr.boxplot.stats(homes$saleprice ~ homes$zipcode + homes$floors)}
#' @keywords internal
bigr.boxplot.stats <- function (formula, data=NULL) {
    logSource <- "boxplot.stats"
  
    # The dataset from which statistics will be computed. It could be
    # a bigr.vector (if no grouping columns specified) or a bigr.frame
    dataset <- NULL
    
    # The id of the column from which statistics will be computed
    targetColId <- NULL
    
    # The name of the column from which statistics will be computed
    targetColname <- NULL
    
    # The id's of the grouping columns
    groupByColIds <- vector()
    
    # The names of the grouping columns
    groupByColnames <- vector()
    
    # Parse the formula and extract variables
    parsedFormula <- .bigr.parseFormulaToPlot(formula, data)
    if (is.null(parsedFormula)) {
        bigr.err(logSource, "The provided formula is not valid.")
    }

    # Notice the column ids should be adjusted to JaQL's (starting from zero)
    dataset <- parsedFormula[[1]]
    targetColId <- parsedFormula[[2]] - 1
    targetColname <- parsedFormula[[3]]
    
    # Notice the column ids should be adjusted to JaQL's (starting from zero)
    groupByColIds <- parsedFormula[[4]] - 1
    groupByColnames <- parsedFormula[[5]]
    
    bigr.info(logSource, "groupByColIds: ")
    bigr.infoShow(groupByColIds)
    # Filter null values (i.e., NA's) in all grouping columns
    datasetExpr <- .bigr.getJaqlExpression(dataset)
    if (length(groupByColIds) > 0) {
        filter <- "filter " %++% paste("not isnull($[" %++% groupByColIds %++% 
                                    "])", collapse = " and ")
        datasetExpr <- .bigr.getJaqlExpression(dataset) %++% " -> " %++% filter
    }

    jaqlExpr <- "boxplot(" %++% datasetExpr %++% ", " %++% targetColId %++% 
      ", [" %++% paste(groupByColIds, collapse = ", ") %++% "])"    		

    # class, min, q1, q2, q4, min
    statsColtypes <- c("character", rep("numeric", 5)) 

    # Remove column 'class' from the query if no grouping columns were specified.
    # Otherwise, the JDBC driver will throw an
    # exception since the values for class are [].
    if (length(groupByColIds) == 0) {	
        jaqlExpr <- jaqlExpr %++% " -> transform {${* - .class}}"
        statsColtypes <- c(rep("numeric", 5))
    }

    # Invoke JaQL function boxplot to compute statistics
    boxplotStats <- .bigr.executeJaqlQuery(jaqlExpr, limit = FALSE, coltypes=statsColtypes)

    # Return the statistics along with the axis labels
    return(list(targetColname, groupByColnames, boxplotStats))
}

#' This function renders a histogram for a given dataset.
#'
#' If a formula is passed as parameter, it must specify:
#' 
#' 1. A bigr.frame as the data origin
#' 2. A bigr.vector with the target column for the boxplot
#' 3. One or more grouping columns separated by the + operator (see example below)
#'
#' @param formula a formula or a bigr.vector specifying the data source
#' @param nbins the number of bins (optional)
#' @param data optional bigr.vector
#' @return a data.frame with the computed statistics
#' @examples \dontrun{
#' # Render a histogram for the saleprice column in bigr.frame homes:
#' bigr.histogram(homes$saleprice)
 
#' # Render a histogram (five bins) for the saleprice column in bigr.frame homes 
#' # for each distinct zipcode.
#' bigr.histogram(homes$saleprice ~ homes$zipcode, nbins=5)
#'
#' # Render a histogram for the saleprice column in bigr.frame homes for each distinct 
#' combination of zipcode and floor.
#' bigr.histogram(homes$saleprice ~ homes$zipcode + homes$floors)}
bigr.histogram <- function (formula, nbins, data=NULL) {
    logSource <- "bigr.histogram"
    
    # Require ggplot library
    require(ggplot2)
    
    # Compute statistics for the histogram
    histData <- bigr.histogram.stats(formula, nbins, data)
    
    # Get the target column name
    targetColname <- histData[[1]]
    
    # Get the grouping column
    groupByColnames <- histData[[2]]
    
    # Get the input data for the plot
    histStats <- histData[[3]]
    
    # Initialize the plot with the calculated statistics
    plot <- ggplot(histStats, aes(x = centroids, y = counts))
    
    # If attribute class is part of histStats, then a histogram
    # should be plot for each group value.
    if (!is.null(histStats$class)) {
        groups <- unique(histStats$class)
        for (group in groups) {
            plot <- plot + geom_histogram(data = histStats[histStats$class == 
                                                         group, ], stat = "identity", binwidth = 100)
        }
        plot <- plot + facet_wrap(~class, scales = "free_y")
    } else {
        # If there's no attribute class, it means that no grouping columns
        # were specified. Hence, only one histogram should be plot.
        plot <- plot + geom_histogram(data = histStats, stat = "identity", binwidth = 100)
    }
    plot <- plot + xlab(targetColname) + ylab("Frequency")
    return(plot)
}

#' This function computes statistics to render a histogram. These are centroids and counts.
#'
#' If a formula is passed, it must specify
#' 
#' 1. A bigr.frame as the data origin
#' 2. A bigr.vector with the target column for the boxplot
#' 3. One or more grouping columns separated by the + operator (see example below)
#'
#' @param formula a formula or a bigr.vector specifying the data source
#' @param nbins the number of bins (optional)
#' @param data optional bigr.vector
#' @return a data.frame with the computed statistics
#' @examples \dontrun{
#' --Calculate histogram statistics for the saleprice column in bigr.frame homes:
#' bigr.histogram.stats(homes$saleprice)
#' 
#' -- Calculate histogram statistics (five bins) for the saleprice column in bigr.frame homes 
#' for each distinct zipcode.
#' bigr.histogram.stats(homes$saleprice ~ homes$zipcode, nbins=5)
#'
#' -- Calculate histogram statistics for the saleprice column in bigr.frame homes for each distinct 
#' combination of zipcode and floor.
#' bigr.histogram.stats(homes$saleprice ~ homes$zipcode + homes$floors)}
#' @keywords internal
bigr.histogram.stats.old <- function (formula, nbins, data=NULL) {
    logSource <- "bigr.histogram.stats.old"
    
    # Use default number of bins if none specified
    if (missing(nbins)) {
        nbins <- bigr.env$DEFAULT_NBINS
    }	
    
    # Validate nbins
    if (!.bigr.is.integer(nbins)) {
        bigr.err(logSource, "The number of bins must be a positive integer number greater than 1.")
    }
    if (nbins < 2) {
        bigr.err(logSource, "The number of bins must be a positive integer number greater than 1.")
    }
    
    # The dataset from which statistics will be computed. It could be
    # a bigr.vector (if no grouping columns specified) or a bigr.frame
    dataset <- NULL
    
    # The id of the column from which statistics will be computed
    targetColId <- NULL
    
    # The name of the column from which statistics will be computed
    targetColname <- NULL
  
    # The id's of the grouping columns
    groupByColIds <- vector()
      
    # The names of the grouping columns
    groupByColnames <- vector()
      
    # Parse the formula and extract variables
    parsedFormula <- .bigr.parseFormulaToPlot(formula, data)
    if (is.null(parsedFormula)) {
        bigr.err(logSource, "The provided formula is not valid.")
    }
      
    # Notice the column ids should be adjusted to JaQL's (starting from zero)
    dataset <- parsedFormula[[1]]
    targetColId <- parsedFormula[[2]] - 1
    targetColname <- parsedFormula[[3]]
    
    # Notice the column ids should be adjusted to JaQL's (starting from zero)
    groupByColIds <- parsedFormula[[4]] - 1
    groupByColnames <- parsedFormula[[5]]
  
    # Filter null values (i.e., NA's) in all grouping columns
    datasetExpr <- .bigr.getJaqlExpression(dataset)
    if (length(groupByColIds) > 0) {
        filter <- "filter " %++% paste("not isnull($[" %++% groupByColIds %++% 
                                    "])", collapse = " and ")
        datasetExpr <- .bigr.getJaqlExpression(dataset) %++% " -> " %++% filter
    }
  
    jaqlExpr <- "histogram(" %++% datasetExpr %++% ", " %++% nbins %++% 
        ", " %++% targetColId %++% ", [" %++% paste(groupByColIds, collapse = ", ") %++% 
        "])"
  
    # Remove column 'class' from the query if no grouping columns were specified.
    # Otherwise, the JDBC driver will throw an
    # exception since the values for class are [].
    ctypes <- c("character", "numeric", "numeric")
    if (length(groupByColIds) == 0) {	
        jaqlExpr <- jaqlExpr %++% " -> transform {${* - .class}}"
        ctypes = c("numeric", "numeric")    
    }
    
    histStats <- .bigr.executeJaqlQuery(jaqlExpr, limit = FALSE, coltypes=ctypes)
  
    # Remove last bin, which only contains the max value
    #histStats[nrow(histStats) - 1, length(ctypes)] <-  histStats[nrow(histStats) - 1, length(ctypes)] + 1
    #histStats[nrow(histStats), ] <- NA
  
    # Return the statistics along with the axis labels
    return(list(targetColname, groupByColnames, histStats))
}

#' This function computes statistics to render a histogram. These are centroids and counts.
#'
#' If a formula is passed, it must specify
#' 
#' 1. A bigr.frame as the data origin
#' 2. A bigr.vector with the target column for the boxplot
#' 3. One or more grouping columns separated by the + operator (see example below)
#'
#' @param formula a formula or a bigr.vector specifying the data source
#' @param nbins the number of bins (optional)
#' @param data optional bigr.vector
#' @return a data.frame with the computed statistics
#' @examples \dontrun{
#' --Calculate histogram statistics for the saleprice column in bigr.frame homes:
#' bigr.histogram.stats(homes$saleprice)
#' 
#' -- Calculate histogram statistics (five bins) for the saleprice column in bigr.frame homes 
#' for each distinct zipcode.
#' bigr.histogram.stats(homes$saleprice ~ homes$zipcode, nbins=5)
#'
#' -- Calculate histogram statistics for the saleprice column in bigr.frame homes for each distinct 
#' combination of zipcode and floor.
#' bigr.histogram.stats(homes$saleprice ~ homes$zipcode + homes$floors)}
bigr.histogram.stats <- function (formula, nbins, data=NULL) {
    require(plyr)
    logSource <- "bigr.histogram.stats"
    
    # Use default number of bins if none specified
    if (missing(nbins)) {
        nbins <- bigr.env$DEFAULT_NBINS
    }    
    
    # Validate nbins
    if (!.bigr.is.integer(nbins)) {
        bigr.err(logSource, "The number of bins must be a positive integer number greater than 1.")
    }
    if (nbins < 2) {
        bigr.err(logSource, "The number of bins must be a positive integer number greater than 1.")
    }
    
    # The dataset from which statistics will be computed. It could be
    # a bigr.vector (if no grouping columns specified) or a bigr.frame
    dataset <- NULL
    
    # The id of the column from which statistics will be computed
    targetColId <- NULL
    
    # The name of the column from which statistics will be computed
    targetColname <- NULL
    
    # The id's of the grouping columns
    groupByColIds <- vector()
    
    # The names of the grouping columns
    groupByColnames <- vector()
    
    # Parse the formula and extract variables
    parsedFormula <- .bigr.parseFormulaToPlot(formula, data)
    if (is.null(parsedFormula)) {
        bigr.err(logSource, "The provided formula is not valid.")
    }
    
    # Notice the column ids should be adjusted to JaQL's (starting from zero)
    dataset <- bigr.vectorToFrame(parsedFormula[[1]])
    targetColId <- parsedFormula[[2]] - 1
    targetColname <- parsedFormula[[3]]
    
    # Notice the column ids should be adjusted to JaQL's (starting from zero)
    groupByColIds <- parsedFormula[[4]] - 1
    groupByColnames <- parsedFormula[[5]]
    
    # Filter null values (i.e., NA's) in all grouping columns as well as in the target column
    datasetExpr <- .bigr.getJaqlExpression(dataset)
    if (length(groupByColIds) > 0) {
        filter <- "filter " %++% 
            paste("(not isnull($[" %++% groupByColIds %++% "]))", collapse = " and ") %++% 
                            " and (not isnull($[" %++% targetColId %++% "]))"
        dataset@tableExpression <- dataset@tableExpression %++% " -> " %++% filter
    } else {
        dataset@tableExpression <- dataset@tableExpression %++% 
            " -> filter (not isnull(" %++% dataset@columnExpression %++% "))"
    }
    
    boundsFormulaString <- "max(" %++% targetColname %++% ") +" %++% "min(" %++% targetColname %++% ") ~ . "     
    bigr.info(logSource, "Formula for bounds: " %++% boundsFormulaString)
    
    sum <- summary(dataset, as.formula(boundsFormulaString))    
    max <- sum[, 1]
    min <- sum[, 2]
    binsize <- (max - min) / nbins
    bigr.info(logSource, "min: " %++% min)
    bigr.info(logSource, "max: " %++% max)
    bigr.info(logSource, "binsize: " %++% binsize)
    bins <- as.integer((dataset[, targetColname] - min) / binsize - 
                           as.integer(dataset[, targetColname] == max))
    
    dataset$bins <- bins
    binsFormulaString <- "count(.) ~ " %++% paste(groupByColnames, collapse=" + ") %++% " + bins"
    
    #bigr.infoShow(logSource, head(dataset))
    
    bigr.info(logSource, "Hist formula: " %++% binsFormulaString)
    
    histStats <- summary(dataset, as.formula(binsFormulaString))   
    
    colnames <- names(histStats)
    colnames[length(colnames)] <- "counts"
    names(histStats) <- colnames

    if (length(groupByColIds) > 0) {
        # Combine grouping column names into a single string value
        instr <- "paste(" %++% paste("histStats[, " %++% seq(1:length(groupByColIds)) %++% "]", collapse =", ") %++% ", sep=',')"
        bigr.info(logSource, instr)
        histStats$class <- "(" %++% eval(parse(text=instr)) %++% ")"
        histStats <- histStats[, c("class", "counts", "bins")]
        
        # Fill zero counts (not included in the summary)
        allbins <- merge(unique(histStats$class), seq(1:nbins) - 1)
        names(allbins) <- c("class", "bins")
        allbins$counts <- 0
        histStats <- ddply(rbind(allbins, histStats), .(class, bins), summarize, counts = sum(counts))
        histStats$centroids <- histStats$bins * binsize + min + binsize / 2
        histStats <- histStats[ order(histStats$class, histStats$centroids), ]
    } else {
        histStats$centroids <- histStats$bins * binsize + min + binsize / 2
    }
    # Return the statistics along with the axis labels
    return(list(targetColname, groupByColnames, histStats))
}

# This function extracts the required parameters from a formula in order to
# calculate statistics for boxplots and histograms.
#
# @param formula a formula or a bigr.vector
# @return
.bigr.parseFormulaToPlot <- function(formula, data=NULL) {
    logSource <- "extractVariables"
     
    # Validate formula
    if (class(formula) != "formula" && class(formula) != bigr.env$VECTOR_CLASS_NAME) {
        return(NULL)
    }
    if (class(formula) == "formula") {
        charFormula <- as.character(formula)
    
        # A formula must have three elements: '$', target column and
        # grouping columns
        if (length(formula) != 3) {
            bigr.warn(logSource, "Incomplete formula.")
            return(NULL)
        }
        if (charFormula[1] != "~") {
            return(NULL)
        }
        
        # Check for invalid operators /symbols
        if (.bigr.contains(charFormula[2], "-") | .bigr.contains(charFormula[3], 
                                                           "-")) {
            bigr.err(logSource, "Invalid symbol: -")            
        }
        if (.bigr.contains(charFormula[2], "*") | .bigr.contains(charFormula[3], 
                                                           "*")) {
            bigr.err(logSource, "Invalid symbol: *")
        }
        if (.bigr.contains(charFormula[2], "/") | .bigr.contains(charFormula[3], 
                                                           "/")) {
            bigr.err(logSource, "Invalid symbol: /")
        }
        if (.bigr.contains(charFormula[2], "^") | .bigr.contains(charFormula[3], 
                                                           "^")) {
            bigr.err(logSource, "Invalid symbol: ^")
        }
        if (.bigr.contains(charFormula[2], ":") | .bigr.contains(charFormula[3], 
                                                           ":")) {
            bigr.err(logSource, "Invalid symbol: :")
        }
        if (.bigr.contains(charFormula[2], "~") | .bigr.contains(charFormula[3], 
                                                           "~")) {
            bigr.err(logSource, "Invalid formula: multiple ~ operators are not supported")
        }
        if (.bigr.contains(charFormula[2], "|") | .bigr.contains(charFormula[3], 
                                                           "|")) {
            bigr.err(logSource, "Invalid symbol: |")
        }
        if (.bigr.contains(charFormula[2], "poly(") | .bigr.contains(charFormula[3], 
                                                                 "poly(")) {
            bigr.err(logSource, "Invalid function: poly(")
        }
        if (.bigr.contains(charFormula[2], "Error(") | .bigr.contains(charFormula[3], 
                                                                "Error(")) {
            bigr.err(logSource, "Invalid function: Error(")
        }
        if (.bigr.contains(charFormula[2], "I(") | .bigr.contains(charFormula[3], 
                                                               "I(")) {
            bigr.err(logSource, "Invalid function: I(")
        }
        
        leftSide <- formula[[2]]
        rightSide <- formula[[3]]
        
        leftSideChar <- as.character(formula)[2]
        rightSideChar <- as.character(formula)[3]
        groupByColnames <- NULL
        targetColname <- NULL
        
        #####################################
        # Case 1: No data parameter specified
        #####################################        
        if (is.null(data)) {
            
            # Check that a bigr.frame is specified for both left and right sides of the formula
            if (!.bigr.contains(leftSideChar, "$") | !.bigr.contains(rightSideChar, "$")) {
                bigr.err(logSource, "A bigr.frame must be specified (1)")
            }
            # Parse left side
            if (length(leftSide) == 3) {
                data <- eval(formula[[2]][[2]])
                targetColname <- as.character(formula[[2]][[3]])
            } else {
                bigr.err(logSource, "Invalid formula left side. Incorrect number of arguments.")                
            }
            groupByColnames <- all.vars(formula[[3]])[-1]
            
        ##################################
        # Case 2: data parameter specified
        ##################################            
        } else {
            if (.bigr.contains(leftSideChar, "$") | .bigr.contains(rightSideChar, "$")) {
                bigr.err(logSource, "Ambiguous bigr.frame was found. If argument 'data' is specified, " %++% 
                    " operator '$' should not appear in the formula (1)")
            }
            if (length(leftSide) != 1) {
                bigr.err(logSource, "Ambiguous bigr.frame was found. If argument 'data' is specified, " %++% 
                             " operator '$' should not appear in the formula (2)")
            }
            targetColname <- all.vars(formula[[2]])   
            groupByColnames <- all.vars(formula[[3]])
        }
        if (length(targetColname) > 1) {
            bigr.err(logSource, "More than one target column were found but only one was expected")
        }
        if (class(data) != bigr.env$FRAME_CLASS_NAME) {
            bigr.err(logSource, "A bigr.frame or bigr.vector must be specified to calculate box plot or histogram statistics.")
        }
        
        # Obtain column id's
        targetColId <- match(targetColname, colnames(data))
        
        if (!(.bigr.is.integer(targetColId) & targetColId > 0)) {
            bigr.err(logSource, "Column '" %++% targetColname %++%
                 "' does not belong to the given bigr.frame.")
        }
    
        # Check that target column is numeric
        coltype <- coltypes(data)[targetColId]
        if (coltype != "numeric" & coltype != "integer") {
            bigr.err(logSource, "Target column for histograms and box plots must be numeric")
        }
        
        groupByColIds <- match(groupByColnames, colnames(data))
        if (.bigr.hasNullOrEmpty(groupByColIds)){
            bigr.err(logSource, "At least one specified column does not belong to the given bigr.frame")
        }
        return(list(data, targetColId, targetColname, groupByColIds,
                groupByColnames))
    } else {
        # If a bigr.vector is provided
        if (formula@dataType != "numeric" & formula@dataType != "integer") {
            bigr.err(logSource, "Target column for plot must be of type 'numeric' or 'integer'.")
        }
        data <- formula
        targetColId <- 1
        targetColname <- formula@name
        groupByColIds <- vector()
        groupByColnames <- vector()
        return(list(data, targetColId, targetColname, groupByColIds,
                groupByColnames))
    }
}

bigr.vectorToFrame <- function(bv) {
    logSource <- "bigr.vectorToFrame"
    if (class(bv) == bigr.env$FRAME_CLASS_NAME) {
        return(bv)
    }
    if (class(bv) == bigr.env$VECTOR_CLASS_NAME) {
        bf <- new(bigr.env$FRAME_CLASS_NAME, dataSource=bigr.env$TRANSFORM, dataPath=bv@dataPath,
                  colnames=bv@name, coltypes=bv@dataType, localProcessing=bv@localProcessing, 
                  na.string="", envs=bv@envs)
        bf@tableExpression <- bv@tableExpression
        bf@columnExpression <- bv@columnExpression
        return(bf)
    } else {
        bigr.err(logSource, "Unsupported type: '" %++% class(bv) %++% "'")
    }
}
