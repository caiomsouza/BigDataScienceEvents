#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------

#' class bigr.jdbc
#' 
#' This is the JDBC implementation. It requires BigSQL JDBC for client/server database connection.
#' The bigr.env$CONNECTION saves the jdbcObj of this class.
#' The object of this class connects to BigSQL and then create a statement for all the queries.
#' @section Slots:
#'  \describe{
#'      \item{\code{connProp}:}{\code{"list"} values specifying the necessary connection attributes}
#'      \item{\code{jdbcConnection}:}{\code{"jobjRef"} the real JDBC connection object as output}
#'      \item{\code{statement}:}{\code{"jobjRef"} the statement used to execute the queries}
#'  }

#' @name bigr.jdbc
#' @rdname bigr.jdbc
#' @exportClass bigr.jdbc
#' @keywords internal
setClass(bigr.env$JDBC_CLASS_NAME,
         representation(
             connProp = "list",
             jdbcConnection = "jobjRef",
             statement = "jobjRef",
             env = "environment"
         ),
         prototype(
             connProp = NULL,
             jdbcConnection = NULL,
             statement = NULL,
             env = NULL)
)

# Constructor of bigr.jdbc, it taks the bigr.env$CONNECTION as input
setMethod("initialize", bigr.env$JDBC_CLASS_NAME, 
          function(.Object, connProp) {
              logSource <- "bigr.jdbc::initialize"
              bigr.info(logSource, "Initializing bigr.jdbc...")
              
              # checking parameters
              if (missing(.Object) || missing(connProp)) {
                  bigr.err(logSource, "Arguments .Object and connProp are required...")
              }
              
              if (is.null(.Object)) {
                  bigr.err(logSource, "Invalid .Object value...")
              }
              
              if (is.null(connProp)) {
                  bigr.err(logSource, "Invalid connProp connection properties...")
              }
              
              # based on rJava package for java invocation
              require(rJava)
              
              # include the JDBC driver jar file in the classpath
              .jinit(classpath=connProp$driverPath)
              
              # add the class path to the BigRResultSet class
              bigrRoot <- system.file(package=bigr.env$PACKAGE_NAME)
              .jaddClassPath(bigrRoot %++% "/" %++% "BigRResultSet.jar")
              
              # import required Java packages
              javaImport("java.sql.*")
              javaImport("java.math.BigDecimal")
              javaImport("java.util.Properties")
              javaImport("java.io.*")
              
              # set up the connection string, including host/port/database/user/password
              url <- .jnew("java/lang/String", connProp$connectionString)
              
              # the name of the BigSQL JDBC driver
              sqlserver <- "com.ibm.biginsights.bigsql.jdbc.BigSQLDriver"
              
              # the way to retrieve the BigSQL driver from the system
              .jfindClass(sqlserver)
              
              # try to establish the connection with BigSQL
              # first we try the DriverManager approach, which is the recommended approach
              # if the driver can be found above
              conn <- .jnull()
              conn <- .jcall("java/sql/DriverManager", "Ljava/sql/Connection;", "getConnection", url, check=FALSE)
              ex <- .jgetEx()
              .jcheck(TRUE)          
              if (!is.null(ex)) {
                  bigr.info(logSource, "Failed to establish the jdbc connection, retry...")
              }

              # if above fails, we will try to load the driver manually
              if (.jnull() == conn) {
                  # retry with loading driver
                  info <- .jcall(sqlserver, "Ljava/util/Properties;", "parseURL", url, .jcast(.jnull(), "java.util.Properties"))
                  drv <- .jnew(sqlserver)
                  conn <- .jcall(drv, "Ljava/sql/Connection;", "connect", url, info, check=FALSE)
                  ex <- .jgetEx()
                  .jcheck(TRUE)          
                  if (!is.null(ex)) {
                      bigr.err(logSource, "Failed to establish the jdbc connection with BigSQL. Please check the error " %++% ex$getMessage())
                  }
              }

              # we have the connection now, set it up in the bigr.env$CONNECTION
              if (.jnull() != conn) {
                  .Object@jdbcConnection <- conn
                  .Object@connProp <- connProp
                  .Object@env <- new.env()
                  .Object@env$jc <- conn
              
                  finalizer <- function(e) {
                      # disconnect if not yet
                      if (!is.jnull(e$jc)) {
                          .jcall(e$jc, "V", "close")
                          .jclear()
                      }
                  }
                  reg.finalizer(.Object@env, finalizer)
              }
              return (.Object)
          }
)

.bigr.jdbc.query.helper <- function(connObj, queryText, update=FALSE)
{
    logSource <- ".bigr.jdbc.query.helper"
    
    if (update == TRUE) {
        query <- .jcall(connObj@statement, "I", "executeUpdate", queryText, check=FALSE)
    }
    else {
        query <- .jcall(connObj@statement, "Ljava/sql/ResultSet;", "executeQuery", queryText, check=FALSE)
    }
    
    ex <- .jgetEx()
    .jcheck(TRUE)
    
    if (!is.null(ex)) {
        msg <- "Error code : " %++% ex$getErrorCode() %++% ", SQLState : " %++% ex$getSQLState() %++% 
               "\nCaused by : " %++% ex$getMessage() %++% "\nThe stack trace :"
        sw <- .jcast(.jnew("java/io/StringWriter"), "java/io/Writer")
        pw <- .jnew("java/io/PrintWriter", sw)
        .jcall(ex, "V", "printStackTrace", pw)
        bigr.err(logSource, msg %++% sw$toString())
    }
    
    return (query)
}

#' Function to execute a query on BigSQL server
#' nrow is used to control how many rows caller wants to retrieve
.bigr.jdbc.query <- function(queryText, update=FALSE, nrow=0, colnames, coltypes)
{
    logSource <- ".bigr.jdbc.query"
    bigr.info(logSource, "Start processing the query...")
    
    # check parameters
    if (missing(queryText)) {
        bigr.err(logSource, "Argument queryText is required...")
    }
    
    if (missing(colnames)) {
        colnames <- NULL
    }
    
    if (missing(coltypes)) {
        coltypes <- NULL
    }
    
    if (nrow < 0) {
        bigr.err(logSource, "Argument nrow can not be negative...")
    }
    
    # get the connection object
    connObj <- bigr.env$CONNECTION@jdbcObj
    
    # if the statement handle has not been created, create it now
    if (is.jnull(connObj@statement) || .jcall(connObj@statement, "Z", "isClosed", check=FALSE)) {
        .jcheck(TRUE)
        tryCatch({
            connObj@statement <- .jcall(connObj@jdbcConnection, "Ljava/sql/Statement;", "createStatement")
        }, error = function (e) {
            bigr.err(logSource, "Failed to create the statement...")
        })
        bigr.env$CONNECTION@jdbcObj@statement <- connObj@statement
    }
    
    # if it is just an update, no ResultSet to handle, otherwise, we need to parse the result set
    if (update == FALSE) {
        # run the query
        query <- .bigr.jdbc.query.helper(connObj, queryText)
        
        # nothing returns
        if (is.null(query)) {
            return (NULL)
        }
        
        # we have result set to process
        numColumns <- 0
        rsmd <- .jcall(query, "Ljava/sql/ResultSetMetaData;", "getMetaData")
        numColumns <- .jcall(rsmd, "I", "getColumnCount")
    
        # build the vectors of column type name
        columnTypeNameV <- c()
        cols <- list()
        for (i in 1:as.numeric(numColumns)) {
            columnTypeName <- .jcall(rsmd, "S", "getColumnTypeName", as.integer(i))
            columnTypeNameV <- c(columnTypeNameV, columnTypeName)

            if (("array" == columnTypeName) && (1 == numColumns) && !is.null(coltypes)) {
                for (j in 1:length(coltypes)) {
                    cols[[j]] <- as.character(c())
                }
            }
            else if (("array" == columnTypeName) || ("char" == columnTypeName) || ("varchar" == columnTypeName) ||
                     ("binary" == columnTypeName) || ("timestamp" == columnTypeName) || ("boolean" == columnTypeName) ||
                     ("bigint" == columnTypeName) || ("double" == columnTypeName) || ("float" == columnTypeName)) {
                cols[[i]] <- as.character(c())
                names(cols)[i] <- .jcall(rsmd, "S", "getColumnName", as.integer(i))
            }
            else {
                bigr.err(logSource, "Unknown data type...")
            } 
        }
        
        # set fetchSize
        # retrieve fetchsize option
        fetchSize <- getOption("bigr.jdbc.fetchsize")
        if (is.null(fetchSize)) {
            fetchSize <- as.integer(16384)
        }
        else {
            fetchSize <- as.integer(fetchSize)
            if (is.na(fetchSize)) {
                fetchSize <- as.integer(16384)
            }
        }
        .jcall(connObj@statement, "V", "setFetchSize", fetchSize)
        
        # fetch first time
        rest <- .jcall(query, "Z", "next", check=FALSE)
        ex <- .jgetEx()
        .jcheck(TRUE)
        
        if (!is.null(ex)) {
            msg <- "Error code : " %++% ex$getErrorCode() %++% ", SQLState : " %++% ex$getSQLState() %++% 
                "\nCaused by : " %++% ex$getMessage() %++% "\nThe stack trace :"
            sw <- .jcast(.jnew("java/io/StringWriter"), "java/io/Writer")
            pw <- .jnew("java/io/PrintWriter", sw)
            .jcall(ex, "V", "printStackTrace", pw)
            bigr.err(logSource, msg %++% sw$toString())
                    
            return (NULL)
        }
        
        # invoke BigRResultSet to retrieve the data
        rowsFetched <- 0
        toBeFetched <- nrow
        if (("array" == columnTypeName) && (1 == numColumns) && !is.null(coltypes)) {
            brs <- .jnew("BigRResultSet", query, rsmd, TRUE, as.integer(length(coltypes)))
        }
        else {
            brs <- .jnew("BigRResultSet", query, rsmd, TRUE)
        }
        
        while (rest) {
            if ((toBeFetched > 0) && (toBeFetched < fetchSize)) {
                    rowsRequested <- toBeFetched
            }
            else {
                rowsRequested <- fetchSize
            }
             
            rowsFetched <- .jcall(brs, "I", "fetch", as.integer(rowsRequested))
            
            if (("array" == columnTypeName) && (1 == numColumns) && !is.null(coltypes)) {
                arrayColumns <- .jcall(brs, "I", "getArrayColumnCount")
                for (i in 1:arrayColumns) {
                    cols[[i]] <- c(cols[[i]], .jcall(brs, "[Ljava/lang/String;", "getStringTypeColumn", as.integer(i))[1:rowsFetched])
                }
            }
            else {
                for (i in 1:as.numeric(numColumns)) {
                    columnTypeName <- columnTypeNameV[i]
                    if (("array" == columnTypeName) || ("char" == columnTypeName) || ("varchar" == columnTypeName) ||
                        ("binary" == columnTypeName) || ("timestamp" == columnTypeName)) {
                        cols[[i]] <- c(cols[[i]], .jcall(brs, "[Ljava/lang/String;", "getStringTypeColumn", as.integer(i))[1:rowsFetched])
                    }
                    else if (("bigint" == columnTypeName) || ("double" == columnTypeName) || ("boolean" == columnTypeName) ||
                             ("float" == columnTypeName)) {
                        cols[[i]] <- c(cols[[i]], .jcall(brs, "[Ljava/lang/String;", "getColumnInString", as.integer(i))[1:rowsFetched])
                    }
                } # for
            }
                    
            if (toBeFetched > 0) {
                toBeFetched <- toBeFetched - rowsFetched
            }
                
            if (rowsFetched < rowsRequested) {
                rest <- FALSE
            }
        } # while
        
        # hint JVM gc to collect the memory allocated in JDBC object
        .jcall(brs, "V", "release")
        
        # remove the rJava objects
        rm(brs)
        
        # convert the list into a data frame and return
        if (length(cols[[1]]) > 0) {        
            if (!is.null(coltypes)) {
                # use read.table to split the array of array data type for the moment
                if ((numColumns == 1) && ("array" == columnTypeNameV[1])) {
                    for (i in 1:as.numeric(arrayColumns)) {
                        class(cols[[i]]) <- coltypes[i]
                    }
                }
                else if (numColumns == length(coltypes)) {
                    for (i in 1:as.numeric(numColumns)) {
                        class(cols[[i]]) <- coltypes[i]
                    }
                }
                else {
                    bigr.err(logSource, "Invalid coltypes is specified...")
                }
            }
            else {
                for (i in 1:as.numeric(numColumns)) {
                    columnTypeName <- columnTypeNameV[i]
                    if (("array" == columnTypeName) || ("char" == columnTypeName) || ("varchar" == columnTypeName) ||
                        ("binary" == columnTypeName) || ("timestamp" == columnTypeName)) {
                        class(cols[[i]]) <- "character"
                    }
                    else if (("bigint" == columnTypeName) || ("double" == columnTypeName) || ("float" == columnTypeName)) {
                        class(cols[[i]]) <- "numeric"
                    }
                    else if ("boolean" == columnTypeName) {
                        class(cols[[i]]) <- "logical"
                    }
                }
            }
            
            attr(cols, "row.names") <- seq_len(length(cols[[1]]))
            class(cols) <- "data.frame"
            
            if (!is.null(colnames) && (ncol(cols) == length(colnames))) {
                colnames(cols) <- colnames
            }
            
            if (nrow > 0) {
                cols <- head(cols, n=nrow)
            }
        }
        else {
            # no row in the result set
            cols <- data.frame()
        }
        
        # close the query
        .jcall(query, "V", "close")
        
        # ask JVM to run garbage collection
        .jcall("java/lang/System", "V", "gc")
        
        return (cols)
    }
    else {
        # it is an update case, we just run the jdbc function
        return (.bigr.jdbc.query.helper(connObj, queryText, update=TRUE))        
    }
}

#' Wrapper function for update
.bigr.jdbc.update <- function(queryText)
{
    logSource <- ".bigr.jdbc.update"
    bigr.info(logSource, "Start processing update...")
    .bigr.jdbc.query(queryText, update=TRUE)
}

#' The function to establish the JDBC connection
.bigr.jdbc.connect <- function(connProp) {
    .Object <- new(bigr.env$JDBC_CLASS_NAME, connProp = connProp)
    return (.Object)
}

#' The function to disconnect
.bigr.jdbc.disconnect <- function(jdbcObj) {
    logSource <- ".bigr.jdbc.disconnect"
    if (.bigr.jdbc.isValid()) {
        if (!is.jnull(jdbcObj@statement)) {
            .jcall(jdbcObj@statement, "V", "close")
            jdbcObj@statement <- .jnull()
        }
        .jcall(jdbcObj@jdbcConnection, "V", "close")
        jdbcObj@jdbcConnection <- .jnull()
        jdbcObj@env$jc <- .jnull()
    }
}

#' Return whether the JDBC connection is still valid
.bigr.jdbc.isValid <- function(jdbcObj) {
    if (missing(jdbcObj)) {
        if (.bigr.isNullOrEmpty(bigr.env$CONNECTION)) {
            return(FALSE)
        } else {
            jdbcObj <- bigr.env$CONNECTION@jdbcObj
        }
    }
    if (.bigr.isNullOrEmpty(jdbcObj)) {
        return(FALSE)
    } else {
        return (.jcall(jdbcObj@jdbcConnection, "Z", "isValid", as.integer(0)))
    }
}
