#-------------------------------------------------------------
# IBM Confidential
# OCO Source Materials
# (C) Copyright IBM Corp. 2010, 2013
# The source code for this program is not published or
# otherwise divested of its trade secrets, irrespective of
# what has been deposited with the U.S. Copyright Office.
#-------------------------------------------------------------


#############################################################################
### DOCUMENTATION for the package (also "An Introduction to Big R")
#############################################################################

#' Big R (bigr) provides an end-to-end integration of R within IBM InfoSphere
#' BigInsights. This makes it easy to write and execute R programs that 
#' operate on big data.
#' 
#' Using Big R, an R user can explore, transform, and analyze big data hosted
#' in a BigInsights cluster using familiar R syntax and paradigm. All of 
#' theses capabilities are accessible from a standard R client. The goals of 
#' Big R are two-fold:
#' 
#' (1) Enable the use of R as a query language for big data: Big R hides many
#' of the complexities pertaining to the underlying Hadoop / MapReduce 
#' framework. Using classes such as bigr.frame, bigr.vector and bigr.list, a 
#' user is presented with an API that is heavily inspired by R's foundational
#' API on data.frames, vectors and frames.
#' 
#' (2) Enable the pushdown of R functions such that they run right on the 
#' data: Via mechanisms such as groupApply, rowApply and tableApply, 
#' user-written functions composed in R can be shipped to the cluster. 
#' BigInsights transparently parallelizes exection of these function and 
#' provides consolidated results back to the user. Almost any R code, 
#' including most packages available on open-source repositories such as 
#' CRAN, can be run using this mechanism.
#' 
#' To use Big R, one needs to take the following steps:
#' 
#' (1) Install the "bigr" package on the client. Big R requires several 
#' pre-requisite packages including rJava, data.table, and base64enc.
#' 
#' (2) To enable function pushdown via the "Apply" functions, each data node 
#' of a BigInsights cluster needs to have the R interpreter installed on it. 
#' In addition, each data node also needs the same "bigr" package installed.
#' 
#' (3) Ensure that Big SQL server is running on the BigInsights cluster. As 
#' Big R statements are executed, they are transparently converted into 
#' corresponding SQL and JaQL statements, and these are executed by the Big
#' SQL server.
#' 
#' The builtin package documentation describes the package API and includes 
#' numerous illustrative examples. Many of the examples refer to the 
#' "airline" dataset. This data originally comes from US DOT/RITA 
#' (http://www.rita.dot.gov) and a cleansed version is also available at 
#' http://stat-computing.org/dataexpo/2009/the-data.html. This data serves as
#' an excellent vehicle for describing the capabilities of Big R. A small 
#' sample of the original data is bundled with the Big R package itself.
#' 
#' @examples \dontrun{
#' 
#' # In order to try out any example, first run the following steps to upload 
#' # the aforementioned dataset to a BigInsights cluster.
#' bigr.connect(host="hostname", port=7052, 
#'              user="username", password="password")
#' airfile <- system.file("extdata", "airline.zip", package="bigr")
#' airfile <- unzip(airfile, exdir = tempdir())
#' airR <- read.csv(airfile, stringsAsFactors=F)
#' 
#' # Upload the data to the BigInsights server. This may take 15-20 seconds
#' air <- as.bigr.frame(airR)
#' air <- bigr.persist(air, dataSource="DEL", dataPath="airline_demo.csv", 
#'                      header=T, delimiter=",", useMapReduce=F)
#'                      
#' # Once uploaded, one merely needs to instantiate a big.frame object, 
#' # commonly referenced as "air" in the examples, to access the dataset via
#' # the Big R API.
#' air <- bigr.frame(dataPath = "airline_demo.csv", 
#'                   dataSource = "DEL", 
#'                   delimiter=",", header = T,
#'                   coltypes = ifelse(1:29 %in% c(9,11,17,18,23), 
#'                                     "character", "integer"),
#'                   useMapReduce = F)
#' }
#'                   
#' @docType package
#' @name An Introduction to Big R
#' @title An Introduction to Big R
#' @rdname intro
NULL

#############################################################################
### DOCUMENTATION for length()
#############################################################################

#' Return the length of a Big R object. The length of a bigr.frame is the 
#' number of its columns. The length of a bigr.vector is the number of its
#' elements. The length of a bigr.list is the number of objects held in the
#' list
#' 
#' @name length
#' @title Length of a bigr object
#' @section Usage: 
#'  \code{length(x)}
#' @param x a bigr.vector, bigr.frame or bigr.list
#' @examples \dontrun{
#' 
#' # length of a bigr.frame (i.e. number of columns)
#' length(air)
#' 
#' # length of a bigr.vector (i.e. number of elements)
#' length(air[,"UniqueCarrier"])
#' }
NULL


